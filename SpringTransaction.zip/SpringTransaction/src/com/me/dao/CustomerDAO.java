package com.me.dao;

import com.me.entity.Customer;

public interface CustomerDAO {

	public void create(Customer customer);
}