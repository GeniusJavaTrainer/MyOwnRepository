package com.me.client;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.me.entity.Address;
import com.me.entity.Customer;
import com.me.service.CustomerManager;
import com.me.service.CustomerManagerImpl;

public class TransactionManagerMain {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
				"spring.xml");

		CustomerManager customerManager = ctx.getBean("customerManager",
				CustomerManagerImpl.class);

		Customer cust = createDummyCustomer();
		customerManager.createCustomer(cust);

		ctx.close();
	}

	private static Customer createDummyCustomer() {
		Customer customer = new Customer();
		customer.setId(4);
		customer.setName("Dagdu");
		Address address = new Address();
		address.setId(4);
		address.setCountry("Bharat");
		address.setAddress("Pune");
		customer.setAddress(address);
		return customer;
	}

}
