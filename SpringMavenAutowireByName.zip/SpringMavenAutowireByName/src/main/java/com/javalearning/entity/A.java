package com.javalearning.entity;

public class A {
	private B b;
	
	public A(){
		System.out.println("Inside A");
	}
}