package com.javalearning.entity;

public class C {
	public C(){
		System.out.println("Inside C");
	}
}