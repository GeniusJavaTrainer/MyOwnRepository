package com.javalearning.entity;

public class B {
	private C c;
	
	public B(){
		System.out.println("Inside B");
	}
}