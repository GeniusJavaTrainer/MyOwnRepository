
package com.javalearning.client;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.javalearning.dao.MyDao;

public class Client1 {

	public static void main(String[] args) {
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		MyDao mydao  = (MyDao)appContext.getBean("dataSource");
		
		System.out.println(mydao);
	}

}
