package com.javalearning.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.javalearning.entity.Bean1;
import com.javalearning.entity.Bean2;
import com.javalearning.entity.Emp;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml", "beans2.xml");
		
		Emp e = (Emp)appContext.getBean("empl");
		e.calculateSalary();
		System.out.println(e);
		
		//A a = (A)appContext.getBean("exA");
		
		/*Address address = (Address)appContext.getBean("another");
		System.out.println(address);*/
		
		Bean1 bean1 = (Bean1)appContext.getBean("bean1");
		Bean2 bean2 = (Bean2)appContext.getBean("bean2");
		
		System.out.println(bean1);
		System.out.println(bean2);
		//Bean1 bean3 = (Bean1)appContext.getBean("bean2");
		
		/*if(bean1 == bean2){
			System.out.println("Both are same");
		}else{
			System.out.println("Both are different");
		}*/
		/*System.out.println(bean1);
		System.out.println(bean2);*/
	}
}