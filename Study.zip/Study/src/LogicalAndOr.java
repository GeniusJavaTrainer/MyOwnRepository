
public class LogicalAndOr {

	public static void main(String[] args) {
		/*int age = 32;
		int experience = 3;
		boolean isThereAccident = true;
		
		if(age >= 30 || experience > 5 || isThereAccident == false){
			System.out.println("Driver selected.");
		}else{
			System.out.println("Driver is not selected.");
		}*/
		
		int a = 10;
		int b = 8;
		
		if(a > 10 | b++ == 8){
			System.out.println("Correct!");
		}else{
			System.out.println("Incorrect!");
		}
		
		System.out.println(b);
	}
}