
public class BitwiseOperators {

	public static void main(String[] args) {
		int number = 3;//0011
		int mask = 2;  //0010
		int result = 0;//0001
		
		result = number ^ mask;
		System.out.println(result);
	}
}