
public class TernaryOperator {

	public static void main(String[] args) {
		int first = 10;
		int second = 12;
		
		int greatest = 0;
		
		greatest = (first > second)?first:second;
		
		System.out.println(greatest);
	}
}