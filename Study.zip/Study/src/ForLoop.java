
public class ForLoop {

	public static void main(String[] args) {
		int i = 1;
		int j = 10;
		// init ; test ; inc/dec
		while(i <= 10){
			System.out.println(i + "\t"+j);
			i++;
			j--;
		}
	}
}