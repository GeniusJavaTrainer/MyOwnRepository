
public class IfStatement {

	public static void main(String[] args) {
		int a = 10;
		boolean isItTrue = true;
		
		if(isItTrue){
			System.out.println("Non-zero");
		}else{
			System.out.println("Zero");
		}
	}
}