
public class SwitchDemo {

	public static void main(String[] args) {
		int grade = 1;
		
		float basic = 0.0f;
		float da = 0.0f;
		float hra = 0.0f;
		float pf = 0.0f;
		float salary = 0.0f;
		
		final int gr = 2;
		
		switch(grade){
		case 1:// byte, short, int
			basic = 250000;
			da = .80f * basic;
			hra = .50f * basic;
			pf = .20f * basic;
			break;

		case 3:
			basic = 100000;
			da = .50f * basic;
			hra = .30f * basic;
			pf = .1f * basic;
			break;
			
		case gr:
			basic = 150000;
			da = .60f * basic;
			hra = .40f * basic;
			pf = .15f * basic;
			break;
		default:
			System.out.println("Erroneous grade.");
			break;
		}
		
		salary = basic + da + hra - pf;
		
		System.out.printf("Salary: Rs. %.2f", salary);
	}
}