
public class Operators {

	public static void main(String[] args) {
		int number = 10;
		int result = 0;
		System.out.println("Before incrementing:");
		System.out.println("number: "+number);
		System.out.println("result: "+result);
		
		result = number++;//Post increment.
		/* Assign the value to left hand side first & then 
		 * increases the value by 1.
		 */
		System.out.println("After post incrementing:");
		System.out.println("number: "+number);
		System.out.println("result: "+result);
		
		result = ++number;
		
		/* Increment the value first & then assign the value to left hand side.
		 */
		
		System.out.println("After pre incrementing:");
		System.out.println("number: "+number);
		System.out.println("result: "+result);
	}
}