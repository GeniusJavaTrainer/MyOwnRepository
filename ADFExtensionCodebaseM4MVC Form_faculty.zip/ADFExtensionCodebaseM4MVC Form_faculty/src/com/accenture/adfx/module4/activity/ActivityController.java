package com.accenture.adfx.module4.activity;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.adfx.module4.dao.ICustomerDao;
import com.accenture.adfx.module4.entity.Customer;
import com.accenture.adfx.module4.entity.Gender;

@Controller
public class ActivityController {

	protected final Log logger = LogFactory.getLog(getClass());
	
	/**
     * Data Access Object for account. This is injected by the Spring framework.
     * The @Autowired annotation
     * marks a Customer DAO resource that is needed by the this class. When the
     * annotation is applied to this method, the container will inject an
     * instance of the Customer DAO into the application component when the
     * component is initialised.
     */
	@Autowired
    private ICustomerDao customerDao;   
    

	/**
	 * This method return the gender values to be populated in the page.
	 * Annotation @ModelAttribute binds a method parameter or method return value to a named 
	 * model attribute, exposed to a web view. Supported for RequestMapping annotated 
	 * handler classes. Can be used to expose command objects to a web view, using 
	 * specific attribute names, through annotating corresponding parameters of a 
	 * RequestMapping annotated handler method.
	 * @return genderList - List of gender values
	 */
	@ModelAttribute("genderList")
	public List<Gender> populateCountry() {
		List<Gender> genderList = new ArrayList<Gender>();
		Gender g1 = new Gender();
		g1.setId(1);
		g1.setDescription("Male");
		genderList.add(g1);
		g1 = new Gender();
		g1.setId(2);
		g1.setDescription("Female");
		genderList.add(g1);
		return genderList;
	}
	
	/**
	 * This method loads the customer profile page with attributes like first name, last name, etc.,.
	 * The dispatcher will scan such annotated classes for mapped methods, detecting @RequestMapping
	 * annotations. To enable auto detection of such annotated controllers, add
	 * component scanning in configuration. This is easily achieved by using the
	 * spring-context schema as shown in the following XML snippet. 
	 * <br/>
	 * &lt;context:component-scan base-package =
	 * "com.accenture.adfx.newcodington.module28"/&gt; 
	 * <br/>
	 * @ModelMap - Implementation of Map for use when building model data for use with UI tools.
	 * The ModelAndView class uses a ModelMap class that is a custom Map implementation 
	 * that automatically generates a key for an object when an object is added to it. 
	 * <br/>	
	 * @param request - HttpServletRequest
	 * @param response - HttpServletResponse
	 * @param map - customer ModelMap
	 * @return ModelAndView - Model and View
	 * @throws Exception - Exception
	 */
	@RequestMapping("/customer.htm")
	public ModelAndView customerProfile(HttpServletRequest request,HttpServletResponse response, ModelMap map) throws Exception
	{
		// redirecting to the profile page (profile.jsp)
		Customer customer = new Customer();
		map.addAttribute(customer);
		return new ModelAndView("customer");
	}
	
	/**
	 * This method get the populated customer attribute values from UI and transform to dao.
	 * The dispatcher will scan such annotated classes for mapped methods, detecting @RequestMapping
	 * annotations. To enable auto detection of such annotated controllers, add
	 * component scanning in configuration. This is easily achieved by using the
	 * spring-context schema as shown in the following XML snippet. 
	 * <br/>
	 * &lt;context:component-scan base-package =
	 * "com.accenture.adfx.newcodington.module28"/&gt; 
	 * <br/>
	 * @ModelMap - Implementation of Map for use when building model data for use with UI tools.
	 * The ModelAndView class uses a ModelMap class that is a custom Map implementation 
	 * that automatically generates a key for an object when an object is added to it. 
	 * <br/>	
	 * @param request - HttpServletRequest
	 * @param response - HttpServletResponse
	 * @param map - customer ModelMap
	 * @return ModelAndView - Model and View
	 * @throws Exception - Exception
	 */
	
	@RequestMapping("/register.htm")
	public ModelAndView validateCustomer(HttpServletRequest request,HttpServletResponse response, @ModelAttribute("customer") Customer customer) throws Exception
	{

		logger.info("inside validateCustomer");
		
		ModelAndView mView=new ModelAndView();
		
		
		int updRecord=0;
		try
		{
		updRecord= customerDao.insertRecord(customer);
		logger.info("updRecord : "+updRecord);
		}
		catch(ClassNotFoundException ex)
		{
			logger.info("ClassNotFoundException : "+ex.getMessage());
			mView.addObject("MESSAGE",ex.getMessage());
			mView.setViewName("customer");
		}
		catch(SQLException ex)
		{
			logger.info("SQLException : "+ex.getMessage());
			mView.addObject("MESSAGE",ex.getMessage());
			mView.setViewName("customer");
		}
		if(updRecord>0)
		{
			logger.info("Success : "+updRecord);
			mView.addObject("MESSAGE","Customer " + customer.getFirstName() + " Succesfully Inserted..");
			mView.setViewName("insertstatus");
		}
		return mView;
	}
	
}
