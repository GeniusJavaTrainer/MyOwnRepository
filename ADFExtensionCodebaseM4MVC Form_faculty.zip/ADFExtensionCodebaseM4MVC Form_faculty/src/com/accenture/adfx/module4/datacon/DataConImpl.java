package com.accenture.adfx.module4.datacon;

/**
 * Spring Implementation to demonstrate connection with the Mysql 
 */

import javax.sql.DataSource;

public class DataConImpl implements DataConnection {

	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	/**
	 * Returns data source.
	 * @return dataSource.
	 */
	public DataSource dbcon() {
		return dataSource;
	}

}
