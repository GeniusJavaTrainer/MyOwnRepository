package com.accenture.adfx.module4.dao;

import java.sql.SQLException;

import com.accenture.adfx.module4.entity.Customer;

public interface ICustomerDao {
	
	public int insertRecord(Customer customer) throws SQLException, ClassNotFoundException;

}
