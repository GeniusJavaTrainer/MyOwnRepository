package com.accenture.adfx.module4.sample;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.adfx.module4.entity.Country;
import com.accenture.adfx.module4.entity.User;

/**
* This class is type of Spring 2.5 annotation based controller.
* The @Controller annotation indicates that a particular class serves the role
* of a controller. There is no need to extend any controller base class or
* reference the Servlet API.The basic purpose of the @Controller annotation is
* to act as a stereotype for the annotated class, indicating its role.
*/
@Controller
public class SampleController {
	
	protected final Log logger = LogFactory.getLog(getClass());
	
	/**
	 * This method return the list of country values to be populated in the page.
	 * Annotation @ModelAttribute binds a method parameter or method return value to a named 
	 * model attribute, exposed to a web view. Supported for RequestMapping annotated 
	 * handler classes. Can be used to expose command objects to a web view, using 
	 * specific attribute names, through annotating corresponding parameters of a 
	 * RequestMapping annotated handler method.
	 * @return countryList - List of country values
	 */
	@ModelAttribute("countryList")
	public List<Country> populateCountry() {
		List<Country> countryList = new ArrayList<Country>();
		Country c1 = new Country();
		c1.setCountryId(1);
		c1.setCountryName("India");
		countryList.add(c1);
		c1 = new Country();
		c1.setCountryId(2);
		c1.setCountryName("Others");
		countryList.add(c1);
		return countryList;
	}

	/**
	 * This method loads the login page with user name and password fields.
	 * The dispatcher will scan such annotated classes for mapped methods, detecting @RequestMapping
	 * annotations. To enable auto detection of such annotated controllers, add
	 * component scanning in configuration. This is easily achieved by using the
	 * spring-context schema as shown in the following XML snippet.
	 * <br/>
	 * &lt;context:component-scan base-package =
	 * "com.accenture.adfx.newcodington.module28"/&gt; 
	 * <br/>
	 * @ModelMap - Implementation of Map for use when building model data for use with UI tools.
	 * The ModelAndView class uses a ModelMap class that is a custom Map implementation 
	 * that automatically generates a key for an object when an object is added to it. 
	 * <br/>
	 * @param request - HttpServletRequest
	 * @param response - HttpServletResponse
	 * @return ModelAndView - Model and View
	 * @throws Exception - Exception
	 */
	
	@RequestMapping("/login.htm")
	public ModelAndView loadLoginPage(HttpServletRequest request,HttpServletResponse response, ModelMap map) throws Exception
	{
		logger.info("*********loadLoginPage method call");
	     User user = new User();
	     map.addAttribute(user);
		// redirecting to the login page (sample.jsp)
		return new ModelAndView("sample");
	}
	/**
	 * This method validates the user name and password.
	 * The dispatcher will scan such annotated classes for mapped methods, detecting @RequestMapping
	 * annotations. To enable auto detection of such annotated controllers, add
	 * component scanning in configuration. This is easily achieved by using the
	 * spring-context schema as shown in the following XML snippet. <br/>
	 * <br/>
	 * &lt;context:component-scan base-package =
	 * "com.accenture.adfx.newcodington.module28"/&gt; 
	 * <br/>
	 * @param response - HttpServletResponse
	 * @return mView - Model and View
	 * @throws Exception - Exception
	 */
	@RequestMapping("/userlogin.htm")
	public ModelAndView validateUser(HttpServletRequest request,HttpServletResponse response, @ModelAttribute("user") User user) throws Exception
	{
		logger.info("UserName :"+user.getUserName());
		logger.info("Country : "+user.getCountry());
		
		ModelAndView mView=new ModelAndView();
		
		// check the user name and password. If both are equal redirect to success page else error page. 
		if(user.getUserName().equalsIgnoreCase(user.getPassword()) && user.getCountry().equals("1"))
		{
			mView.addObject("USERNAME", user.getUserName());
			mView.setViewName("usersuccess");
		}
		else
		{
			mView.addObject("ERROR", "Invalid Credentials");
			mView.setViewName("sample");
		}
		return mView;
	}	
}