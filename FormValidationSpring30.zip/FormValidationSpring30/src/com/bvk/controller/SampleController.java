package com.bvk.controller;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bvk.entity.Country;
import com.bvk.entity.User;


/**
* This class is type of Spring 2.5 annotation based controller.
* The @Controller annotation indicates that a particular class serves the role
* of a controller. There is no need to extend any controller base class or
* reference the Servlet API.The basic purpose of the @Controller annotation is
* to act as a stereotype for the annotated class, indicating its role.
*/
@Controller
public class SampleController {
	
	protected final Log logger = LogFactory.getLog(getClass());
	@Autowired @Qualifier("validator")
	private Validator validator;
	
	@ModelAttribute("countryList")
	public List<Country> populateCountry() {
		List<Country> countryList = new ArrayList<Country>();
		Country c1 = new Country();
		c1.setCountryId(1);
		c1.setCountryName("India");
		countryList.add(c1);
		c1 = new Country();
		c1.setCountryId(2);
		c1.setCountryName("Others");
		countryList.add(c1);
		return countryList;
	}
	
	@RequestMapping("/login.htm")
	public ModelAndView loadLoginPage(HttpServletRequest request,HttpServletResponse response, ModelMap map) throws Exception
	{
		logger.info("*********loadLoginPage method call");
	     User user = new User();
	     map.addAttribute(user);
		// redirecting to the login page (sample.jsp)
		return new ModelAndView("sample");
	}
	
	@RequestMapping("/userlogin.htm")
	public ModelAndView validateUser(@ModelAttribute User user, BindingResult result) throws Exception
	{
		logger.info("UserName :"+user.getUserName());
		logger.info("Country : "+user.getCountry());
	
		ModelAndView mView=new ModelAndView();
		validator.validate(user, result);
		
		if (result.hasErrors()) {     
			mView.setViewName("sample");
			return mView;       
		} 
		// check the user name and password. If both are equal redirect to success page else error page.
		
		if(!user.getCountry().equals("1")){
			mView.addObject("ERROR", "Invalid country");
			mView.setViewName("sample");
		}
		
		else if(user.getUserName().equalsIgnoreCase(user.getPassword()) && user.getCountry().equals("1"))
		{
			mView.addObject("USERNAME", user.getUserName());
			mView.setViewName("usersuccess");
			
			
		}
		else
		{
			mView.addObject("ERROR", "Invalid Credentials");
			mView.setViewName("sample");
		}
		return mView;
	}	
}
