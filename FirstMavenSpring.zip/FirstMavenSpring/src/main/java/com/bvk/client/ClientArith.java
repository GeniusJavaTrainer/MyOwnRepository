package com.bvk.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bvk.entity.Arith;

public class ClientArith {

	public static void main(String[] args) {
		//IoC container
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		Arith arith = (Arith) appContext.getBean("arithImp");//Dependency Injection.
		
		System.out.println(arith.add(10, 20));
		
		/*Employee emp = (Employee)appContext.getBean("emp");
		
		System.out.println(emp);*/
	}
}