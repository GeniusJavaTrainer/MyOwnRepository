package byteDemo;

import entity.Student;

public class RandomAccessFileDemo {
	public static void main(String[] args) {
		Student student1 = new Student(1, "bvk", 98.76f);
		Student student2 = new Student(2, "ssn", 71.76f);
		Student student3 = new Student(3, "bcx", 85.43f);
		
		student1.writeToRandomFile();
		student2.writeToRandomFile();
		student3.writeToRandomFile();
		
		Student students[] = Student.readFromRandomFile();
		
		for (Student student : students) {
			System.out.println(student);
		}
	}
}