package characterDemo;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CharStreamDemo {
	public static void main(String[] args) {
		FileReader fileReader = null;
		FileWriter fileWriter = null;
		int value = 0;
		//char contents[] = null;
		
		try{
			fileReader = new FileReader("abc.txt");
			fileWriter = new FileWriter("target7.txt");
			//contents = new char[100];
			
			//fileReader.read(contents);
			value = fileReader.read();
			while(value != -1){
				fileWriter.write(value);
				value= fileReader.read();
			}
			//fileWriter.write(contents);
			//bos.write(contents);
			//bos.flush();
		}catch(IOException fnfe){
			System.out.println("File is not found.");
		}finally{
			try{
				if(fileReader != null){
					fileReader.close();
				}
				if(fileWriter != null){
					fileWriter.close();
				}
			}catch(IOException ie){
				System.out.println("Error while reading the file");
			}
		}
		System.out.println("Done with copying file.");
	}
}