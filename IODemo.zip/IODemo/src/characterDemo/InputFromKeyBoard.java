package characterDemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class InputFromKeyBoard {
	public static void main(String[] args) {
		BufferedReader br = null;
		
		int number = 0;
		float temperature = 0.0f;
		String input = null;
		
		try{
			br = new BufferedReader(new InputStreamReader(System.in));

			System.out.print("Enter an integer: ");
			input = br.readLine();
			number = Integer.parseInt(input);
			
			System.out.print("Enter a float value: ");
			input = br.readLine();
			temperature = Float.parseFloat(input);
			
			System.out.println(number);
			System.out.println(temperature);
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}catch(NumberFormatException nfe){
			System.out.println(nfe.getMessage());
		}finally{
			try{
				if(br != null){
					br.close();
				}
			}catch(IOException ioe){
				System.out.println(ioe.getMessage());
			}
		}
	}
}