package characterDemo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class BufferedPrimitiveData {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FileWriter fw = null;
		FileReader fr = null;
		
		PrintWriter pw = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		
		char ch = 'A';
		byte b = 120;
		short s = 30000;
		int i = 65535;
		float f = 56.78f;
		double d = 88.98;
		
		try{
			fw = new FileWriter("simplePrim.txt");
			bw = new BufferedWriter(fw);
			pw = new PrintWriter(bw);
			
			pw.println(ch);
			pw.println(b);
			pw.println(s);
			pw.println(i);
			pw.println(f);
			pw.println(d);
			pw.flush();
		}catch(IOException ie){
			System.out.println("File can't be opened.");
		}finally{
			pw.close();
		}
		
		try{
			fr = new FileReader("simplePrim.txt");
			br = new BufferedReader(fr);
			String str;
			while((str = br.readLine()) != null)
				System.out.println(str);
		}catch(IOException ie){
			System.out.println("File can't be opened.");
		}finally{
			try{
				fr.close();
			}catch(IOException ie){
				System.out.println("Unable to close the file.");
			}
		}
	}
}