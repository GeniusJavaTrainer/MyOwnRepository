package characterDemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ReadOneLine {

	public static void main(String[] args) {
		String input = null;
		
		BufferedReader br = null;
		
		try{
			br = new BufferedReader(new InputStreamReader(System.in));
			
			input = br.readLine();
			
			while(!input.equals("")){
				System.out.println(input);
				input = br.readLine();
			}
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}
	}
}