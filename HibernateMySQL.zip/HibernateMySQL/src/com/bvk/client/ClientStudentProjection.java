package com.bvk.client;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;

import com.bvk.entity.Student1;

public class ClientStudentProjection {

	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure().
				addAnnotatedClass(com.bvk.entity.Student1.class).buildSessionFactory();
		
		Session session = sessionFactory.openSession();

		try{
			Criteria criteriaStudent = session.createCriteria(Student1.class);
			criteriaStudent.setProjection(Projections.rowCount());
			
			long rows = (long)criteriaStudent.uniqueResult();
			System.out.println("Number of rows: " + rows);
			
			criteriaStudent.setProjection(Projections.avg("percent"));
			double average = (double)criteriaStudent.uniqueResult();
			System.out.println("Average Percentage: " + average);
			
			criteriaStudent.setProjection(Projections.max("percent"));
			float max = (float)criteriaStudent.uniqueResult();
			System.out.println("Maximum Percentage: " + max);
			
			criteriaStudent.setProjection(Projections.min("percent"));
			float min = (float)criteriaStudent.uniqueResult();
			System.out.println("Minimum Percentage: " + min);
			
		}catch(Exception e){
			System.out.println(e.getMessage());

		}
	}
}