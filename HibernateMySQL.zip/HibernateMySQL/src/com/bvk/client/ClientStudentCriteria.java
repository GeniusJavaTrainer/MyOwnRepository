package com.bvk.client;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.bvk.entity.Student1;

public class ClientStudentCriteria {
	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure().
				addAnnotatedClass(com.bvk.entity.Student1.class).buildSessionFactory();
		
		Session session = sessionFactory.openSession();

		try{
			Criteria criteriaStudent = session.createCriteria(Student1.class);
			
			/*criteriaStudent.addOrder(Order.desc("percent"));
			criteriaStudent.addOrder(Order.asc("name"));*/
			//criteriaStudent.add(Restrictions.ilike("name", "a%"));
			criteriaStudent.add(Restrictions.between("percent", 90f,100f));
			List<Student1>studentList = (List<Student1>)criteriaStudent.list();
			
			for (Student1 student : studentList) {
				System.out.println(student);
			}
		}catch(Exception e){
			System.out.println(e.getMessage());

		}
	}
}