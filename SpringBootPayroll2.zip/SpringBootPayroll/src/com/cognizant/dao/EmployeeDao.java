package com.cognizant.dao;
import java.util.List;

import com.cognizant.entity.Employee;

public interface EmployeeDao {
	
	int getAllEmployee(Employee employee);
	
	List<Employee> getEmpDetails();
	
	//List<UserDetails> getUser(int id);
	
	Employee getEmployeeById(int id );
	 
	String deleteEmployee(int id); 
	 
	String updateEmp(Employee employee);
	
	String createEmployee(Employee employee);

}
