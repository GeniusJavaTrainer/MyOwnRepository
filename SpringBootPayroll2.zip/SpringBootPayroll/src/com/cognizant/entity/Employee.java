

package com.cognizant.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class Employee implements Serializable
{

@Id
@Column(name = "empId")
private int empId;
@Column(name ="name")
    private String name;
@Column(name = "lastName")
private String lastName;
@Column(name = "dateOfBirth")
private String dateOfBirth;
@Column(name = "dateOfJoining")
private String dateOfJoining;
@Column(name = "emailId")
private String emailId;
@Column(name = "phoneNumber")
private String phoneNumber;
@Column(name = "designation")
private String designation;
@Column(name = "username")
private String username;
@Column(name = "password")
private String password;
@Column(name = "isAdmin")
private boolean isAdmin;
@Column(name = "salary")
private float salary;
@Column(name = "access")
private boolean access;

public Employee() {

}

public int getEmpId() {
return empId;
}

public void setEmpId(int empId) {
this.empId = empId;
}

public String getName() {
return name;
}

public void setName(String firstName) {
this.name = firstName;
}

public String getLastName() {
return lastName;
}

public void setLastName(String lastName) {
this.lastName = lastName;
}

public String getDateOfBirth() {
return dateOfBirth;
}

public void setDateOfBirth(String dateOfBirth) {
this.dateOfBirth = dateOfBirth;
}

public String getDateOfJoining() {
return dateOfJoining;
}

public void setDateOfJoining(String dateOfJoining) {
this.dateOfJoining = dateOfJoining;
}

public String getEmailId() {
return emailId;
}

public void setEmailId(String emailId) {
this.emailId = emailId;
}

public String getPhoneNumber() {
return phoneNumber;
}

public void setPhoneNumber(String phoneNumber) {
this.phoneNumber = phoneNumber;
}

public String getDesignation() {
return designation;
}

public void setDesignation(String designation) {
this.designation = designation;
}

public boolean getisAdmin() {
return isAdmin;
}

public void setAdmin(boolean isAdmin) {
this.isAdmin = isAdmin;
}

public boolean getaccess() {
return access;
}
public void setaccess(boolean access) {
this.access = access;
}

public String getUsername() {
return username;
}

public void setUsername(String username) {
this.username = username;
}

public String getPassword() {
return password;
}

public void setPassword(String password) {
this.password = password;
}

@Override
public String toString() {
return "Employee [empId=" + empId + ", name=" + name + ", username=" + username + ", password=" + password
+ "]";
}

public float getSalary() {
return salary;
}

public void setSalary(float salary) {
this.salary = salary;
}
}

