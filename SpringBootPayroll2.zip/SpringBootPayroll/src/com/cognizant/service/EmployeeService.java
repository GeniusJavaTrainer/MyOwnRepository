package com.cognizant.service;

import java.util.List;

import com.cognizant.entity.Employee;



public interface EmployeeService {
	int getAllEmployee(Employee employee);

	List<Employee> getEmpDetails();	
	
	Employee getEmployeeById(int id );
		 
	String deleteEmployee(int id); 
		 
	String updateEmp(Employee employee);
		
	String createEmployee(Employee employee);
}
