
public class Operators {

	public static void main(String[] args) {
		int num = 32;
		int shift = 2;
		
		int afterShift = num << shift;
		
		System.out.println(afterShift);
		
		afterShift = num * (int)Math.pow(2,shift);
		System.out.println(afterShift);
		
		afterShift = num >> shift;
		System.out.println(afterShift);
		
		afterShift = num / (int)Math.pow(2,shift);
		System.out.println(afterShift);
		
		afterShift = num >>> shift;
		System.out.println(afterShift);
		
		num = -32;
		shift = 2;
		
		System.out.println("For negative quantity:");
		
		afterShift = num >> shift;
		System.out.println(afterShift);
		
		afterShift = num >>> shift;
		System.out.println(afterShift);
	}
}