import java.util.Scanner;


public class ArraySearch {

	public static void main(String[] args) {
		int a[];
		int size = 0;
		int element = 0;
		int position = -1;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter array size: ");
		size = Integer.parseInt(scInput.nextLine());
		
		a = new int[size];
		
		for (int i = 0; i < a.length; i++) {
			System.out.print("Enter a number: ");
			a[i] = Integer.parseInt(scInput.nextLine());
		}
		
		System.out.print("Enter element to be searched: ");
		element = Integer.parseInt(scInput.nextLine());
		
		for (int i = 0; i < a.length; i++) {
			if(element == a[i]){
				position = i;
				break;
				
			}
		}
		
		if(position != -1){
			System.out.println("Element found at position: "+ (position+1));
		}else{
			System.out.println("Element not found.");
		}
		scInput.close();
	}
}