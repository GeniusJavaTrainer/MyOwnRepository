import java.util.Scanner;


public class StringTest {

	public static void main(String[] args) {
		String sport = null;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter your favorite sport: ");
		sport = scInput.nextLine();
		
		switch(sport){
		case "cricket":
		case "football":
		case "lawn tennis":
			System.out.println("So, you love outdoor sports");
			break;
			
		case "chess":
		case "badminton":
		case "table tennis":
			System.out.println("So, you love indoor sports");
			break;
		}
		scInput.close();
	}

}
