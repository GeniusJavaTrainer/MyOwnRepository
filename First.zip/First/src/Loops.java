
public class Loops {

	public static void main(String[] args) {
		Outer:
		{
		for(int i=1 ; i <= 5 ; i++){
			for(int j = 1 ; j <= 4 ; j++){
				if(i == 2 && j == 2){
					break Outer;
				}
				System.out.println(i+"\t"+j);
			}
			System.out.println();
			System.out.println("Outside inner loop\n");
		}
		System.out.println("\nOutside both the loops");
		}
		System.out.println("\nOutside block");
	Inner:
		{
			System.out.println("Hi");
			break Inner;
		}
		}
}