import java.util.Arrays;
import java.util.Scanner;


public class SortArray {

	public static void main(String[] args) {
		int a[];
		int size = 0;
				
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter array size: ");
		size = Integer.parseInt(scInput.nextLine());
		
		a = new int[size];
		
		for (int i = 0; i < a.length; i++) {
			System.out.print("Enter a number: ");
			a[i] = Integer.parseInt(scInput.nextLine());
		}
		
		System.out.println("Array before sorting: ");
		
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i]+"\t");
		}
		
		System.out.println();
		
		Arrays.sort(a);
		
		System.out.println("Array after sorting: ");
		
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i]+"\t");
		}
		scInput.close();
	}
}