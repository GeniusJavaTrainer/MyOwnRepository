import java.util.Scanner;


public class MyFirstProgram {

	public static void main(String[] args) {
		Scanner scInput = new Scanner(System.in);
		double area = 0.0;
				
		System.out.print("Enter radius: ");
		double radius = scInput.nextDouble();
		
		area = Math.PI * radius * radius;
		System.out.printf("Area is %-8.2f",area);
		
		scInput.close();
	}
}