
public class Compare {

	public static void main(String[] args) {
		byte num = 10;
		int qty = 60;
		char name = 'A';

		num = (byte)name;
		name = (char)num;
	}
}