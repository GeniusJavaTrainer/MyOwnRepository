import java.util.Scanner;

public class ArraysDemo {

	public static void main(String[] args) {
		int a[];
				
		int size = 0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter array size: ");
		size = Integer.parseInt(scInput.nextLine());
		
		a = new int[size];
		
		for (int i = 0; i < a.length; i++) {
			System.out.print("Enter a number: ");
			a[i] = Integer.parseInt(scInput.nextLine());
		}
		
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		scInput.close();
	}
}