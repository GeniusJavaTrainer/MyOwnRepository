import React from 'react'
import Component3 from './Component3'
export default function Component2() {
  return (
    <div>
        <Component3/>
    </div>
  )
}
