import React from 'react'

export default function NoContext5(props) {
  return (
    <div>
        <h1>Component 5</h1>
        <h1>{props.user}</h1>
    </div>
  )
}
