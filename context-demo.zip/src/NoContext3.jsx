import React from 'react'
import NoContext4 from './NoContext4'
export default function NoContext3(props) {
  return (
    <div>
        <h1>Component3</h1>
        <NoContext4 user={props.user}/>
    </div>
  )
}
