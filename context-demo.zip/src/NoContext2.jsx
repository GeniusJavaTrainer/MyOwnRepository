import React from 'react'
import NoContext3 from './NoContext3'
export default function NoContext2(props) {
  return (
    <div>
        <h1>Component 2</h1>
        <NoContext3 user={props.user}/>
    </div>
  )
}
