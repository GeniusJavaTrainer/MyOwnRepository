import "./App.css";

import Component1 from "./Component1";
function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <NoContext1 /> */}
        <Component1 />
      </header>
    </div>
  );
}

export default App;
