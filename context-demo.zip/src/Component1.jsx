
import Component2 from './Component2';
import { useState } from 'react';
import { UserContext } from './user-context';

export default function Component1() {
  
  const [user] = useState("Bhalchandra");

  return (
    <UserContext.Provider value={user}>
      <h1>{`Hello ${user}!`}</h1>
      <Component2 />
    </UserContext.Provider>
  );
}
