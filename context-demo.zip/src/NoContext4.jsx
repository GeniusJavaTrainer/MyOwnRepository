import React from 'react'
import NoContext5 from './NoContext5'

export default function NoContext4(props) {
  return (
    <div>
        <h1>Component 4</h1>
        <NoContext5 user={props.user}/>
    </div>
  )
}
