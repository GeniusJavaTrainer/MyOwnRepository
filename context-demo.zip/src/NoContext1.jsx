import React, { useState } from 'react'
import NoContext2 from './NoContext2'

export default function NoContext1() {
    const [user] = useState("Bhalchandra")
  return (
    <div>
        <h1>Hello {user}</h1>
        <NoContext2 user={user}/>
    </div>
  )
}
