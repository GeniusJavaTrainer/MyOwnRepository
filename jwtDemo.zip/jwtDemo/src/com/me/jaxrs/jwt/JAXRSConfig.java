package com.me.jaxrs.jwt;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.me.jaxrs.jwt.boundary.BooksResource;
import com.me.jaxrs.jwt.filters.JWTAuthFilter;
import com.me.jaxrs.jwt.filters.JWTResponseFilter;

/**
 *
 * Specific to /resources/book
 */
@ApplicationPath("resources")
public class JAXRSConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> clazzes = new HashSet();
        clazzes.add(JWTAuthFilter.class);
        clazzes.add(BooksResource.class);
        clazzes.add(JWTResponseFilter.class);

        return clazzes;
    }
}
