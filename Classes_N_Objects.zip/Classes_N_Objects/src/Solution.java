import java.util.ArrayList;
import java.util.Scanner;

public class Solution {

    public static void main(String[] args) {
        ArrayList<Integer> array[] = null;
        int n;
        
        Scanner scInput = new Scanner(System.in);
        
        n = scInput.nextInt();
        
        for(int i = 0 ; i < n ; i++){
            for(;scInput.hasNext();){
            	
            }
        }
    }
}