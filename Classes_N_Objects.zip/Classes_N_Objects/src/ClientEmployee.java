import java.util.Scanner;

public class ClientEmployee {

	public static void main(String[] args) {
		
		/*
		 * byte, short, int, long = 0
		 * char = \u0000
		 * float = 0.0f
		 * double = 0.0
		 * boolean = false
		 * reference = null
		 */
		Scanner scInput = new Scanner(System.in);
		
		int empid;
		String name;
		float salary;
		
		System.out.print("Enter empid: ");
		empid = Integer.parseInt(scInput.nextLine());
				
		System.out.print("Enter name: ");
		name = scInput.nextLine();
		
		System.out.print("Enter salary: ");
		salary = Float.parseFloat(scInput.nextLine());
				 
		Employee empl = new Employee(empid, name, salary);
		empl.output();
		
		System.out.print("Enter empid: ");
		empid = Integer.parseInt(scInput.nextLine());
				
		System.out.print("Enter name: ");
		name = scInput.nextLine();
		
		System.out.print("Enter salary: ");
		salary = Float.parseFloat(scInput.nextLine());
		
		Employee empNew = new Employee(empid, name, salary);
		empNew.output();
		
		scInput.close();
		
		name = empNew.getName();
		salary = empNew.getSalary();
		
		System.out.println("Before modification:");
		System.out.println(name + " has " + "salary:Rs." + salary);
		
		empNew.setSalary(350000);
		salary = empNew.getSalary();
		
		System.out.println("After modification:");
		System.out.println(name + " has " + "salary:Rs." + salary);
	}
}