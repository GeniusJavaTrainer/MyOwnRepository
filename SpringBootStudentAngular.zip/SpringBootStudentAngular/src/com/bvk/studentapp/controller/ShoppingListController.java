package com.bvk.studentapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bvk.studentapp.model.Student;
import com.bvk.studentapp.service.StudentService;

@RestController
public class ShoppingListController {
	
	@Autowired
	private StudentService service;
	

	@RequestMapping(method=RequestMethod.POST, value="/studentlist/")
	public void addStudentList(@RequestBody Student studentList){
		this.service.addStudent(studentList);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/studentlist/{id}")
	public void deleteStudentList(@PathVariable int id){
		this.service.deleteStudent(id);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/studentlist")
	public void editStudent(@RequestBody Student student){
		this.service.editStudent(student);
	}
	
	@RequestMapping("/studentlist/{id}")
	public Student getStudent(@PathVariable int id){
		return this.service.getStudentById(id);
	}
	
	@RequestMapping("/studentlists")
	public List<Student> getStudentList(){
		return this.service.getAllStudents();
	}
	
	@RequestMapping("/")
	public String hello(){
		return "Hello World";
	}
}