package com.bvk.studentapp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.bvk.studentapp.model.Student;

@Service
public class StudentService {
	
	private List<Student>studentList;
	
		public StudentService(){
			studentList = new ArrayList<>();
			
			studentList.add(new Student(1,"Bandu Khodkar"));
			studentList.add(new Student(2,"Zampya Paranjpe"));
		}
		
		public void addStudent(Student student){
			this.studentList.add(student);
		}
		
		public void editStudent(Student student){
			for (int i = 0 ; i < this.studentList.size() ; i++) {
				Student stu = this.studentList.get(i);
				if(stu.getId() == student.getId()){
					this.studentList.set(i, student);
				}
			}
		}
		
		public void deleteStudent(int studentId){
			Student student = getStudentById(studentId);
			this.studentList.remove(student);
		}
		
		public Student getStudentById(int id){
			return studentList.stream().filter(x->x.getId()==id).findFirst().get();
		}
		
		public List<Student> getAllStudents(){
			return this.studentList;
		}
}