package com.cognizant.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyConfigClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
