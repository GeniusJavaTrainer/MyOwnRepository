package code;

public class TestRunnable {
	public static void main(String[] args) {
		/*// New
		Thread t1 = new Thread(new MultiThreadRunnable(),"FirstThread");
		Thread t2 = new Thread(new MultiThreadRunnable(),"SecondThread");
		
		//Runnable
		t1.start();
		t2.start();*/
		
		Thread t1 = new Thread(new MultiThread(),"FirstThread");
		Thread t2 = new Thread(new MultiThread(),"AnotherThread");
		
		t1.setPriority(Thread.MAX_PRIORITY);
		t2.setPriority(6);
		
		t2.start();
		t1.start();
				
		for(int i = 1 ; i <= 10 ; i++){
			System.out.println("In " + Thread.currentThread().getName() +" "+ i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}