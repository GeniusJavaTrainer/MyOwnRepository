package com.capgemini.bank.utility;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.bank.exception.ProductException;

public class DbConnection {
	public static Connection getConnection() throws ProductException {
		Connection conn = null;

		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			conn = ds.getConnection();
		}

		catch (SQLException e) {
			throw new ProductException("SQL Error:"+e.getMessage());
		} catch (NamingException e) {
			throw new ProductException("message from DB/NamingExc:"
					+ e.getMessage());
		}
		return conn;
	}
}
