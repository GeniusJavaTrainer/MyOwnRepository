package com.capgemini.bank.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.bank.dto.Product;
import com.capgemini.bank.exception.ProductException;
import com.capgemini.bank.service.ProductService;
import com.capgemini.bank.service.ProductServiceImpl;

/**
 * Servlet implementation class BankController
 */
@WebServlet("*.obj")
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProductService productService = new ProductServiceImpl();
						
		String target = "";

		List<Product>productList = null;
		
		HttpSession session = request.getSession();
		// Object creations
		
		String targetPurchase = "purchaseItem.jsp";
		String targetSuccess = "TransactionSuccess.jsp";
		String targetError = "CustomerError.jsp";
		String targetProduct = "productDetails.jsp";

		String path = request.getServletPath().trim();
		
		String name = request.getParameter("customerName");
		
		switch (path) {

		case "/getRecords.obj":
			try{
				productList = productService.getProducts();
				session.setAttribute("productList", productList);
				target = targetProduct;
			}catch(ProductException be){
				session.setAttribute("errorMessage", be.getMessage());
				target = targetError;
			}
			break;
		case "/purchase.obj":
			String productName = request.getParameter("productname");
			String quantity = request.getParameter("qty");
			String price = request.getParameter("price");
			
			session.setAttribute("productName", productName);
			session.setAttribute("quantity", quantity);
			session.setAttribute("price", price);
			
			target = targetPurchase;
			break;

		case "/update.obj":
			double amount = Double.parseDouble(request.getParameter("amount"));
			String accountNum = session.getAttribute("accountNo").toString();
			transactionBean.setAccountNumber(accountNum);
			transactionBean.setTransactionAmount(amount);
			
			try {
				productService.debit(transactionBean);
				target = targetSuccess;
			} catch (ProductException be) {
				session.setAttribute("errorMessage", be.getMessage());
				target = targetError;
			}
			break;
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}