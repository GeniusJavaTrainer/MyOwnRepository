package com.capgemini.bank.service;

import java.util.List;

import com.capgemini.bank.dto.Product;
import com.capgemini.bank.exception.ProductException;

public interface ProductService {
	public List<Product> getProducts() throws ProductException;
	public boolean update(String productName) throws ProductException;
}