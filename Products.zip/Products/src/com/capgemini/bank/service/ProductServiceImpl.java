package com.capgemini.bank.service;

import java.util.List;

import com.capgemini.bank.dao.ProductDAO;
import com.capgemini.bank.dao.ProductDAOImpl;
import com.capgemini.bank.dto.Product;
import com.capgemini.bank.exception.ProductException;

public class ProductServiceImpl implements ProductService {
	private ProductDAO productDAO = new ProductDAOImpl();
	
	@Override
	public List<Product> getProducts() throws ProductException {
		List<Product>productList = productDAO.getProducts();
		return productList;
	}

	@Override
	public boolean update(String productName) throws ProductException {
		return productDAO.update(productName);
	}
}