package com.capgemini.bank.dao;

public interface IQueryMapperProduct {
	public static final String GET_RECORDS = "SELECT * FROM product"
			+ " WHERE quantity_available > 0";
	
	public static final String UPDATE = "UPDATE product SET quantity_available = quantity_available - 1"
			+ " WHERE product_name = ?";
}