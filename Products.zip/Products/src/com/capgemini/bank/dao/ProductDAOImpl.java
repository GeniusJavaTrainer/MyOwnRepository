package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.bank.dto.Product;
import com.capgemini.bank.exception.ProductException;
import com.capgemini.bank.utility.DbConnection;

public class ProductDAOImpl implements ProductDAO {

	@Override
	public List<Product> getProducts() throws ProductException {
		List<Product>productList = new ArrayList<>();
		
		try(Connection connProduct = DbConnection.getConnection();
		PreparedStatement pstProduct = 
		connProduct.prepareStatement(IQueryMapperProduct.GET_RECORDS);){
						
			ResultSet rsProduct = pstProduct.executeQuery();
			
			while(rsProduct.next()){
				Product product = new Product();
				product.setProductName(rsProduct.getString("product_name"));
				product.setFactoryLocation(rsProduct.getString("factory_location"));
				product.setQuantityAvailable(rsProduct.getInt("quantity_available"));
				product.setPrice(rsProduct.getDouble("price"));
				product.setManufacturingDate(rsProduct.getDate("mfg_date"));
				
				productList.add(product);
			}
		}catch(SQLException se){
			throw new ProductException(se.getMessage());
		}
		return productList;
	}

	@Override
	public boolean update(String productName) throws ProductException {
		boolean isUpdated = false;
		try(Connection connProduct = DbConnection.getConnection();
				PreparedStatement pstProduct = 
				connProduct.prepareStatement(IQueryMapperProduct.UPDATE);){
					pstProduct.setString(1, productName);
					
					int records = pstProduct.executeUpdate();
					
					if(records > 0){
						isUpdated = true;
					}
				}catch(SQLException se){
					throw new ProductException(se.getMessage());
				}
		return isUpdated;
	}
}