package com.capgemini.bank.dao;

import java.util.List;

import com.capgemini.bank.dto.Product;
import com.capgemini.bank.exception.ProductException;

public interface ProductDAO {
	public List<Product> getProducts() throws ProductException;
	public boolean update(String productName) throws ProductException;
}