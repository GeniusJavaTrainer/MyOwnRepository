  /* 
   package body
  */
create or replace package body pkg1 is 

procedure prc1(x number,y number) is
    z number;
 begin
    z:=x+y;
    dbms_output.put_line(' Addition is : '||z);
 end prc1;

procedure prc1(x number,y number,z number) is
    k number;
 begin
    k:=x*y-z;
    dbms_output.put_line(' Result of x*y-z is : '||k);
 end prc1;

function fun1(x number) return number is
   z number;
 begin
   z:=x*x;
   return z;
 end fun1;

end pkg1;
/