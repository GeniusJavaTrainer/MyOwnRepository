 /* package specification */

create or replace package pkg1 is 

  procedure prc1(x number,y number);
  procedure prc1(x number,y number,z number);
  function fun1(x number) return number;

end pkg1;
/