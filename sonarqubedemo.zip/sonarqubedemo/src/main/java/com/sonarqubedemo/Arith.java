package com.sonarqubedemo;

public class Arith {
	public int add(int first, int second){
		return first + second;
	}
	
	public int sub(int first, int second){
		return first - second;
	}
}
