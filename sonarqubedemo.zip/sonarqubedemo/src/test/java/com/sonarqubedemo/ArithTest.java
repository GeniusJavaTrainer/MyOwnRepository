package com.sonarqubedemo;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ArithTest {
	private Arith arith;
	
	@Before
	public void setup(){
		arith = new Arith();
	}
	
	@After
	public void tearDown(){
		arith = null;
	}
	
	@Test
	public final void testAdd() {
		assertTrue(arith.add(10, 20) == 30);
	}

}
