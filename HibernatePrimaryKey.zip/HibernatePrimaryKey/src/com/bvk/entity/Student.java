package com.bvk.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_primarykey_anno")
public class Student implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3123708389432319453L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int rollno;
	private String name;
	
	public Student() {
		super();
	}

	public Student(int rollno, String name) {
		super();
		this.rollno = rollno;
		this.name = name;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + "]";
	}
}