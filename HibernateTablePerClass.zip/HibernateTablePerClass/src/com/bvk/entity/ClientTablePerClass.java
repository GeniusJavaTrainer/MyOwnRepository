package com.bvk.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ClientTablePerClass {

	public static void main(String[] args) {
		SessionFactory sf = new Configuration().configure().
				addAnnotatedClass(com.bvk.entity.Employee.class).
				addAnnotatedClass(com.bvk.entity.Manager.class).
				buildSessionFactory();
		
		Session session = sf.openSession();
		
		Transaction tx = null;
		
		try{
			Employee employee = new Employee(1, "bvk", 300000);
			Manager manager = new Manager("Marketing");
			
			manager.setEmpid(2);
			manager.setName("svk");
			manager.setSalary(250000);
			
			tx = session.beginTransaction();
			
			session.save(employee);
			session.save(manager);
			
			tx.commit();
		}catch(Exception e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}	}
}