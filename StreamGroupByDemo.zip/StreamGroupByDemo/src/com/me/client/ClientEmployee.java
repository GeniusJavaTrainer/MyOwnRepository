package com.me.client;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.me.entity.Employee;

public class ClientEmployee {

	public static void main(String[] args) {
		List<Employee> employees = List.of(
	            new Employee(1,"Alice", "IT", "New York", 120000, true),
	            new Employee(2,"Bob", "Finance", "Chicago", 95000, true),
	            new Employee(3,"Carol", "IT", "Chicago", 110000, false),
	            new Employee(4,"David", "HR", "New York", 85000, true),
	            new Employee(5,"Eva", "Finance", "New York", 105000, true),
	            new Employee(6,"Frank", "IT", "Boston", 125000, true)
	        );

	        // 1. Group employees by department
	        Map<String, List<Employee>> byDepartment =
	            employees.stream()
	                     .collect(Collectors.groupingBy(Employee::getDepartment));

	        // 2. Group names by department
	        Map<String, List<String>> namesByDepartment =
	            employees.stream()
	                     .collect(Collectors.groupingBy(
	                         Employee::getDepartment,
	                         Collectors.mapping(
	                             Employee::getName,
	                             Collectors.toList()
	                         )
	                     ));

	        // 3. Count employees in each department
	        Map<String, Long> countByDepartment =
	            employees.stream()
	                     .collect(Collectors.groupingBy(
	                         Employee::getDepartment,
	                         Collectors.counting()
	                     ));

	        // 4. Calculate average salary by department
	        Map<String, Double> averageSalaryByDepartment =
	            employees.stream()
	                     .collect(Collectors.groupingBy(
	                         Employee::getDepartment,
	                         Collectors.averagingInt(Employee::getSalary)
	                     ));

	        // 5. Calculate total salary by department
	        Map<String, Integer> totalSalaryByDepartment =
	            employees.stream()
	                     .collect(Collectors.groupingBy(
	                         Employee::getDepartment,
	                         Collectors.summingInt(Employee::getSalary)
	                     ));

	        // 6. Find the highest-paid employee in each department
	        Map<String, Optional<Employee>> highestPaidByDepartment =
	            employees.stream()
	                     .collect(Collectors.groupingBy(
	                         Employee::getDepartment,
	                         Collectors.maxBy(
	                             Comparator.comparingInt(Employee::getSalary)
	                         )
	                     ));

	        // 7. Group employees by department and then by city
	        Map<String, Map<String, List<Employee>>> byDepartmentAndCity =
	            employees.stream()
	                     .collect(Collectors.groupingBy(
	                         Employee::getDepartment,
	                         Collectors.groupingBy(Employee::getCity)
	                     ));

	        // 8. Partition employees into active and inactive groups
	        Map<Boolean, List<Employee>> byActiveStatus =
	            employees.stream()
	                     .collect(Collectors.partitioningBy(Employee::isActive));

	        // 9. Group by department into a Set
	        Map<String, Set<String>> citiesByDepartment =
	            employees.stream()
	                     .collect(Collectors.groupingBy(
	                         Employee::getDepartment,
	                         Collectors.mapping(
	                             Employee::getCity,
	                             Collectors.toSet()
	                         )
	                     ));

	        // 10. Group by department while preserving insertion order
	        Map<String, List<Employee>> orderedByDepartment =
	            employees.stream()
	                     .collect(Collectors.groupingBy(
	                         Employee::getDepartment,
	                         LinkedHashMap::new,
	                         Collectors.toList()
	                     ));

	        System.out.println(byDepartment);
	        System.out.println(namesByDepartment);
	        System.out.println(countByDepartment);
	        System.out.println(averageSalaryByDepartment);
	        System.out.println(totalSalaryByDepartment);
	        System.out.println(highestPaidByDepartment);
	        System.out.println(byDepartmentAndCity);
	        System.out.println(byActiveStatus);
	        System.out.println(citiesByDepartment);
	        System.out.println(orderedByDepartment);
	}

}
