package com.me.client;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.me.entity.Employee2;

public class ClientMapGrouping {

	public static void main(String[] args) {
		// Example 1: Group map entries by their values
        Map<String, Integer> scores = new LinkedHashMap<>();
        scores.put("Alice", 90);
        scores.put("Bob", 80);
        scores.put("Carol", 90);
        scores.put("David", 70);
        scores.put("Eva", 80);

        Map<Integer, List<String>> usersByScore =
                scores.entrySet()
                      .stream()
                      .collect(Collectors.groupingBy(
                              Map.Entry::getValue,
                              LinkedHashMap::new,
                              Collectors.mapping(
                                      Map.Entry::getKey,
                                      Collectors.toList()
                              )
                      ));

        System.out.println(usersByScore);
        // {90=[Alice, Carol], 80=[Bob, Eva], 70=[David]}


        // Example 2: Count how many map entries have each value
        Map<Integer, Long> countByScore =
                scores.entrySet()
                      .stream()
                      .collect(Collectors.groupingBy(
                              Map.Entry::getValue,
                              Collectors.counting()
                      ));

        System.out.println(countByScore);
        // {70=1, 80=2, 90=2}


        // Example 3: Group map keys by the first character of the key
        Map<String, Integer> prices = new LinkedHashMap<>();
        prices.put("Apple", 3);
        prices.put("Avocado", 5);
        prices.put("Banana", 2);
        prices.put("Blueberry", 6);
        prices.put("Carrot", 4);

        Map<Character, List<String>> productsByInitial =
                prices.entrySet()
                      .stream()
                      .collect(Collectors.groupingBy(
                              entry -> entry.getKey().charAt(0),
                              LinkedHashMap::new,
                              Collectors.mapping(
                                      Map.Entry::getKey,
                                      Collectors.toList()
                              )
                      ));

        System.out.println(productsByInitial);
        // {A=[Apple, Avocado], B=[Banana, Blueberry], C=[Carrot]}


        // Example 4: Group entries by a category derived from their values
        Map<String, List<String>> usersByPerformance =
                scores.entrySet()
                      .stream()
                      .collect(Collectors.groupingBy(
                              entry -> performanceCategory(entry.getValue()),
                              LinkedHashMap::new,
                              Collectors.mapping(
                                      Map.Entry::getKey,
                                      Collectors.toList()
                              )
                      ));

        System.out.println(usersByPerformance);
        // {Excellent=[Alice, Carol], Good=[Bob, Eva], Needs Improvement=[David]}


        // Example 5: Group values and calculate totals
        Map<String, Integer> salesByStore = new LinkedHashMap<>();
        salesByStore.put("East-Store-1", 12000);
        salesByStore.put("East-Store-2", 18000);
        salesByStore.put("West-Store-1", 15000);
        salesByStore.put("West-Store-2", 22000);

        Map<String, Integer> salesByRegion =
                salesByStore.entrySet()
                            .stream()
                            .collect(Collectors.groupingBy(
                                    entry -> regionOf(entry.getKey()),
                                    LinkedHashMap::new,
                                    Collectors.summingInt(Map.Entry::getValue)
                            ));

        System.out.println(salesByRegion);
        // {East=30000, West=37000}


        // Example 6: Group the values of a map by an object property
        Map<String, Employee2> employees = new LinkedHashMap<>();
        employees.put("E001", new Employee2(
                "Alice", "IT", "New York", 120000));
        employees.put("E002", new Employee2(
                "Bob", "Finance", "Chicago", 95000));
        employees.put("E003", new Employee2(
                "Carol", "IT", "Chicago", 110000));
        employees.put("E004", new Employee2(
                "David", "HR", "New York", 85000));

        Map<String, List<String>> namesByDepartment =
                employees.entrySet()
                         .stream()
                         .collect(Collectors.groupingBy(
                                 entry -> entry.getValue().getDepartment(),
                                 LinkedHashMap::new,
                                 Collectors.mapping(
                                         entry -> entry.getValue().getName(),
                                         Collectors.toList()
                                 )
                         ));

        System.out.println(namesByDepartment);
        // {IT=[Alice, Carol], Finance=[Bob], HR=[David]}


        // Example 7: Nested grouping: department, then city
        Map<String, Map<String, List<String>>> namesByDepartmentAndCity =
                employees.entrySet()
                         .stream()
                         .collect(Collectors.groupingBy(
                                 entry -> entry.getValue().getDepartment(),
                                 LinkedHashMap::new,
                                 Collectors.groupingBy(
                                         entry -> entry.getValue().getCity(),
                                         LinkedHashMap::new,
                                         Collectors.mapping(
                                                 entry -> entry.getValue().getName(),
                                                 Collectors.toList()
                                         )
                                 )
                         ));

        System.out.println(namesByDepartmentAndCity);
        // {
        //   IT={New York=[Alice], Chicago=[Carol]},
        //   Finance={Chicago=[Bob]},
        //   HR={New York=[David]}
        // }
    }

    private static String performanceCategory(int score) {
        if (score >= 90) {
            return "Excellent";
        }
        if (score >= 80) {
            return "Good";
        }
        return "Needs Improvement";
    }

    private static String regionOf(String storeCode) {
        return storeCode.substring(0, storeCode.indexOf('-'));
    }	

	

}
