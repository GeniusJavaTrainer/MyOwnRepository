package com.me.entity;

public class Employee2 {
	private final String name;
    private final String department;
    private final String city;
    private final int salary;

    public Employee2(String name, String department, String city, int salary) {
        this.name = name;
        this.department = department;
        this.city = city;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public String getCity() {
        return city;
    }

    public int getSalary() {
        return salary;
    }

	@Override
	public String toString() {
		return "Employee2 [name=" + name + ", department=" + department + ", city=" + city + ", salary=" + salary + "]";
	}
   
}
