package com.me.entity;

public class Employee {
	private final int empid;
	private final String name;
    private final String department;
    private final String city;
    private final int salary;
    private final boolean active;

    public Employee(int empid, String name, String department, String city,
             int salary, boolean active) {
    	this.empid = empid;
        this.name = name;
        this.department = department;
        this.city = city;
        this.salary = salary;
        this.active = active;
    }

    
    public int getEmpid() {return empid;}
    public String getName() { return name; }
    public String getDepartment() { return department; }
    public String getCity() { return city; }
    public int getSalary() { return salary; }
    public boolean isActive() { return active; }

    @Override
    public String toString() {
        return name + " ($" + salary + ")";
    }
}