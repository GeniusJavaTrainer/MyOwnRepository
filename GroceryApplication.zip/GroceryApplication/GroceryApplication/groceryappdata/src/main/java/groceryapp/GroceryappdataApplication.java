package groceryapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroceryappdataApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroceryappdataApplication.class, args);
	}
}