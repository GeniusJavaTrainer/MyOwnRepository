package com.me.function;

public class RollDice {
	public static int rollDice(){
		return (int)(Math.random()*6 + 1);
	}
}
