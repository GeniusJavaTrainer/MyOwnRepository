package com.me.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.me.entity.Address;
import com.me.entity.Employee;

/**
 * Servlet implementation class ELServlet
 */
public class ELServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ELServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher requestDispatch = request.getRequestDispatcher("el.jsp");
		
		Cookie cookie = new Cookie("myCookie", "Imp");
		cookie.setMaxAge(-1);
		
		response.addCookie(cookie);
		
		Address address = new Address("M. G. Road", "Mumbai", "Maharashtra");
		Employee employee = new Employee(1, "abc", address, 100000);
		
		request.setAttribute("message", "I'm from request");
		request.setAttribute("employee", employee);
		request.getSession().setAttribute("message", "I'm from Session");
		getServletContext().setAttribute("message", "I'm from ServletContext");
		
		requestDispatch.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
