showMapped = () => {
    const numbers = [10, 34, 56, 89, 52];

    const squared = numbers.map((x) => {
        if (x % 2 == 0) {
            return x * 2;
        } else {
            return x;
        }
    }
    );

    let showNumbers =
        "<table class='table table-striped'>" +
        "<thead>" +
        "<tr>" +
        "<th>Squared numbers</th>" +
        "</tr>" +
        "</thead><tbody>";

    for (i = 0; i < squared.length; i++) {
        showNumbers += "<tr><td>" + squared[i] + "</td></tr>";
    }

    showNumbers += "</tbody></table>";

    document.getElementById("arrays").innerHTML = showNumbers;
}