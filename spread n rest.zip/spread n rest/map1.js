showMapped = () => {
    const numbers = [10, 34, 56, 89, 52];

    const squared = numbers.map(x => x * 2);

    let showNumbers =
        "<table class='table table-striped'>" +
        "<thead>" +
        "<tr>" +
        "<th>Squared numbers</th>" +
        "</tr>" +
        "</thead><tbody>";

    for (i = 0; i < squared.length; i++) {
        showNumbers += "<tr><td>" + squared[i] + "</td></tr>";
    }

    showNumbers += "</tbody></table>";

    document.getElementById("arrays").innerHTML = showNumbers;
}