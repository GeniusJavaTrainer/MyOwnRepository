package com.bvk.bo;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.bvk.dao.StudentDAO;
import com.bvk.entity.StudentTO;
@Service
public class StudentBOImpl implements StudentBO{
	
	public String calculate(StudentTO studentTO){
		int m1 = studentTO.getM1();
		int m2 = studentTO.getM2();
		
		String message = null;
		
		int total = (m1+m2);
		float percent = total/2.0f;
		
		studentTO.setTotal(total);
		studentTO.setPercent(percent);
		
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		try{
		StudentDAO studentDAO = (StudentDAO)appContext.getBean("studentDAO");
		
		int status = studentDAO.insertStudent(studentTO);
		
		if(status == 1){
			message = "Record inserted successfully...";
		}
		
		}catch(ClassNotFoundException cnfe){
			message = cnfe.getMessage();
		}catch(SQLException se){
			message = se.getMessage();
		}
		return message;
	}
}