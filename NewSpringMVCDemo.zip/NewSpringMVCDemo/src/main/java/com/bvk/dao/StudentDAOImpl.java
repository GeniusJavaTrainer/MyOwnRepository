package com.bvk.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.bvk.entity.StudentTO;

//@SuppressWarnings("deprecation")
@Repository
public class StudentDAOImpl implements StudentDAO {

/*private SimpleJdbcTemplate  simpleJdbcTemplate;
	
	public void setDataSource(DataSource dataSource){
		this.simpleJdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}*/
	
	@Override
	public int insertStudent(StudentTO studentTO) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		String query = "INSERT INTO stud VALUES(?,?,?,?,?,?)";
		Connection connStudent = null;
		PreparedStatement pst = null;
		
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username="postgres";
		String password = "postgres";
		String driver = "org.postgresql.Driver";
		
		int records = 0;
		
		int rollNo = studentTO.getRollNo();
		String name = studentTO.getName();
		int m1 = studentTO.getM1();
		int m2 = studentTO.getM2();
		int total = studentTO.getTotal();
		float percent = studentTO.getPercent();
		
		Class.forName(driver);
		
		connStudent = DriverManager.getConnection(url, username, password);
		pst = connStudent.prepareStatement(query);
		
		pst.setInt(1, rollNo);
		pst.setString(2, name);
		pst.setInt(3, m1);
		pst.setInt(4, m2);
		pst.setInt(5, total);
		pst.setFloat(6, percent);
		
		records = pst.executeUpdate();
		/*simpleJdbcTemplate.update(query,rollNo,name,m1,m2,total,percent);*/
		return records;
	}
}