package com.bvk.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bvk.bo.StudentBO;
import com.bvk.entity.StudentTO;

@Controller
public class RequestAttender {
	@RequestMapping("/attender.htm")
	public ModelAndView requestHandler(HttpServletRequest request,HttpServletResponse response) throws Exception {
	
	ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
	
	ModelAndView modelAndView = new ModelAndView("result");//view
	//   /WEB-INF/pages/result.jsp
	int rollNo = Integer.parseInt(request.getParameter("rollno"));
	String name = request.getParameter("name");
	int m1 = Integer.parseInt(request.getParameter("m1"));
	int m2 = Integer.parseInt(request.getParameter("m2"));
	
	StudentTO studentTO = new StudentTO(rollNo, name, m1, m2);
	//model
	String message = "Record inserted successfully.";
	
	StudentBO studentBO = (StudentBO)appContext.getBean("studentBO");
	
	message = studentBO.calculate(studentTO);
	
	if(message == null){
		message="Unable to insert record";
	}
	
	modelAndView.addObject("message", message);
	return modelAndView;	 
	}	
}