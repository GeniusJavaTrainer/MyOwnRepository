import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { LoginServiceService } from './login-service.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  isUserValid: boolean = false;
  jwtToken: string;

  form = new FormGroup({
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
    //    percent: new FormControl('', Validators.required),
    //    country: new FormControl('', Validators.required)
  });

  constructor(private httpservice: LoginServiceService, private http: HttpClient) {

  }
  get f() {
    return this.form.controls;
  }

  /*submit() {
        this.http.get('http://localhost:8080/student/api/student').subscribe(
          response => {
            this.students = response
            //        console.log(this.students);
          },
          error => {
            console.log(error);
          });
    this.httpservice.delete(this.form);
    //console.log(this.students)
  }*/

  submit1() {
    /*    this.rollno = this.form.get('rollno').value
        this.http.get('http://localhost:8080/student/api/student/seek/' + this.rollno).subscribe(
          response => {
            this.students = response
            //        console.log(this.students);
          },
          error => {
            console.log(error);
          });
        //    this.students = this.httpservice.getAll();
        console.log(this.students)*/
    this.jwtToken = this.httpservice.post(this.form)
    console.log(this.jwtToken.toString())
    /*.subscribe(
      response => {
        this.jwtToken = response;
      },
      error => {
        this.jwtToken = error;
        console.log("Error: " + error);
      }).toString();
    console.log(this.jwtToken)*/
  }
}