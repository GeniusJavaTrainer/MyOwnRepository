import { Injectable } from '@angular/core';
import { HttpHeaders, HttpParams, HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {
  students: Object;
  jwtToken: string;
  constructor(private http: HttpClient) { }
  sendData() {
    return this.jwtToken;
  }
  post(formData) {
    var isUserValid: boolean = false;
    //    var email = formData.get('email').value
    //    var password = formData.get('password').value

    const body = new HttpParams()
      .set('email', formData.get('email').value)
      .set('password', formData.get('password').value)

    const headers = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });


    /*this.http.get('http://localhost:8080/user/login' + email + '/' + password).subscribe(
      response => {
        isUserValid = true;
        console.log(response);
      },
      error => {
        isUserValid = false;
        console.log(error);
      });*/

    return this.http.post('http://localhost:8080/user/login', body.toString(), { headers: headers, responseType: 'text' }).toString()
  }

  put(formData) {
    const body = new HttpParams()
      .set('rollno', formData.get('rollno').value)
      .set('name', formData.get('name').value)
      .set('percent', formData.get('percent').value)
      .set('country', formData.get('country').value)

    const headers = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });


    this.http.put('http://localhost:8080/student/api/student/update', body.toString(), { headers: headers }).subscribe(
      response => {
        console.log(response);
      },
      error => {
        console.log(error);
      });
  }

  delete(formData) {
    this.http.delete('http://localhost:8080/student/api/student/delete/' + formData.get('rollno').value).subscribe(
      response => {
        console.log(response);
      },
      error => {
        console.log(error);
      });
  }

  getAll() {
    this.http.get('http://localhost:8080/student/api/student').subscribe(
      response => {
        this.students = response
        console.log(this.students);
      },
      error => {
        console.log(error);
      });
    return this.students;
  }

  /*      getOne(formData) {
          this.http.get('http://localhost:8080/student/api/student/insert').subscribe(
            response => {
              console.log(response);
            },
            error => {
              console.log(error);
            });
        }*/}
