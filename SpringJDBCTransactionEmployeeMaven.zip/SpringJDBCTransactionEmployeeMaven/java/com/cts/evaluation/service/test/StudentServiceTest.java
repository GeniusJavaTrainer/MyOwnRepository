package com.cts.evaluation.service.test;

import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cts.evaluation.service.StudentService;
import com.cts.evaluation.vo.Student;

/**
 * @author 769890
 *
 */

public class StudentServiceTest {
	private Student student;
		
	/**
	 * @throws java.lang.Exception
	 */
	
	@Before
	public void setUp() throws Exception {
		HashMap<Integer, Float>records = new HashMap<Integer, Float>();
		
		records.put(1, 90.89f);
		records.put(2, 100.00f);
		records.put(3, 89.89f);
		records.put(4, 101.89f);
		
		student = new Student();
		student.setRecord(records);
	}

	/**
	 * @throws java.lang.Exception
	 */
	
	@After
	public void tearDown() throws Exception {
		student = null;
	}

	/**
	 * Test method for
	 * {@link com.cts.evaluation.service.StudentService#validateRecord(HashMap<Integer, Float>)}.
	 */
	
	@Test
	public final void testValidateRecord(){
		Set<Map.Entry<Integer, Float>>invalidRecords = null;
		HashMap<Integer, Float>records = student.getRecord();
		
		invalidRecords = StudentService.validateRecord(records);
		assertTrue( invalidRecords.size() == 1);
	}
}