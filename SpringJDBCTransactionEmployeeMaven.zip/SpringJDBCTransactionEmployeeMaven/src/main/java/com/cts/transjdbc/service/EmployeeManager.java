package com.cts.transjdbc.service;

import com.cts.transjdbc.model.Employee;

public interface EmployeeManager {
	public void createEmployee(Employee employee);
	public Employee getEmployee(int id);
}
