package com.cts.transjdbc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.cts.transjdbc.model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public void create(Employee employee) {
		String queryEmployee = "insert into Emp1 values (?,?,?)";
		String queryAddress = "insert into Address (id, address,country) values (?,?,?)";

		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

		jdbcTemplate.update(queryEmployee, new Object[] { employee.getId(),
				employee.getName(), employee.getSalary() });
		System.out.println("Inserted into Employee Table Successfully");
		/*
		 * jdbcTemplate.update(queryAddress, new Object[] { employee.getId(),
		 * employee.getAddress().getAddress(), employee.getAddress().getCountry() });
		 * System.out.println("Inserted into Address Table Successfully");
		 */	}

	public Employee getEmployee(int id) {
		Employee employeeFound = null;
		
		String query = "SELECT * FROM emp1 WHERE id = ?";
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		
		employeeFound = (Employee)jdbcTemplate.queryForObject(query, new Object[]{
				id},
				new RowMapper(){
			public Object mapRow(ResultSet resultSet, int rowNum) throws SQLException{
				int id = resultSet.getInt("id");
				String name = resultSet.getString("name");
				float salary = resultSet.getFloat("salary");
				
				Employee employee = new Employee(id, name, salary);
				return employee;
			}
		}
		);
		return employeeFound;
	}

}