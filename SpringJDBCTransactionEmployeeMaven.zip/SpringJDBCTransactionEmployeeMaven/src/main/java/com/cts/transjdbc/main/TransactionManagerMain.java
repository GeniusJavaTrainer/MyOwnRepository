package com.cts.transjdbc.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.transjdbc.model.Employee;
import com.cts.transjdbc.service.EmployeeManager;

public class TransactionManagerMain {

	public static void main(String[] args) {
		
		//SkeletonValidator sv = new SkeletonValidator();
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
				"spring.xml");

		EmployeeManager employeeManager = (EmployeeManager)ctx.getBean("employeeManager");

		Employee employee = createDummyEmployee();
		employeeManager.createEmployee(employee);

		ctx.close();
	}

	private static Employee createDummyEmployee() {
		Employee employee = new Employee();
		employee.setId(100);
		employee.setName("Shashank");
		employee.setSalary(98000.89f);
		/*
		 * Address address = new Address(); address.setId(2);
		 * address.setCountry("India");
		 * 
		 * address.setAddress("Ram Nagar"); employee.setAddress(address);
		 */
		return employee;
	}
}