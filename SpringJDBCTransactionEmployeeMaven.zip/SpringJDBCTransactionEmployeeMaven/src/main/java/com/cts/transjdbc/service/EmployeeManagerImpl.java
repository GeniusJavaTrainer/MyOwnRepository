package com.cts.transjdbc.service;

import org.springframework.transaction.annotation.Transactional;

import com.cts.transjdbc.dao.EmployeeDAO;
import com.cts.transjdbc.model.Employee;

public class EmployeeManagerImpl implements EmployeeManager {

	private EmployeeDAO employeeDAO;

	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	@Transactional
	public void createEmployee(Employee cust) {
		employeeDAO.create(cust);
	}

	@Transactional
	public Employee getEmployee(int id) {
		return employeeDAO.getEmployee(id);
	}
}
