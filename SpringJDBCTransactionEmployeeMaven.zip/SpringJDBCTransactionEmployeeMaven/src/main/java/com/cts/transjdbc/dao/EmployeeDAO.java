package com.cts.transjdbc.dao;

import com.cts.transjdbc.model.Employee;

public interface EmployeeDAO {

	public void create(Employee student);
	public Employee getEmployee(int id);
}