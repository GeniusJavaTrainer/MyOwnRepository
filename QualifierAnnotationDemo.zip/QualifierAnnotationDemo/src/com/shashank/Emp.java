package com.shashank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
//bean id is emp as class name is Emp, its
//unqualified name is emp.

public class Emp implements EmpInterface {

	private int empid;
	private String name;
	@Autowired
	private Date dob1;
	@Autowired(required=false)
	//@Qualifier("add")
	private Address add1;
	private float salary;
	
	public Emp(){
		empid = 88;
		name = new String("Naren");
		salary=88000;
	}
	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Date getDob1() {
		return dob1;
	}

	
	public void setDob1(Date dob) {
		this.dob1 = dob;
		System.out.println("Date Set");
	}


	public Address getAdd1() {
		return add1;
	}

	
	public void setAdd1(Address add1) {
		this.add1= add1;
		System.out.println("Address Set");
	}


	public float getSalary() {
		return salary;
	}


	public void setSalary(float salary) {
		this.salary = salary;
	}


	@Override
	public void printIt() {
		// TODO Auto-generated method stub
		System.out.println("Employee Id: " + empid);
		System.out.println("Employee name: " + name);
		System.out.println("Date of Birth: " + dob1);
		System.out.println("Address: " + add1);
		System.out.println("Salary: " + salary);
	}
}