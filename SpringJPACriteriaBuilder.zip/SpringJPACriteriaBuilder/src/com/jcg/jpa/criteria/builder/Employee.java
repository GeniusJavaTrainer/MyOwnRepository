package com.jcg.jpa.criteria.builder;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {

	@Id
	@GeneratedValue(strategy= GenerationType.AUTO) 	
	private int emp_id;
	private double emp_salary;
	private String emp_name, emp_desig;

	public Employee( ) {
		super();
	}

	public Employee(int eid, String ename, double esalary, String edesig) {
		super( );
		this.emp_id = eid;
		this.emp_name = ename;
		this.emp_salary = esalary;
		this.emp_desig = edesig;
	}

	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public double getEmp_salary() {
		return emp_salary;
	}

	public void setEmp_salary(double emp_salary) {
		this.emp_salary = emp_salary;
	}

	public String getEmp_desig() {
		return emp_desig;
	}

	public void setEmp_desig(String emp_desig) {
		this.emp_desig = emp_desig;
	}

	public String toString() {
		return "Id?= " + emp_id + ", Name?= " + emp_name + ", Designation?= " + emp_desig + ", Salary?= " + emp_salary;
	}
}