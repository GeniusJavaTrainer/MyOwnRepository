package com.bhalchandra.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bhalchandra.entity.CustomerTO;
import com.bhalchandra.service.CustomerService;

public class ClientDBOperations2 {

	public static void main(String[] args) {

		int custId = 0;
		String name = null;
		String address = null;
		
		CustomerTO customerTO = null;
		
		CustomerService customerService = null;
		
		Scanner scCustomer = new Scanner(System.in);
		
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		customerService = (CustomerService)appContext.getBean("customerService");
		
				System.out.print("Enter Customer ID: ");
				custId = Integer.parseInt(scCustomer.nextLine());
				
				System.out.print("Enter Customer Name: ");
				name = scCustomer.nextLine();
				
				System.out.print("Enter Customer Address: ");
				address = scCustomer.nextLine();
				
				customerTO = new CustomerTO(custId, name, address);
				String message = customerService.insertRecord(customerTO);
				System.out.println(message);
				
				scCustomer.close();
	}
}