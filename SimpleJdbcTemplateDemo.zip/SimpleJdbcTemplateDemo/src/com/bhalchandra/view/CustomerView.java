package com.bhalchandra.view;

public class CustomerView {
/*	public int prepareView(){
		int choice = 0;
		
		int custId = 0;
		String name = null;
		String address = null;
		
		Scanner scCustomer = new Scanner(System.in);
		
		System.out.println("Following is the choice:");
		System.out.println("1. Insert");
		System.out.println("2. Insert using procedure");
		System.out.println("3. Update");
		System.out.println("4. Delete");
		System.out.println("5. View");
		System.out.println("0. Exit");
			
		choice = Integer.parseInt(scCustomer.nextLine());
		
	}*/
}