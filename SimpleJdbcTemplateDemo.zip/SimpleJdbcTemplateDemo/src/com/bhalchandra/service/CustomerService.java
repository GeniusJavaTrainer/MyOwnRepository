package com.bhalchandra.service;

import com.bhalchandra.entity.CustomerTO;

public interface CustomerService {
		String insertRecord(CustomerTO customer);
}
