package com.bhalchandra.service;

import org.springframework.dao.DataAccessException;

import com.bhalchandra.dao.Customer;
import com.bhalchandra.entity.CustomerTO;

public class CustomerServiceImpl implements CustomerService {
	private Customer customerDAO;
	
	public CustomerServiceImpl() {
		super();
	}

	public Customer getCustomerDAO() {
		return customerDAO;
	}

	public void setCustomerDAO(Customer customerDAO) {
		this.customerDAO = customerDAO;
	}


	@Override
	public String insertRecord(CustomerTO customer) {
		String message = null;
		
		try{
		message = customerDAO.insertCustomer(customer);
		}catch(DataAccessException dae){
			message = dae.getMessage();
		}
		return message;
	}
}