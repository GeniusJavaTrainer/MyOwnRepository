package com.bhalchandra.dao;

import org.springframework.dao.DataAccessException;

import com.bhalchandra.entity.CustomerTO;

public interface Customer {
	public String insertCustomer(CustomerTO customer) throws DataAccessException;
	public void updateCustomer(CustomerTO customer);
	public void deleteCustomer(CustomerTO customer);
	public CustomerTO selectCustomer(CustomerTO customer);
	public void insertUsingProcedure(CustomerTO customer);
}