package com.bvk.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class LogAspect {
	@AfterThrowing(pointcut="execution(* com.bvk.StudentDAOImpl.insertStudent(..))", throwing="error")
	public void afterThrowing(JoinPoint joinPoint, Throwable error){
		System.out.println("Exception is thrown on method: " + error);
	}
}