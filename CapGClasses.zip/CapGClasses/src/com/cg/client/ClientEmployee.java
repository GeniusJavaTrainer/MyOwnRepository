package com.cg.client;
import java.util.Scanner;

import com.cg.entity.Address;
import com.cg.entity.Department;
import com.cg.entity.Employee;

public class ClientEmployee {

	public static void main(String[] args) {
		System.out.println("Total salary summed of all employees is:");
		System.out.println(Employee.getTotalSalary());
		
		Employee employee = null;
	//  Datatype  var.      way to create an object
		
		Address address = null;
		
		int empid = 0;
		String name = null;
		float salary = 0.0f;
		
		String street = null;
		String city = null;
		String state = null;
		
		Department department = null;
		
		int dept = 0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter employee id: ");
		empid = scInput.nextInt();
				scInput.nextLine();
				
		System.out.print("Employee name: ");
		name = scInput.nextLine();
		
		System.out.print("Enter employee salary: ");
		salary = scInput.nextFloat();
				 scInput.nextLine();
		
		System.out.print("Street: ");
		street = scInput.nextLine();
		
		System.out.print("City: ");
		city = scInput.nextLine();
		
		System.out.print("State: ");
		state = scInput.nextLine();
		
		System.out.println("Enter department as follows: ");
		System.out.println("1. Marketing");
		System.out.println("2. Finance");
		System.out.println("3. Production");
		
		dept = scInput.nextInt();
			   scInput.nextLine();
			   
		switch(dept) {
		case 1:
				department = Department.MARKETING;
				break;
		case 2:
				department = Department.FINANCE;
				break;
		case 3:
				department = Department.PRODUCTION;
				break;
		}
		
		address = new Address(street, city, state);
		
		employee = new Employee(empid, name, salary, address, department);
		
		/*System.out.print("Enter employee id: ");
		empid = scInput.nextInt();
				scInput.nextLine();
				
		System.out.print("Employee name: ");
		name = scInput.nextLine();
		
		System.out.print("Enter employee salary: ");
		salary = scInput.nextFloat();
				 scInput.nextLine();		
		
		Employee employee1 = new Employee(empid, name, salary);*/
		//  Datatype  var.      way to create an object
			
		employee.print();
//		employee1.print();

//		employee.setSalary(1000000);
		
/*		System.out.println("Salary of empid "+ employee.getEmpid() + " is Rs."+ employee.getSalary());
		
		System.out.println("Total salary summed of all employees is:");*/
//		System.out.println(Employee.getTotalSalary());//Method is called with Class reference & not
		//Object reference like employee or employee1
		
		//System.out.println(employee1.getTotalSalary());//Bad practice
		scInput.close();
	}

}