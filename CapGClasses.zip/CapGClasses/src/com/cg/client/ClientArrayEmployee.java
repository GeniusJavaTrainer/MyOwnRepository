package com.cg.client;

import java.util.Scanner;

import com.cg.entity.Employee;

public class ClientArrayEmployee {

	public static void main(String[] args) {

		Employee employees[] = new Employee[3];//Array of 3 null values of type Employee.
		
		int empid = 0;
		String name = null;
		float salary = 0.0f;
		
		Scanner scInput = new Scanner(System.in);
		
		for (int i = 0; i < employees.length; i++) {
			System.out.print("Enter employee id: ");
			empid = scInput.nextInt();
					scInput.nextLine();
					
			System.out.print("Employee name: ");
			name = scInput.nextLine();
			
			System.out.print("Enter employee salary: ");
			salary = scInput.nextFloat();
					 scInput.nextLine();
					 
			employees[i] = new Employee(empid, name, salary);
		}
		
		for (Employee employee : employees) {
			employee.print();
		}

		scInput.close();
	}

}