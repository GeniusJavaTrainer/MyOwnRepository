package com.cg.entity;

public enum Department {
	MARKETING, FINANCE, PRODUCTION
}