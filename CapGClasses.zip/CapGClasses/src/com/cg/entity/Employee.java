package com.cg.entity;
public class Employee {
	
	private static float totalSalary;
	
	private int empid;
	private String name;
	private float salary;
	private Address address;
	private Department department;//Can have values from MARKETING, FINANCE & PRODUCTION only.
	
	public Employee(int empid, String name, float salary, Address address, Department department) {
		this.empid = empid;
		this.name = name;
		this.salary = salary;
		this.address = address;
		this.department = department;
	}

	
	/*
	 * Polymorphism
	 * 
	 * One Name - Many Forms
	 * 
	 * Constructor of One Name.
	 * 
	 * It has Many Forms. One is parameterless & other is parameterized.
	 * 
	 * When it happens in same class, it is overloading.
	 * 
	 * So, we saw Constructor Overloading.
	 * 
	 * 
	 */
	public Employee() {//default constructor
	}

	public Employee(int empid, String name, float salary) {//Parameterized Constructor
		this.empid = empid;
		this.name = name;
		this.salary = salary;
		totalSalary += this.salary;
	}

	public Employee(int empid, String name, float salary, Address address) {
		this.empid = empid;
		this.name = name;
		this.salary = salary;
		this.address = address;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	public void print() {
		System.out.println("Employee ID: " + empid);
		System.out.println("Employee Name: " + name);
		System.out.println("Employee Salary: " + salary);
		System.out.println("Department: " + department);
		address.print();
	}
	
	public static float getTotalSalary() {
		return totalSalary;
	}
}