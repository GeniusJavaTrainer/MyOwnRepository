package com.me.service;

import java.util.List;

import com.me.entity.Fruit;
import com.me.exception.FruitNotFoundException;

public interface FruitService {
	public Fruit registerFruit(Fruit Fruit);
	public Fruit updateFruit(Fruit Fruit);
	public Fruit deleteFruit(int fruitId) throws FruitNotFoundException;
	public Fruit getFruit(int fruitId) throws FruitNotFoundException;
	public List<Fruit> getFruits();
}