package com.me.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.me.dao.FruitRepository;
import com.me.entity.Fruit;
import com.me.exception.FruitNotFoundException;

@Service
public class FruitServiceImpl implements FruitService {

	@Autowired
	private FruitRepository fruitRepo;
	
	@Override
	public Fruit registerFruit(Fruit Fruit) {
		return null;
	}

	@Override
	public Fruit updateFruit(Fruit Fruit) {
		return null;
	}

	@Override
	public Fruit deleteFruit(int empid)  throws FruitNotFoundException{
		return null;
	}

	@Override
	public Fruit getFruit(int empid)  throws FruitNotFoundException{
		return null;
	}

	@Override
	public List<Fruit> getFruits() {
		return null;
	}
}