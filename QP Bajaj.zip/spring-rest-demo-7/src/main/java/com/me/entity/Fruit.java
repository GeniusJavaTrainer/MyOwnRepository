package com.me.entity;

import javax.persistence.Entity;

@Entity
public class Fruit {
	//Mark it as primary key & automatically generate primary key
	private int fruitId;
	
	//Should not be blank
	private String name;
	
	
	private float price;

	public Fruit() {
		super();
	}

	public Fruit(String name, float price) {
		super();
		this.name = name;
		this.price = price;
	}


	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}


	public int getFruitId() {
		return fruitId;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + fruitId;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + Float.floatToIntBits(price);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Fruit other = (Fruit) obj;
		if (fruitId != other.fruitId)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Float.floatToIntBits(price) != Float.floatToIntBits(other.price))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Fruit [fruitId=" + fruitId + ", name=" + name + ", price=" + price + "]";
	}
}