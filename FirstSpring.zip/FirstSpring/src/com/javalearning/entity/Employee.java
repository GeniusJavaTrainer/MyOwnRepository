package com.javalearning.entity;

public class Employee {
	private int empid;
	private String name;
	private Address address;
	private float salary;
	
	public Employee() {
		super();
	}

	public Employee(int empid, String name, float salary) {
		super();
		this.empid = empid;
		this.name = name;
		this.salary = salary;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {//"bvk"
		this.name = name;
	}

	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {//
		this.address = address;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "empid=" + empid + "\nname=" + name + "\naddress=" + address + "\nsalary=" + salary
				+ "\n==============================================================";
	}
}