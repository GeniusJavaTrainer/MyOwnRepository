package com.bvk.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="order_master110")
public class Order implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4098657090871319299L;

	@Id
	private int id;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name="product_orders110", joinColumns = { @JoinColumn(name="order_id")},
	inverseJoinColumns = {@JoinColumn(name="product_id")})
	private Set<Product>products = new HashSet<>();

	public Order() {
		super();
	}

	public Order(int id, Set<Product> products) {
		super();
		this.id = id;
		this.products = products;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Set<Product> getProducts() {
		return products;
	}

	public void setProducts(Set<Product> products) {
		this.products = products;
	}

	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (id != other.id)
			return false;
		if (products == null) {
			if (other.products != null)
				return false;
		} else if (!products.equals(other.products))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", products=" + products + "]";
	}
}