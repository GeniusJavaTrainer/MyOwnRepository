package com.bvk.client;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bvk.entity.Order;
import com.bvk.entity.Product;

public class ClientManyToMany {

	public static void main(String[] args) {
		SessionFactory sf = new Configuration().configure().
				addAnnotatedClass(com.bvk.entity.Product.class).
				addAnnotatedClass(com.bvk.entity.Order.class).
				buildSessionFactory();
		
		Session session = sf.openSession();
		
		Transaction tx = null;
		
		try{
			Product productOne = new Product();
			Product productTwo = new Product();
			
			Order orderOne = new Order();
			Order orderTwo = new Order();
			
			Set<Product>products = new HashSet<>();
			Set<Order>orders = new HashSet<>();
			
			productOne.setId(5);
			productOne.setName("Trekking Shoes");
			productOne.setPrice(4500);
			
			productTwo.setId(6);
			productTwo.setName("Stick");
			productTwo.setPrice(450);
			
			products.add(productOne);
			products.add(productTwo);
			
			orderOne.setId(1);
			orderOne.setProducts(products);
			
			orderTwo.setId(2);
			orderOne.setProducts(products);
			
			orders.add(orderOne);
			orders.add(orderTwo);
			
			productOne.setOrders(orders);
			productTwo.setOrders(orders);
			
			orderOne.setProducts(products);
			orderTwo.setProducts(products);
			
			tx = session.beginTransaction();
			
			session.save(orderTwo);
			session.save(orderOne);
			
			tx.commit();
		}catch(Exception e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}