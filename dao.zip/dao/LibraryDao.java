package com.cognizant.dao;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.model.Library;

public interface LibraryDao extends CrudRepository<Library, Long> {
	Library findById(Long id);
}
