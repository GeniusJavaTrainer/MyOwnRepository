package com.cognizant.dao;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.model.Book;

public interface BookDao extends CrudRepository<Book, Long> {
	
}
