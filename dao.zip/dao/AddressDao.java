package com.cognizant.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Address;

@Repository
public interface AddressDao extends CrudRepository<Address, Long> {

}
