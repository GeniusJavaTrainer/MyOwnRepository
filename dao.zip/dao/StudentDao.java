package com.cognizant.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Student;

@Repository
public interface StudentDao extends CrudRepository<Student, Long> {
	Student findByRollNo(Long id);
}