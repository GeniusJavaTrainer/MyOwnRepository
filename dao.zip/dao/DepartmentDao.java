package com.cognizant.dao;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.model.Department;

public interface DepartmentDao extends CrudRepository<Department, Integer> {
	Department findById(int id);
}
