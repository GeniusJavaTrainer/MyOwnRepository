package com.springboot.couchbase;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootandcouchbaseApplicationTests {

	@Test
	void contextLoads() {
	}
}
