package com.springboot.couchbase.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.couchbase.entity.Employee;
import com.springboot.couchbase.exception.EntityNotFound;
import com.springboot.couchbase.repository.EmployeeRepository;

//spring annotation
@Service
public class EmployeeService {

    @Autowired
    EmployeeRepository repository;

    //save new employee in the couchbase
    public void save(final Employee e) {
        repository.save(e);
    }

    //get total count in the couchbase
    public long count() {
        return repository.count();
    }

    //get all employees from the couchbase
    public List<Employee> getEmployees() {
        final Iterable<Employee> employeeIterable = repository.findAll();
        return StreamSupport.stream(employeeIterable.spliterator(), false).collect(Collectors.toList());
    }

    //get employee by id from the couchbase
    public Employee getEmployee(final String eid) throws EntityNotFound {
        return repository.findById(eid).orElseThrow(EntityNotFound::new);
    }

  //insert employee by id from the couchbase
    public Employee insertEmployee(final Employee employee) throws EntityNotFound {
        return repository.save(employee);
    }
    
  //update employee by id from the couchbase
    public Employee updateEmployee(final Employee employee) throws EntityNotFound {
        return repository.save(employee);
    }
    
  //delete employee by id from the couchbase
    public void deleteEmployee(final String empId) throws EntityNotFound{
        repository.deleteById(empId);
    }
    //get employees by department from the couchbase
    public List<Employee> getEmployeesByWorkDepartment(final String workDepartment) {
        return repository.findAllByWorkDepartment(workDepartment);
    }
}
