package hello;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;



@EnableEurekaClient
@SpringBootApplication
public class EurekaClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(EurekaClientApplication.class, args);
        getMicroserviceName();
    }
    
    public static String getMicroserviceName()
    {
    	RestTemplate restTemplate = new RestTemplate();
    	HttpHeaders headers = new HttpHeaders();
    	
    	// set `content-type` header
    	headers.setContentType(MediaType.APPLICATION_JSON);

    	headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
    	
    	// request body parameters
    	Map<String, String> map = new HashMap<>();
    	map.put("email", "abc@email.com");
    	map.put("password", "pass123");
    	

    	// build the request
    	HttpEntity<Map<String, String>> entity = new HttpEntity<>(map, headers);

    	// send POST request
    	ResponseEntity<String> response = restTemplate.postForEntity("http://localhost:8080/user/login", entity, String.class);

    	if (response.getStatusCode() == HttpStatus.OK) {
    	    System.out.println("Request Successful");
    	} else {
    	    System.out.println("Request Failed");
    	    System.out.println(response.getStatusCode());
    	}
    	HttpHeaders myHeader = new HttpHeaders();
    	
    	/*myHeader.set("Accept","application/json");
    	myHeader.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));*/
    	myHeader.add("User-Agent", "Spring's RestTemplate" );
    	myHeader.set("Authorization","Bearer "+response.getBody());
    	HttpEntity<String> request = new HttpEntity<>(myHeader);
    	
    	ResponseEntity<Policy> response1 = restTemplate.exchange("http://localhost:8080/secure/policies/1",HttpMethod.GET ,request, Policy.class,1);
    	
    	System.out.println(response1.getBody());
    	
    	return response.getBody();
    }
}