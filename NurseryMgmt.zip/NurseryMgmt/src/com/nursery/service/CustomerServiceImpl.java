package com.nursery.service;

import java.util.List;

import com.nursery.dao.CustomerDAOImpl;
import com.nursery.dao.ICustomerDAO;
import com.nursery.entity.Customer;

public class CustomerServiceImpl implements CustomerService {

	private ICustomerDAO customerDAO;
	
	public CustomerServiceImpl() {
		customerDAO = new CustomerDAOImpl();
	}
	
	@Override
	public int insertCustomer(Customer customer) {
		return customerDAO.insert(customer);
	}

	@Override
	public int updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteCustomer(int custId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer viewCustomer(int custId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> viewCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

}
