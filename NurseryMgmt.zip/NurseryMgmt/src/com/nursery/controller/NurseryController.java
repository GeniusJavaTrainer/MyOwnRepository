package com.nursery.controller;

import com.nursery.entity.Customer;
import com.nursery.service.CustomerService;
import com.nursery.service.CustomerServiceImpl;

public class NurseryController {

	private CustomerService customerService;

	public NurseryController() {
		customerService = new CustomerServiceImpl();
	}
	
	public void insertCustomer(Customer customer) {
		int status = customerService.insertCustomer(customer);
		
		if(status > 0) {
			System.out.println("Record inserted successfully.");
		}else {
			System.out.println("Record couldn't be inserted");
		}
	}
}
