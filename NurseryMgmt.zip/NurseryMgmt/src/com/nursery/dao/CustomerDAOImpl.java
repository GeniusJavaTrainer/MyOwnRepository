package com.nursery.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.nursery.entity.Customer;
import com.nursery.utility.DBUtil;

public class CustomerDAOImpl implements ICustomerDAO {

	@Override
	public int insert(Customer customer) {
		int status = 0;

		Connection connStudent = null;
		PreparedStatement pstStudent = null;

		String sql = new String("INSERT INTO customer VALUES(?,?,?,?)");

		try {
			connStudent = DBUtil.createConnection();

			pstStudent = connStudent.prepareStatement(sql);
			pstStudent.setInt(1, customer.getCustId());
			pstStudent.setString(2, customer.getName());
			pstStudent.setString(3, customer.getAddress());
			pstStudent.setString(4, customer.getContactNo());
			

			status = pstStudent.executeUpdate();

			System.out.println("Record inserted successfully with customer ID " + customer.getCustId());
		} catch (SQLException se) {
			System.out.println(se.getMessage());
		} finally {
			try {
				DBUtil.closeConnection();
			} catch (SQLException se) {
				System.out.println("Problems in closing connection");
			}
		}
		return status;
	}

	@Override
	public int update(Customer customer) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int custId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer viewOne(int custId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> viewAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
