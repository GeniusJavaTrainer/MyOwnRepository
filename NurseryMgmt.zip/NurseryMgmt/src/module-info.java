/**
 * 
 */
/**
 * @author Bhalchandra
 *
 */
module NurseryMgmt {
	requires java.sql;
	requires ojdbc14.g;
}