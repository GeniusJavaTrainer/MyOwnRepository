import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ContactusComponent } from './contactus/contactus.component';
import { InfoComponent } from './info/info.component';
import { PricesComponent } from './prices/prices.component';

const routes: Routes = [
  { path: "home", component: HomeComponent },
  { path: "contactus", component: ContactusComponent },
  { path: "info", component: InfoComponent },
  { path: "prices", component: PricesComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ContactusComponent,
    InfoComponent,
    PricesComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
