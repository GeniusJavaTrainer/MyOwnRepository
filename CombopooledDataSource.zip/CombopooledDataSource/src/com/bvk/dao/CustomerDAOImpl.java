package com.bvk.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import com.bvk.entity.CustomerTO;

public class CustomerDAOImpl implements Customer {
	//private SimpleJdbcDaoSupport  jdbcDAOSupport = new SimpleJdbcDaoSupport();
	
	private SimpleJdbcTemplate  simpleJdbcTemplate ;
	
	public void setDataSource(DataSource dataSource){
		simpleJdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}
	
	@Override
	public void insertCustomer(CustomerTO customer) {
		// TODO Auto-generated method stub
		String query = "INSERT INTO customer VALUES(?,?,?)";
		
		Integer custId = customer.getCustomerId();
		String name = customer.getName();
		String address = customer.getAddress();
		
		//simpleJdbcTemplate.getJdbcTemplate().update(query, custId,name,address);
		simpleJdbcTemplate.update(query, custId,name,address);
	}

	@Override
	public void updateCustomer(CustomerTO customer) {
		// TODO Auto-generated method stub
		String query = "UPDATE customer SET custId=?, name=?, address=?"
				+ "WHERE customerId=?";
		
		Integer custId = customer.getCustomerId();
		String name = customer.getName();
		String address = customer.getAddress();
		
		//simpleJdbcTemplate.getJdbcTemplate().update(query, custId,name,address,custId);
		simpleJdbcTemplate.update(query, custId,name,address,custId);
	}

	@Override
	public void deleteCustomer(CustomerTO customer) {
		// TODO Auto-generated method stub
		String query = "DELETE FROM customer WHERE custId=?";
		
		Integer custId = customer.getCustomerId();
				
		//simpleJdbcTemplate.getJdbcTemplate().update(query, custId);
		simpleJdbcTemplate.update(query, custId);
	}

	@Override
	public void insertUsingProcedure(CustomerTO customer) {
		// TODO Auto-generated method stub
		String query = "{CALL insertit(?,?,?)}";
		
		Integer custId = customer.getCustomerId();
		String name = customer.getName();
		String address = customer.getAddress();
		
		//simpleJdbcTemplate.getJdbcTemplate().update(query, custId,name,address);
		simpleJdbcTemplate.update(query, custId,name,address);
	}

	@Override
	public CustomerTO selectCustomer(CustomerTO customer) {
		// TODO Auto-generated method stub
		CustomerTO customerFound = null;
		
		String query = "SELECT * FROM customer WHERE customerId = ?";
		
		Integer custId = customer.getCustomerId();
		
		customerFound = (CustomerTO)simpleJdbcTemplate.queryForObject(query, new ParameterizedRowMapper(){
			@Override
			public Object mapRow(ResultSet resultSet, int rowNum) throws SQLException{
				int custId = resultSet.getInt("customerid");
				String name = resultSet.getString("name");
				String address = resultSet.getString("address");
				
				CustomerTO customer = new CustomerTO(custId, name, address);
				return customer;
			}
		},
		custId
		);
		return customerFound;
	}
}