package com.bvk.dao;

import com.bvk.entity.CustomerTO;

public interface Customer {
	public void insertCustomer(CustomerTO customer);
	public void updateCustomer(CustomerTO customer);
	public void deleteCustomer(CustomerTO customer);
	public CustomerTO selectCustomer(CustomerTO customer);
	public void insertUsingProcedure(CustomerTO customer);
}