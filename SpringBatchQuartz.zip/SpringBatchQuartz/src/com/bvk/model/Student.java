package com.bvk.model;

public class Student {
	private int rollno;
	private String name;
	private String branch;
	private float percent;
	
	public Student() {
		super();
	}

	public Student(int rollno, String name, String branch, float percent) {
		super();
		this.rollno = rollno;
		this.name = name;
		this.branch = branch;
		this.percent = percent;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public float getPercent() {
		return percent;
	}

	public void setPercent(float percent) {
		this.percent = percent;
	}

	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + ", branch=" + branch + ", percent=" + percent + "]";
	}
}