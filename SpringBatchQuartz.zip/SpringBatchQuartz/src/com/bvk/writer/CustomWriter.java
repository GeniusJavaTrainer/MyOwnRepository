package com.bvk.writer;

import java.util.List;
import org.springframework.batch.item.ItemWriter;
import com.bvk.model.Student;

public class CustomWriter implements ItemWriter<Student> {

  @Override
  public void write(List<? extends Student> students) throws Exception {

	System.out.println("writing..." + students.size());		
	for(Student student : students){
		System.out.println(student);
	}
  }
}