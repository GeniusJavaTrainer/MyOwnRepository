package com.nursery.client;

import java.util.List;
import java.util.Scanner;

import com.nursery.controller.NurseryController;
import com.nursery.entity.Customer;

public class NurseryClient {

	public static void main(String[] args) {
		int choice = -1;
		int innerChoice = -1;
		
		int custId = 0;
		String name = null;
		String address = null;
		String contactNo = null;
		
		NurseryController nurseryController = new NurseryController();
		
		Customer customer = null;
		
		Scanner scInput = new Scanner(System.in);
		do{
			System.out.println("Following is the choice:");
			System.out.println("1. Customer");
			System.out.println("2. Plants");
			System.out.println("3. Delivery Person");
			System.out.println("4. Order a plant");
			System.out.println("0. Exit");
			
			choice = Integer.parseInt(scInput.nextLine());
			
			switch(choice) {
			case 1:
					do {
						System.out.println("Following is the choice:");
						System.out.println("1. Insert Customer");
						System.out.println("2. Update Customer");
						System.out.println("3. Delete Customer");
						System.out.println("4. View single customer");
						System.out.println("5. View all customers");
						System.out.println("0. Exit");
						
						innerChoice = Integer.parseInt(scInput.nextLine());
						
						switch(innerChoice) {
						case 1:
							System.out.print("Enter customer ID: ");
							custId = Integer.parseInt(scInput.nextLine());
							
							System.out.print("Enter name: ");
							name = scInput.nextLine();
							
							System.out.print("Enter address: ");
							address = scInput.nextLine();
							
							System.out.print("Enter contact no: ");
							contactNo = scInput.nextLine();
							
							customer = new Customer(custId, name, address, contactNo);
		
							nurseryController.insertCustomer(customer);
							break;
						case 2:
							System.out.print("Enter customer ID: ");
							custId = Integer.parseInt(scInput.nextLine());
							
							System.out.print("Enter name: ");
							name = scInput.nextLine();
							
							System.out.print("Enter address: ");
							address = scInput.nextLine();
							
							System.out.print("Enter contact no: ");
							contactNo = scInput.nextLine();
							
							customer = new Customer(custId, name, address, contactNo);
		
							nurseryController.updateCustomer(customer);
							break;
						case 3:
							System.out.print("Enter customer ID: ");
							custId = Integer.parseInt(scInput.nextLine());
							
							nurseryController.deleteCustomer(custId);
							break;
						case 4:
							System.out.print("Enter customer ID: ");
							custId = Integer.parseInt(scInput.nextLine());
							
							customer = nurseryController.viewCustomer(custId);
							System.out.println(customer);
							break;
						case 5:
							List<Customer>customers = nurseryController.viewAllCustomers();
							
							System.out.println("Following is the customer list:");
							
							for(Customer cust : customers) {
								System.out.println(cust);
							}
							break;							
						}
					}while(innerChoice != 0);
					break;
			}
		}while(choice != 0);
		scInput.close();
	}

}
