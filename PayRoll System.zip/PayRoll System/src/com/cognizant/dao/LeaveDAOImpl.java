package com.cognizant.dao;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.cognizant.entity.Employee;
import com.cognizant.entity.Leave;
import com.cognizant.exception.EmployeeException;

public class LeaveDAOImpl implements LeaveDAO {
	
	private static final long serialVersionUID = 1L;
  
    public LeaveDAOImpl() {
        super();
    }
	
    
    
	public List<Leave> getviewSalary(Employee employee) throws EmployeeException {
		int empid = employee.getEmpId();
		float salary = employee.getSalary();
		List<Leave>leaveList = null;
		
		SessionFactory sfEmployee = new Configuration().configure().
				addAnnotatedClass(com.cognizant.entity.Leave.class).buildSessionFactory();
		
		Session sessionEmployee = sfEmployee.openSession();
		try{
			Criteria criteriaEmployee = sessionEmployee.createCriteria(Leave.class);
			
			criteriaEmployee.add(Restrictions.eq("empid", employee.getEmpId()));
			
			leaveList = (List<Leave>)criteriaEmployee.list();
			
			LocalDate today = LocalDate.now();
			
			int thisMonth = today.getMonthValue();
			
			Iterator<Leave>leaveItr = leaveList.iterator();
			
			while(leaveItr.hasNext()){
				Leave leave = leaveItr.next();
				
				int startMonth = leave.getStartDate().toLocalDate().getMonthValue();
				
				if(!(startMonth == (thisMonth-1))){
					leaveItr.remove();
				}
			}
		}catch(HibernateException e){
			throw new EmployeeException("No such Employee");
		}

		
		return leaveList;
	}



	public Employee getviewSalary(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}
	

	

	

	


	
	}



	
