package com.cognizant.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.cognizant.entity.Employee;
import com.cognizant.exception.EmployeeException;

public class EmployeeDAOImpl implements EmployeeDAO {
	private static final long serialVersionUID = 1L;
  
    public EmployeeDAOImpl() {
        super();
    }
	
	public int insert(final Employee employee) throws EmployeeException {
		return 0;
	}

	public int update(final Employee employee) throws EmployeeException {
		return 0;
	}

	public Employee viewSalary(final int empId) throws EmployeeException {
		return null;
	}

	public Employee validateEmployee(final String username, final String password) throws EmployeeException {
		Employee employee = null;
		
		SessionFactory sfEmployee = new Configuration().configure().
				addAnnotatedClass(com.cognizant.entity.Employee.class).buildSessionFactory();
		
		Session sessionEmployee = sfEmployee.openSession();

		try{
			Criteria criteriaEmployee = sessionEmployee.createCriteria(Employee.class);
			
			criteriaEmployee.add(Restrictions.eq("username", username)).
			add(Restrictions.eq("password", password));
			List<Employee>employeeList = (List<Employee>)criteriaEmployee.list();
			
			if(employeeList.size() > 0){
				employee = employeeList.get(0);
			}else{
				throw new EmployeeException("No such Employee");
			}
		}catch(HibernateException e){
			throw new EmployeeException("No such Employee");
		}
		
		return employee;
	}
}