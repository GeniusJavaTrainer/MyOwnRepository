package com.cognizant.entity;


import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Leave implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5119716330336646593L;
	
	

	@Id
	private int grantLeaveId;
	private Date StartDate;
	private Date EndDate;
	private String status;
	private int TotalDays;
	private int empId;
	
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public Date getStartDate() {
		return StartDate;
	}

	public void setStartDate(Date startDate) {
		StartDate = startDate;
	}

	public Date getEndDate() {
		return EndDate;
	}

	public void setEndDate(Date endDate) {
		EndDate = endDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	

	public Leave() {
		
	}

	public int getGrantLeaveId() {
		return grantLeaveId;
	}

	public void setGrantLeaveId(int grantLeave) {
		this.grantLeaveId = grantLeave;
	}
	public int getTotalDays() {
		return TotalDays;
	}

	public void setTotalDays(int totalDays) {
		TotalDays = totalDays;
	}
	
}
