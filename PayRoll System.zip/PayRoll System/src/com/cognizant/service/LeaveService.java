package com.cognizant.service;

import java.util.List;


import com.cognizant.entity.Employee;
import com.cognizant.exception.EmployeeException;

public interface LeaveService {
	
List<Employee> getviewSalary();

}