package com.cognizant.service;

import com.cognizant.entity.Employee;
import com.cognizant.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {

	public int insert(final Employee employee) throws EmployeeException {
		return 0;
	}

	public int update(final Employee employee) throws EmployeeException {
		return 0;
	}

	public Employee viewSalary(final int empId) throws EmployeeException {
		return null;
	}

	public Employee validateEmployee(final String username, final String password) throws EmployeeException {
		return null;
	}

}