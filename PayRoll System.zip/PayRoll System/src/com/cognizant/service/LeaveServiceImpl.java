package com.cognizant.service;

import java.util.List;

import com.cognizant.dao.LeaveDAO;
import com.cognizant.dao.LeaveDAOImpl;
import com.cognizant.entity.Employee;
import com.cognizant.entity.Leave;
import com.cognizant.exception.EmployeeException;

public class LeaveServiceImpl implements LeaveService {

	private LeaveDAO employeeDAO=null;
	
	public LeaveServiceImpl() {
		super();
		this.setEmployeeDAO(new LeaveDAOImpl());
	}

private void setEmployeeDAO(LeaveDAOImpl leaveDAOImpl) {
		// TODO Auto-generated method stub
		
	}

public List<Employee> getviewSalary() {
		// TODO Auto-generated method stub
		return null;
	}



}