package programs;

public class LoopTimeExecution {

	public static void main(String[] args) {

		long after = 0;
		long before = 0;
		
		before = System.currentTimeMillis();
		
		for(int i = 1 ; i <= 1000000000; i++);

		after = System.currentTimeMillis();
		
		System.out.println("Loop took milliseconds = " + (after - before));
	}

}
