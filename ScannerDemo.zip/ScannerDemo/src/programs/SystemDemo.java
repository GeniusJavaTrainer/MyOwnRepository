package programs;

public class SystemDemo {

	public static void main(String[] args) {
		int numbers[] = {1,2,3,4,5};
		int toBeFound = 4;
		
		for (int i = 0; i < numbers.length; i++) {
			if(toBeFound == numbers[i]) {
				System.out.println("Number found at position " + i);
				System.exit(0);//Terminate program gracefully.
			}
		}
		System.out.println("Number not found.");
	}

}
