package programs;

import java.util.Scanner;

public class InputFromKeyboard {

	public static void main(String[] args) {

		Scanner scInput = new Scanner(System.in);
		
		byte age = 0;
		short distance = 0;
		int number = 0;
		long value = 0;
		
		float percent = 0.0f;
				
		char alphabet = 'a';
		
		String text = null;
		
		System.out.print("Enter age: ");
		age = scInput.nextByte();//Read text & convert to byte data type.
		
		System.out.print("Enter distance: ");
		distance = scInput.nextShort();
		
		System.out.print("Enter number: ");
		number = scInput.nextInt();
		
		System.out.print("Enter value: ");
		value = scInput.nextLong();
		
		System.out.print("Enter percent: ");
		percent = scInput.nextFloat();
		
		System.out.print("Enter an alphabet: ");
		alphabet = scInput.next().charAt(0);
				   scInput.nextLine();
				   
		System.out.print("Enter a line: ");
		text = scInput.nextLine();//Reads till Enter key.
		
		System.out.println("The inputted part is:");
		
		System.out.println(age);
		System.out.println(distance);
		System.out.println(number);
		System.out.println(value);
		System.out.println(percent);
		System.out.println(alphabet);
		System.out.println(text);
		
		scInput.close();
	}

}