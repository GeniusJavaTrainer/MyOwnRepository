package com.springforbeginners.javabasedconfig;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
    public static void main(String[] args) throws Exception {
    	AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        Customer customer = (Customer) ctx.getBean("customer");
        System.out.println(customer);
        
        ctx.registerShutdownHook();
        //customer.cleanUp();
    }
}