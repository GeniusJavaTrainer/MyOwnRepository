package com.springforbeginners.javabasedconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    @Bean(initMethod = "initIt", destroyMethod = "cleanUp")
    public Customer customer() {
        Customer customer = new Customer(person());
        customer.setMessage("Welcome to Spring for Beginners");
        return customer;
    }

    @Bean
    public Person person() {
        Person person = new Person();
        person.setName("Sharanam");
        person.setAddress("Mumbai, Maharashtra, India");
        return person;
    }
}
