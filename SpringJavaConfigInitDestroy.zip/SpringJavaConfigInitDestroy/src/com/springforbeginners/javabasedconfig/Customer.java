package com.springforbeginners.javabasedconfig;

public class Customer {
    private Person person;
    private String message;

    public void setMessage(String message) {
        this.message = message;
    }
    
    public Customer(Person person) {
        this.person = person;
    }
    
    public void setPerson(Person person) {
        this.person = person;
    }
    
    @Override
    public String toString() {
        return "Customer [Person=" + person + "]";
    }
    
    public void initIt() throws Exception {
        System.out.println("Initializing the bean...:" + message);
    }
    
    public void cleanUp() throws Exception {
        System.out.println("Spring container destroyed. Customer clean up...");
    }
}