import { Component } from '@angular/core';
import {Hero} from './hero'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  template: `
  <h1>{{title}}</h1>
  <h2>My favorite hero is: {{myHero.name |lowercase}}</h2>
  <p>Heroes:</p>
  <ul>
    <li *ngFor="let hero of heroes">
      {{ hero.name | uppercase}}
    </li>
  </ul>

  <p *ngIf="heroes.length > 3">There are many heroes!</p>
  Hero's birthday is on : {{birthday | date:"dd-MM-yyyy"}}<br/>
  Hero's salary for saving world (I mean America) : {{salary | currency}}<br/>
  Hero's popularity percentage : {{popularity | number}}
`
  
})
export class AppComponent {
  title: string;
  myHero: Hero;
  heroes : Hero[];
  birthday = new Date(1988, 3, 15);
  salary = 250000.00;
  popularity = 97.86787878;

  constructor() {
    this.title = 'Tour of Heroes';
    this.heroes = [
      new Hero(1, 'Thor'),
      new Hero(13, 'Bombasto'),
      new Hero(15, 'Magneta'),
      new Hero(20, 'Tornado')
    ];
    this.myHero = this.heroes[0];
  }
}
