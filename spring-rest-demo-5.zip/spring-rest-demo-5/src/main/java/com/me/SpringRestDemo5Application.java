package com.me;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestDemo5Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestDemo5Application.class, args);
	}
}