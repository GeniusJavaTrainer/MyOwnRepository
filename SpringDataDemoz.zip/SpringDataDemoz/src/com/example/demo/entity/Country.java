package com.example.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name = "country")
public class Country {
	 	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @Column(unique = true)
	    private String name;

	    @NotNull
	     private String capital;

	    @NotNull
	    private String currency;

	    @OneToMany(cascade = CascadeType.ALL,
	            fetch = FetchType.LAZY,
	            mappedBy = "country")
	    private Set<State> statt = new HashSet<>();

	    public Country() {

	    }

	    public Country(String name, String capital, String currency) {
	        this.name = name;
	        this.capital = capital;
	        this.currency = currency;
	    }

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getCapital() {
			return capital;
		}

		public void setCapital(String capital) {
			this.capital = capital;
		}

		public String getCurrency() {
			return currency;
		}

		public void setCurrency(String currency) {
			this.currency = currency;
		}

		public Set<State> getStatt() {
			return statt;
		}

		public void setStatt(Set<State> statt) {
			this.statt = statt;
		}

		@Override
		public String toString() {
			return "Country [id=" + id + ", name=" + name + ", capital=" + capital + ", currency=" + currency
					+ ", statt=" + statt + "]";
		}

	    
}
