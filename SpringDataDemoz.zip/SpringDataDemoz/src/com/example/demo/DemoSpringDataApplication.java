package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.dao.CartRepository;
import com.example.demo.dao.CountryRepository;
import com.example.demo.dao.ItemRepository;
import com.example.demo.dao.StateRepository;
import com.example.demo.entity.Cart;
import com.example.demo.entity.Country;
import com.example.demo.entity.Item;
import com.example.demo.entity.State;

@SpringBootApplication
public class DemoSpringDataApplication implements CommandLineRunner{
	@Autowired
    private CountryRepository countryRepository;

    @Autowired
    private StateRepository stateRepository;
    
    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private CartRepository cartRepository;
    
	public static void main(String[] args) {
		SpringApplication.run(DemoSpringDataApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		/*Country country = new Country("India","NewDelhi","Rupees");

        State state1  = new State("Hariyana");
        state1.setCountry(country);
        State state2  = new State("Bihar");
        state2.setCountry(country);
        country.getStatt().add(state1);
        country.getStatt().add(state2);

        countryRepository.save(country);*/
		
		Cart cart = new Cart(1L);

        // Create two Items
        Item item1 = new Item("As It is",2000L);
        Item item2 = new Item("BCAA",1200L);


        // Add item references in the cart
        cart.getItems().add(item1);
        cart.getItems().add(item2);

        // Add cart reference in the Item
        item1.getCarts().add(cart);
        item2.getCarts().add(cart);

        cartRepository.save(cart);
		
	}
	
	

}
