package com.cg.entity;

@FunctionalInterface
public interface PrintMessage {
	void printMessage(String message);
}
