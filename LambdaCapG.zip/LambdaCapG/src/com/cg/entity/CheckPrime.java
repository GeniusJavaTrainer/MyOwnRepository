package com.cg.entity;
@FunctionalInterface
public interface CheckPrime {
	boolean isPrime(int number);
}