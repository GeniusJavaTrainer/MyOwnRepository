package com.cg.entity;

@FunctionalInterface
public interface SquareCalc {
	int square(int number);
}