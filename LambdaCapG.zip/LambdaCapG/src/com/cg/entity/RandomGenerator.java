package com.cg.entity;

@FunctionalInterface
public interface RandomGenerator {
	double randomize();
}
