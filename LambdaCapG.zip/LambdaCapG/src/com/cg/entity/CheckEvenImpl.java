package com.cg.entity;

public class CheckEvenImpl implements CheckEven {

	@Override
	public boolean isEven(int n) {
		boolean isItEven;
		isItEven = n % 2 == 0;
		return isItEven;
	}
}