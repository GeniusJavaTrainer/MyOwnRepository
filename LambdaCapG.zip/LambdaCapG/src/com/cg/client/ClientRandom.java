package com.cg.client;

import java.util.Random;

import com.cg.entity.RandomGenerator;

public class ClientRandom {

	public static void main(String[] args) {

		RandomGenerator randomGenerator = ()->new Random().nextDouble();
		
		System.out.println(randomGenerator.randomize());
		
	}
}