package com.cg.client;

import com.cg.entity.SquareCalc;

public class ClientSquare {

	public static void main(String[] args) {
		SquareCalc squareCalc = (n)->n*n;
		
		System.out.println(squareCalc.square(20));
	}

}
