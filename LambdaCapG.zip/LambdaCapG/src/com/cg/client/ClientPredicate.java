package com.cg.client;

import java.util.function.BiPredicate;
import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class ClientPredicate {

	public static void main(String[] args) {
		Predicate<Integer>checkEven = (n)-> n%2 == 0;
		IntPredicate chkEven = (n)-> n%2 == 0;
		
		System.out.println(checkEven.test(20));
		System.out.println(chkEven.test(20));
		
		Predicate<Integer>checkPrime =(n)->{
			int sqrt = (int)Math.sqrt(n);
			boolean flag = true;
			
			for(int i = 2 ; i <= sqrt ; i++){
				if(n % i == 0){
					flag = false;
					break;
				}
			}
			return flag;
		};
		
		System.out.println(checkPrime.test(13));
		
		BiPredicate<String, String>areTheySame = (s1,s2)->s1.equals(s2);
		System.out.println("Are they Same? "+areTheySame.test("capg", "capg"));
	}
}