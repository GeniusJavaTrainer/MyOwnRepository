package com.cg.client;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.IntFunction;

public class ClientFunction {

	public static void main(String[] args) {
	Function<Integer, Integer>calculateTwice = (n)->n*2;	
	System.out.println(calculateTwice.apply(10));
	
	IntFunction<Integer>calculateDouble = (n)->n*2;
	System.out.println(calculateDouble.apply(10));
	
	//         return  para1     para2
	BiFunction<Integer,Integer, Integer>calculateMulti = (a,b)->a*b;	
	System.out.println(calculateMulti.apply(10,20));
	}
}