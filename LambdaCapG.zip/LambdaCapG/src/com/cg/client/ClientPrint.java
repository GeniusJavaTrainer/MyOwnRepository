package com.cg.client;

import com.cg.entity.PrintMessage;

public class ClientPrint {

	public static void main(String[] args) {

		PrintMessage printMessage = (n)-> System.out.println(n);

		printMessage.printMessage("Welcome to Lambda Expresions.");
	}

}
