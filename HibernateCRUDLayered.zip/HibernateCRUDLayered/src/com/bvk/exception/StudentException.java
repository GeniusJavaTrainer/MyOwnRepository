package com.bvk.exception;

public class StudentException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8912625351577262815L;

	public StudentException() {
	}

	public StudentException(String message) {
		super(message);
	}
}