package com.shashank;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmpClient {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

		EmpInterface ei = (EmpInterface) context.getBean("employee");
		ei.printIt();
	}
}