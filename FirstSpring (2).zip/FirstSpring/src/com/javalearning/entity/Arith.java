package com.javalearning.entity;

public interface Arith {
	public int add(int a, int b);
	public int subtract(int a, int b);
}