package com.javalearning.entity;

public class SecondArith extends ArithImpl {
	@Override
	
	public int add(int a, int b){
		return (a+b)+10;
	}
	
	@Override
	public int subtract(int a, int b) {
		return (a-b)+10;
	}
}
