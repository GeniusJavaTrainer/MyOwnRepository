package com.bvk.converter;

import com.bvk.model.Student;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

public class StudentConverter implements Converter {

	@Override
	public boolean canConvert(Class type) {
		//we only need "Student" object
		return type.equals(Student.class);
	}

	@Override
	public void marshal(Object source, 
            HierarchicalStreamWriter writer, MarshallingContext context) {
	    //do nothing
	}

	@Override
	public Object unmarshal(
            HierarchicalStreamReader reader, UnmarshallingContext context) {
		
		Student obj = new Student();
		
		//get attribute
		obj.setRollno((Integer.valueOf(reader.getAttribute("rollno"))));
		reader.moveDown();
		
		String name = reader.getValue();
		obj.setName(name);
		reader.moveUp();
		
		reader.moveDown();
		
		String branch = reader.getValue();
		obj.setBranch(branch);
		reader.moveUp();
		
		reader.moveDown();
		
		String perc = reader.getValue();
		float percent = Float.parseFloat(perc);
		
		obj.setPercent(percent);
		
		reader.moveUp();
		
        return obj;
	}
}