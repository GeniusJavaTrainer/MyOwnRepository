package com.me.dao;

import java.util.HashMap;
import java.util.Map;

import com.me.entity.Employee;

public class EmployeeDAO {
	private static Map<Integer, Employee>employeeMap = null;
	
	static {
		employeeMap = new HashMap<>();
		
		employeeMap.put(1, new Employee(1,"bvk",300000));
		employeeMap.put(2, new Employee(2,"svk",350000));
		employeeMap.put(1, new Employee(3,"mrp",80000));
		employeeMap.put(2, new Employee(4,"abc",90000));
	}
	
	public void insertData(Employee employee){
		employeeMap.put(employee.getEmpid(), employee);
	}
	
	public Employee getEmployee(int empid){
		return employeeMap.get(empid);
	}
}