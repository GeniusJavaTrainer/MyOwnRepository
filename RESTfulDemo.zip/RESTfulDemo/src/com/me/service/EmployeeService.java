package com.me.service;

import com.me.dao.EmployeeDAO;
import com.me.entity.Employee;

public class EmployeeService {
	private EmployeeDAO employeeDAO;

	public EmployeeService() {
		employeeDAO = new EmployeeDAO();
	}
	
	public void insertRecord(Employee employee){
		System.out.println("In Service");
		employeeDAO.insertData(employee);
	}
	
	public Employee getEmployee(int empid){
		return employeeDAO.getEmployee(empid);
	}
}