package com.me.controller;

import javax.ws.rs.Path;

import javax.ws.rs.core.Response;
import javax.ws.rs.POST;
import javax.ws.rs.FormParam;

import com.me.entity.Employee;
import com.me.service.EmployeeService;

@Path("/employee")
public class EmployeeController {
	private EmployeeService employeeService;
	
	
	public EmployeeController() {
		super();
		employeeService = new EmployeeService();
	}

	@POST
	@Path("/add")
	public Response addEmployee(@FormParam("id") int empid,
			@FormParam("name") String name,
			@FormParam("salary") float salary){
		
		Employee employee = new Employee(empid, name, salary);
		
		employeeService.insertRecord(employee);
		
		return Response.status(200).entity("Employee Added Successfully "
				+ "with id"+empid).build();
	}
	
	/*@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Employee getMessage(@PathParam("id") int empid){
		return employeeService.getEmployee(empid);
	}*/
}