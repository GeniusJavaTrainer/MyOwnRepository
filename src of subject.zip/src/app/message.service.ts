import { Injectable } from '@angular/core';
import { Observable, Subject, pipe } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class MessageService {
  private subject = new Subject<any>();
  constructor() { }

  sendMessage(message: string) {
      this.subject.next(message);
      this.subject.asObservable().subscribe((data) => {
        console.log(""+ data);
      });
  }

  clearMessage() {
      this.subject.next();
  }

  getMessage(): Observable<string> {
      return this.subject.asObservable();
  } 
}