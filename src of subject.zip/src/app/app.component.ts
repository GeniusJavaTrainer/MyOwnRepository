import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { MessageService } from './message.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnDestroy {
  message: string;
  subscription: Subscription;

  constructor(private messageService: MessageService) {
  }

  sendMessage(){
    this.messageService.sendMessage('Hello There!!');
    this.subscription = this.messageService.getMessage().subscribe(message => { this.message = message; });
  }

  clearMessage(){
    this.messageService.clearMessage();
  }

  ngOnDestroy() {
      // unsubscribe to ensure no memory leaks
      this.subscription.unsubscribe();
  }
}