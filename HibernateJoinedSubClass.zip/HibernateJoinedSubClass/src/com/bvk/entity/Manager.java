package com.bvk.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="mgr_store_joined")
public class Manager extends Employee {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5731362362862831344L;
	private String departmentName;

	public Manager() {
		super();
	}

	public Manager(String departmentName) {
		super();
		this.departmentName = departmentName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	@Override
	public String toString() {
		return "Manager [departmentName=" + departmentName + "]";
	}
}