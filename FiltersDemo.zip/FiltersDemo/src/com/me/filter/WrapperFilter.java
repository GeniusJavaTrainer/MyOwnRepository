package com.me.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.me.wrapper.RequestModifier;
import com.me.wrapper.ResponseWrapper;

/**
 * Servlet Filter implementation class WrapperFilter
 */
public class WrapperFilter implements Filter {

    /**
     * Default constructor. 
     */
    public WrapperFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		RequestModifier rm = new RequestModifier(request);
		ResponseWrapper rw = new ResponseWrapper(response);
		
		// pass the request along the filter chain
		chain.doFilter(rm, rw);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
