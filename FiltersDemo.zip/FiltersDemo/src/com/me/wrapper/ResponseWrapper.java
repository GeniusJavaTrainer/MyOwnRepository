package com.me.wrapper;

import javax.servlet.ServletResponse;
import javax.servlet.ServletResponseWrapper;

public class ResponseWrapper extends ServletResponseWrapper {

	public ResponseWrapper(ServletResponse response) {
		super(response);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setContentType(String contentType){
		
		if(contentType.equalsIgnoreCase("text/html") == false){
			contentType = "text/html";
		}
		
		super.setContentType(contentType);
	}
}
