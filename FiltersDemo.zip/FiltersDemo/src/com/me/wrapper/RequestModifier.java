package com.me.wrapper;

import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestWrapper;

public class RequestModifier extends ServletRequestWrapper {

	public RequestModifier(ServletRequest request) {
		super(request);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getParameter(String parameter){
		String param = super.getParameter("num");
		
		if(param == null || param.equals("")){
			param = "1";
		}
		
		return param;
	}
}
