package com.bvk.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bvk.service.ArithImpl;

@Configuration
public class AppConfig {
	@Bean
	public ArithImpl getArithImpl(){
		return new ArithImpl();
	}
}