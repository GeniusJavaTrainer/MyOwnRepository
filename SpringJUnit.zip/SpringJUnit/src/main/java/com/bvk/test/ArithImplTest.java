package com.bvk.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import com.bvk.config.AppConfig;
import com.bvk.service.Arith;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=AppConfig.class,loader=AnnotationConfigContextLoader.class)
public class ArithImplTest {
	
	@Autowired
	private Arith arithImpl;
	@Test
	public final void testAdd() {
		assertEquals(20, arithImpl.add(10, 10));
	}

	@Test
	public final void testSubtract() {
		assertEquals(0, arithImpl.subtract(10, 10));
	}

	@Test
	public final void testMultiply() {
		assertEquals(100, arithImpl.multiply(10, 10));
	}

	@Test
	public final void testDivide() {
		assertEquals(1,arithImpl.divide(10, 10));
	}

}
