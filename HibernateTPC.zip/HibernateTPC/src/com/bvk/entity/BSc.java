package com.bvk.entity;

//import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="stud_bsc_store1")
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class BSc {
	/**
	 * 
	 */
	//private static final long serialVersionUID = -1405847211170687778L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int rollno;
	private String name;
	
	private int physics;
	private int chemistry;
	private int maths;
	
	protected int total;
	protected float percent;
	
	public BSc() {
		super();
	}

	public BSc(int rollno, String name, int physics, int chemistry, int maths) {
		super();
		this.rollno = rollno;
		this.name = name;
		this.physics = physics;
		this.chemistry = chemistry;
		this.maths = maths;
		calculate();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPhysics() {
		return physics;
	}

	public void setPhysics(int physics) {
		this.physics = physics;
	}

	public int getChemistry() {
		return chemistry;
	}

	public void setChemistry(int chemistry) {
		this.chemistry = chemistry;
	}

	public int getMaths() {
		return maths;
	}

	public void setMaths(int maths) {
		this.maths = maths;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public float getPercent() {
		return percent;
	}

	public void setPercent(float percent) {
		this.percent = percent;
	}

	public int getRollno() {
		return rollno;
	}

	protected void calculate(){
		this.total = this.physics + this.chemistry + this.maths;
		this.percent = this.total/3.0f;
	}
	
	@Override
	public String toString() {
		return "BSc [rollno=" + rollno + ", name=" + name + ", physics=" + physics + ", chemistry=" + chemistry
				+ ", maths=" + maths + ", total=" + total + ", percent=" + percent + "]";
	}
}