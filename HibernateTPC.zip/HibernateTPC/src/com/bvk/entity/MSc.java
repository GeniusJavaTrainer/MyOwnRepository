package com.bvk.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="msc_student_store")
public class MSc extends BSc {

	/**
	 * 
	 */
	//private static final long serialVersionUID = -8917259043025106759L;

	private int advancedPhysics;
	private int quantumMechanics;
	
	public MSc() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MSc(int rollno, String name, int physics, int chemistry, int maths,
			int advancedPhysics, int quantumMechanics) {
		super(rollno, name, physics, chemistry, maths);

		this.advancedPhysics = advancedPhysics;
		this.quantumMechanics = quantumMechanics;
		calculate();
	}
	public int getAdvancedPhysics() {
		return advancedPhysics;
	}
	public void setAdvancedPhysics(int advancedPhysics) {
		this.advancedPhysics = advancedPhysics;
	}
	public int getQuantumMechanics() {
		return quantumMechanics;
	}
	public void setQuantumMechanics(int quantumMechanics) {
		this.quantumMechanics = quantumMechanics;
	}
	@Override
	protected void calculate() {
			super.calculate();
			this.total += this.advancedPhysics + this.quantumMechanics;
			this.percent = this.total/5.0f;
	}
	@Override
	public String toString() {
		return "MSc [Rollno =" + getRollno() + ", Name =" + getName() + ", Physics =" + getPhysics()
				+ ", Chemistry =" + getChemistry() + ", Maths=" + getMaths() + ", advancedPhysics="
				+ advancedPhysics + ", quantumMechanics=" + quantumMechanics + 
				", Total = " + this.total + ", Percent = " + this.percent + "]";
	}
	
	
	
}
