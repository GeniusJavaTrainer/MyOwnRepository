package com.bvk.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bvk.entity.BSc;
import com.bvk.entity.MSc;

public class ClientTablePerClass {

	public static void main(String[] args) {
		SessionFactory sf = new Configuration().configure().
				addAnnotatedClass(com.bvk.entity.BSc.class).
				addAnnotatedClass(com.bvk.entity.MSc.class).
				buildSessionFactory();
		
		Session session = sf.openSession();
		
		Transaction tx = null;
		
		try{
			BSc bsc = new BSc(1, "bvk", 99, 99, 99);
			MSc msc = new MSc(1, "svk", 99, 99, 99,95,98);
			
			
			tx = session.beginTransaction();
			
			session.save(bsc);
			session.save(msc);
			
			tx.commit();
			
			System.out.println("Records inserted successfully...");
		}catch(Exception e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}	}
}