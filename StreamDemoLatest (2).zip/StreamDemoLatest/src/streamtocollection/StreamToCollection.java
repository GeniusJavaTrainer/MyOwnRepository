package streamtocollection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamToCollection {

	public static void main(String[] args) {
		Stream<Integer> numbers = Stream.of(1,2,3,4,5);
		List<Integer>nums = numbers.collect(Collectors.toList());
		nums.forEach(System.out::println);
		
		numbers = Stream.of(1,2,3,4,5,5);
		Set<Integer>numset = numbers.collect(Collectors.toSet());
		numset.forEach(System.out::println);
	}
}