package streambasic;
import java.util.stream.IntStream;

public class UsePeek {

	public static void main(String[] args) {
		//peek used for intermediate operations. For testing purpose only.
		long count = IntStream.of(10,20,30,40,50)
					 .peek(i->System.out.print(i+"\t"))
					 .map(i->i*i)
					 .peek(i->System.out.println(i))
					 .count();
		System.out.println("\nCount: " + count);
	}
}