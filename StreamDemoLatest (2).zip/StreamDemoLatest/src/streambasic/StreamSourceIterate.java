package streambasic;
import java.util.stream.IntStream;

public class StreamSourceIterate {

	public static void main(String[] args) {
		// Prints first five odd numbers
		IntStream.iterate(1, i->i+2).limit(5).forEach(System.out::println);
	}
}