package streambasic;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamOf {

	public static void main(String[] args) {
		Stream.of(1,2,3,4).forEach(System.out::println);
		IntStream.of(1,2,3,4).forEach(System.out::println);
		
		IntStream.builder().add(10).add(20).build().forEach(System.out::println);
	}
}