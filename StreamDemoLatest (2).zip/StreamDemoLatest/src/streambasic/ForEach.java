package streambasic;
import java.util.Arrays;
import java.util.List;

public class ForEach {

	public static void main(String[] args) {
		List<Integer>numbers = Arrays.asList(10,20,30,40);
		//The list is read-only
		numbers.forEach(System.out::println);
	}
}