package streambasic;
import java.util.stream.IntStream;

public class FilterEvenNumbers {

	public static void main(String[] args) {
		IntStream
		.rangeClosed(1, 10)
		.filter(i-> (i%2)==0)//Intermediate operation
		.forEach(System.out::println);
	}
}