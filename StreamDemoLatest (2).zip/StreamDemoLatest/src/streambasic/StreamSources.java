package streambasic;
import java.util.stream.IntStream;

public class StreamSources {
	public static void main(String[] args) {
		IntStream.range(1,10).limit(5).forEach(System.out::println);
	}
}