package com.me.service;

import java.util.List;

import com.me.dao.StudentDAO;
import com.me.entity.Student;

public class StudentService {
	private static StudentDAO sd = new StudentDAO();

	public int insertStudent(Student s){
		int status = sd.insert(s);

		return status;
	}
	
	public Student viewStudent(int id){
		Student s = new Student();
		s = sd.view(id);
		
		return s;
	}
	
	public List<Student>viewAllStudents(){
		List<Student>stu = sd.viewAll();
		return stu;
	}
}