package com.me.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.me.entity.User;
import com.me.helper.DB;

public class UserDAO {

	public User search(String username, String password){
		User user = new User();
		Connection connDB = null;
		PreparedStatement ps = null;
		String query = new String("SELECT user_Id,username,password, category FROM users WHERE username=? and password=?");
		ResultSet rs = null;
		
		try{
			connDB = DB.CreateConnection();
			ps = connDB.prepareStatement(query);
			ps.setString(1, username);
			ps.setString(2, password);
			
			rs = ps.executeQuery();
			
			while(rs.next()){
				user.setUserId(rs.getInt("user_id"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setCategory(rs.getString("category"));
			}
		}catch(ClassNotFoundException cnfe){
			System.out.println(cnfe.getMessage());
		}catch(SQLException se){
			System.out.println(se.getMessage());
		}finally{
			try{
			DB.closeConnection();
			}catch(SQLException se){
				System.out.println(se.getMessage());
			}
		}
		return user;
	}
}
