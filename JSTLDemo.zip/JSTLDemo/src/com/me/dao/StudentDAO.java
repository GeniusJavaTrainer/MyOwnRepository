package com.me.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.me.entity.Student;
import com.me.helper.DB;

public class StudentDAO {

	public StudentDAO() {

	}

	public int insert(Student s) {
		Connection connDB = null;
		PreparedStatement ps = null;
		int isInserted = 0;
		String query = new String("INSERT INTO student VALUES(?,?,?)");
		try {
			connDB = DB.CreateConnection();
			ps = connDB.prepareStatement(query);
			ps.setInt(1, s.getRollno());
			ps.setString(2, s.getName());
			ps.setFloat(3, s.getPercent());

			isInserted = ps.executeUpdate();
		} catch (ClassNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		} catch (SQLException se) {
			System.out.println(se.getMessage());
		} finally {
			try {
				DB.closeConnection();
			} catch (SQLException se) {
				System.out.println(se.getMessage());
			}
		}
		return isInserted;
	}

	public Student view(int id) {
		Student student = new Student();
		Connection connDB = null;
		PreparedStatement ps = null;
		String query = new String("SELECT id,name,percent FROM student WHERE id=?");
		ResultSet rs = null;
		System.out.println(id);
		try {
			connDB = DB.CreateConnection();
			ps = connDB.prepareStatement(query);
			ps.setInt(1, id);

			rs = ps.executeQuery();

			while (rs.next()) {
				student.setRollno(id);
				student.setName(rs.getString("name"));
				student.setPercent(rs.getFloat("percent"));
			}
		} catch (ClassNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		} catch (SQLException se) {
			System.out.println(se.getMessage());
		} finally {
			try {
				DB.closeConnection();
			} catch (SQLException se) {
				System.out.println(se.getMessage());
			}
		}
		return student;
	}

	public List<Student> viewAll() {
		Connection connDB = null;
		PreparedStatement ps = null;
		String query = new String("SELECT id,name,percent FROM student");
		ResultSet rs = null;
		List<Student> studentList = new ArrayList<Student>();
		try {
			connDB = DB.CreateConnection();
			ps = connDB.prepareStatement(query);

			rs = ps.executeQuery();

			while (rs.next()) {
				Student student = new Student();
				student.setRollno(rs.getInt("id"));
				student.setName(rs.getString("name"));
				student.setPercent(rs.getFloat("percent"));

				studentList.add(student);
			}
		} catch (ClassNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		} catch (SQLException se) {
			System.out.println(se.getMessage());
		} finally {
			try {
				DB.closeConnection();
			} catch (SQLException se) {
				System.out.println(se.getMessage());
			}
		}
		return studentList;
	}
}