create table users(
user_id int primary key,
username varchar2(40),
password varchar2(40),
category varchar2(10)
)

insert into users values(1,'ajay123','ajay123','student')

insert into users values(2,'abc123','abc123','faculty')

insert into users values(3,'xyz345','xyz345','principal')

insert into users values(4,'pqr987','pqr987','admin')