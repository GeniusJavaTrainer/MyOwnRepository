package com.bvk.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bvk.entity.Address;
import com.bvk.entity.Student;

public class ClientOneToOne {
	public static void main(String[] args) {
		try{
			SessionFactory sessionFactory = new Configuration().configure().
					addAnnotatedClass(com.bvk.entity.Student.class).
					addAnnotatedClass(com.bvk.entity.Address.class).
					buildSessionFactory();
			
			Session session = sessionFactory.openSession();
			
			Transaction tx = session.beginTransaction();
			
			Student student = new Student();
			
			student.setStudentId(1);
			student.setName("abc");
			
			Address address = new Address();
			address.setAddressId(1);
			address.setCity("Pune");
			address.setState("Maharashtra");
			
			student.setAddress(address);
			
			session.save(student);
			
			tx.commit();
			
			System.out.println("Record inserted...");
			}catch(Exception e){
				System.out.println("Record couldn't be inserted..." + e.getMessage());
				e.printStackTrace();
			}
	}
}