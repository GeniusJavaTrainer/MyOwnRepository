/**
 * 
 */

var app = angular.module("myApp", []);
app.controller("myCtrl", function($scope) {
    $scope.firstName = "Bhalchandra";
    $scope.lastName = "Kalloorkar";
});
