package com.springforbeginners.javabasedconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BookConfig {
    @Bean
    public Author author() {
        Author author = new Author();
        author.setName("Sharanam");
        author.setAddress("Mumbai");
        return author;
    }

    @Bean
    public Book book() {
        Book book = new Book();
        book.setYear("2012");
        book.setIsbn("80-000-000");
        book.setAuthor(author());        
        return book;
    }
}