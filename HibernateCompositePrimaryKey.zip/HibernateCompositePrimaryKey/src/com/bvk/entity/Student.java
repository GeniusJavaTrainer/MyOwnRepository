package com.bvk.entity;

import java.io.Serializable;

public class Student implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4693670573393892251L;
	private int rollno;
	private int examid;
	private float percent;
	
	public Student() {
		super();
	}

	public Student(int rollno, int examid, float percent) {
		super();
		this.rollno = rollno;
		this.examid = examid;
		this.percent = percent;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public int getExamid() {
		return examid;
	}

	public void setExamid(int examid) {
		this.examid = examid;
	}

	public float getPercent() {
		return percent;
	}

	public void setPercent(float percent) {
		this.percent = percent;
	}

	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", examid=" + examid + ", percent=" + percent + "]";
	}
	
	
}
