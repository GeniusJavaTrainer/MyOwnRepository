package com.bvk.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bvk.entity.Student;

public class ClientCompositeStudent {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml"); 

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		Student student = new Student(1, 1, 90.89f);

		Transaction tx=session.beginTransaction();
	    session.save(student);
	    System.out.println("Record inserted successfully.....!!");
	    
	    tx.commit();     

		session.close();
		factory.close();
	}
}