package com.bvk.groceryapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroceryAPIApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroceryAPIApplication.class, args);
	}
}