package com.bvk.groceryapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bvk.groceryapp.model.ShoppingList;
import com.bvk.groceryapp.service.ShoppingListService;

@RestController
public class ShoppingListController {
	
	@Autowired
	private ShoppingListService service;
	
	//localhost:8080
	
	@RequestMapping(method=RequestMethod.POST, value="/shoppinglist/")
	public void addShoppingList(@RequestBody ShoppingList shoppingList){
		/*ShoppingList shoppingList = new ShoppingList();
		shoppingList.setTitle("Walmart");*/
		this.service.addShoppingList(shoppingList);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/shoppinglist")
	public void deleteShoppingList(@RequestBody ShoppingList shoppingList){
		this.service.deleteShoppingList(shoppingList.getShoppingListId());
	}
	
	@RequestMapping("/shoppinglists/{shoppingListId}")
	public ShoppingList getShoppingLists(@PathVariable int shoppingListId){
		/*ShoppingList shoppingList = new ShoppingList();
		shoppingList.setTitle("Walmart");*/
		return this.service.getShoppingListById(shoppingListId);
	}
	
	@RequestMapping("/shoppinglists")
	public List<ShoppingList> getShoppingLists(){
		/*ShoppingList shoppingList = new ShoppingList();
		shoppingList.setTitle("Walmart");*/
		//return shoppingList;
		return this.service.getAllShoppingLists();
	}
	
	@RequestMapping("/")
	public String hello(){
		return "Hello World";
	}
}