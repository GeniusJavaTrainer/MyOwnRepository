package com.bvk.groceryapp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.bvk.groceryapp.model.ShoppingList;

@Service
public class ShoppingListService {
	
	private List<ShoppingList>shoppingLists;
	
		public ShoppingListService(){
			shoppingLists = new ArrayList<>();
			
			shoppingLists.add(new ShoppingList(1,"Phoenix Market City"));
			shoppingLists.add(new ShoppingList(2,"WalMart"));
		}
		
		public void addShoppingList(ShoppingList shoppingList){
			this.shoppingLists.add(shoppingList);
		}
		
		public void deleteShoppingList(int shoppingListId){
			ShoppingList shoppingList = getShoppingListById(shoppingListId);
			this.shoppingLists.remove(shoppingList);
		}
		
		public ShoppingList getShoppingListById(int shoppingListId){
			return shoppingLists.stream().filter(x->x.getShoppingListId()==shoppingListId).findFirst().get();
		}
		public List<ShoppingList> getAllShoppingLists(){
			return this.shoppingLists;
		}
}