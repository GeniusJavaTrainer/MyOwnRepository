package com.bvk.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity

public class Department {
	@Id
	private int deptId;
	
	private String name;
	
	@OneToMany(targetEntity=Location.class,cascade = CascadeType.ALL)
	private Set<Location>locations;

	public Department() {
		super();
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Location> getLocations() {
		return locations;
	}

	public void setLocations(Set<Location> locations) {
		this.locations = locations;
	}

	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", name=" + name + ", locations=" + locations + "]";
	}	
}