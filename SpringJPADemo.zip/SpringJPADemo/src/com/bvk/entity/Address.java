package com.bvk.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="address123")
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int addressId;
	
	@Column
	private String street;
	
	@Column
	private String houseNo;
	
	@Column
	private String city;
	
	@Column
	private String state;
	
	@Column
	private String country;

	public Address() {
		super();
	}

	public Address(int addressId, String street, String houseNo, String city, String state, String country) {
		super();
		this.addressId = addressId;
		this.street = street;
		this.houseNo = houseNo;
		this.city = city;
		this.state = state;
		this.country = country;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", street=" + street + ", houseNo=" + houseNo + ", city=" + city
				+ ", state=" + state + ", country=" + country + "]";
	}
}