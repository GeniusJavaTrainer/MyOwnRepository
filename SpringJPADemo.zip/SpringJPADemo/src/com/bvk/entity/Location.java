package com.bvk.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Location {

	@Id
	private int locationId;
	
	private String name;

	public Location(int locationId, String name) {
		super();
		this.locationId = locationId;
		this.name = name;
	}

	public int getLocationId() {
		return locationId;
	}

	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Location [locationId=" + locationId + ", name=" + name + "]";
	}	
}