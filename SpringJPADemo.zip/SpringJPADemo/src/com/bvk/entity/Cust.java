package com.bvk.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="customer123")

//@NamedQuery(name = "findAllCustomersWithName", query = "select c from Cust c where c.name like :fn")
/*@NamedQueries({
@NamedQuery(name = "findAllCustomersWithAddress", query = "select c from Cust c where c.address like :ct")})*/
public class Cust {
	@Id
	@Column(name="custId")
	private int customerId;
	
	//@Column(name="customername")
	private String name;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Address address;
	
/*	private String city;
	
	private String state;
	
	private String country;
	
	private String mobile;
	
	private String telephone;
	
	private String fax;
	
	private String email;*/

	public Cust() {
		super();
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Cust [customerId=" + customerId + ", name=" + name + ", address=" + address + "]";
	}

/*	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}*/

/*	@Override
	public String toString() {
		return "Cust [customerId=" + customerId + ", name=" + name + ", address=" + address + ", city=" + city
				+ ", state=" + state + ", country=" + country + ", mobile=" + mobile + ", telephone=" + telephone
				+ ", fax=" + fax + ", email=" + email + "]";
	}*/
	
	
}
