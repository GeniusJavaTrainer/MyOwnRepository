package com.bvk.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="customers")
public class Custom {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int customerId;

	private String firstName;

	private String lastName;

	private String gender;

	@ManyToMany(targetEntity=Addresses.class,cascade = CascadeType.ALL,
			fetch=FetchType.LAZY)
	private Set<Addresses> addresses;
	
	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Set<Addresses> getAddresses() {
		return addresses;
	}

	public void setAddresses(Set<Addresses> addresses) {
		this.addresses = addresses;
	}
}