package com.bvk.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.bvk.entity.Customer;

public class DeleteDemo {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
        EntityManager em=emf.createEntityManager();
        Customer customer = new Customer();//New
        customer.setCustomerId(2030);
        customer.setName("Srinath");
        //customer.setCustomerId(7);
        try{
            EntityTransaction entr=em.getTransaction();
            entr.begin();
            
            
            /*customer.setAddress("Pune");
            customer.setCity("Pune");
            customer.setCountry("Bharat");*/
            customer = em.find(Customer.class, 2030);
            em.remove(customer);//persistent
            entr.commit();
            System.out.println("Successfully deleted into database.");
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        finally{
            em.close();//detached
        }
	}
}