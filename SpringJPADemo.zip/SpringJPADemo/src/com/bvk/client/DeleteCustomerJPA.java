package com.bvk.client;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.bvk.entity.Customer;

/**
 *
 * @author Administrator
 */
public class DeleteCustomerJPA {
    
    public static void main(String arg[]){
    	EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("JPA");
		EntityManager em = emf.createEntityManager();
		Customer cusobj = new Customer();
		cusobj=em.find(Customer.class, 2160);
		System.out.println("Record before deletion: " + cusobj);
		try{
            EntityTransaction entr=em.getTransaction();
            entr.begin();

            em.remove(cusobj);
            
            entr.commit();
            
            System.out.println("Successfully deleted into database.");
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        finally{
            em.close();//detached
        }
		
		System.out.println("Record deleted successfully");
    }
}