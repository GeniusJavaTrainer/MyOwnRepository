package com.bvk.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.bvk.entity.Customer;

public class FindCustomerbyIDJPA {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("JPA");
		EntityManager em = emf.createEntityManager();
		
		Customer cusobj = new Customer();
		cusobj=em.find(Customer.class, 2);
		System.out.println("Customer ID : " + cusobj.getCustomerId());
		System.out.println("Customer Name : " + cusobj.getName());
		//System.out.println("Customer Last Name : " + cusobj.getLastName());
//		System.out.println("Customer City : " + cusobj.getCity());
	}
}