package com.bvk.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class NativeQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA");
	    EntityManager entityManager = entityManagerFactory.createEntityManager();
	    
	    try{
            EntityTransaction entr=entityManager.getTransaction();
            entr.begin();

            Query query = entityManager.createNativeQuery("ALTER TABLE customer DROP COLUMN address");    	    
    	    int result = query.executeUpdate();
            entr.commit();
            System.out.println(result);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        finally{
            entityManager.close();//detached
        }
	    
	}
}