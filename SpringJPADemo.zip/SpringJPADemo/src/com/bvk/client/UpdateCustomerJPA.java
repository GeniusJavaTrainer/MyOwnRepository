package com.bvk.client;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.bvk.entity.Customer;

/**
 *
 * @author Administrator
 */
public class UpdateCustomerJPA {
    
    public static void main(String arg[]){
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
        EntityManager em=emf.createEntityManager();
        Customer cusobj = new Customer();
        //Address address = new Address();
        
        //address.setHouseNo("E-3");
		//cusobj=em.find(Customer.class, 2);
        try{
            EntityTransaction entr=em.getTransaction();
            entr.begin();

            cusobj.setName("Bhalchandra");
            cusobj.setCustomerId(2160);
            /*cusobj.setLastName("Kalloorkar");
            cusobj.setGender("M");
            cusobj.setAddress(address);*/
            /*cusobj.setCity("Mumbai");
            cusobj.setCountry("Bharat");*/
            em.merge(cusobj);//persistent
            entr.commit();
            System.out.println("Successfully updated into database.");
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        finally{
            em.close();//detached
        }
    }
}