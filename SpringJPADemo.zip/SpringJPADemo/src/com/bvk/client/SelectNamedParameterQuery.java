package com.bvk.client;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.bvk.entity.Customer;

public class SelectNamedParameterQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA");
	    EntityManager entityManager = entityManagerFactory.createEntityManager();
	    
	    String fname = null;
	    
	    List<Customer> custList = null;
	    
	    Scanner scInput = new Scanner(System.in);
	    
	    Query query = entityManager
				.createQuery("select m from Customer m where name like :fname");
	    
	    System.out.print("What is pattern of name of the customer: ");
	    fname = scInput.nextLine();
	    
	    fname = "%" + fname + "%";
	    
		query.setParameter("fname", fname);
        query.setMaxResults(10);
        
        custList = query.getResultList();
        
        for (Customer customer : custList) {
			System.out.println(customer);
		}
	}

}
