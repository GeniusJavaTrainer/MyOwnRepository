package com.bvk.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.bvk.entity.Address;
import com.bvk.entity.Cust;

public class CreateOneToOne {
	public static void main(String arg[]){
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
        EntityManager em=emf.createEntityManager();
        try{
            EntityTransaction entr=em.getTransaction();
            entr.begin();
            Cust customer = new Cust();//New
            customer.setCustomerId(190);
            customer.setName("abc");
                        
            Address address = new Address();
            //address.setAddressId(2);
            address.setHouseNo("A2");
            address.setStreet("N. G. Road");
            address.setCity("Mumbai");
            address.setState("Maharashtra");
            address.setCountry("Bharat");
            
            customer.setAddress(address);
            
            em.persist(customer);//persistent
            entr.commit();
            System.out.println("Successfully added into database.");
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        finally{
            em.close();//detached
        }
    }
}
