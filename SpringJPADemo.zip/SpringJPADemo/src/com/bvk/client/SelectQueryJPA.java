package com.bvk.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.bvk.entity.Customer;

public class SelectQueryJPA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA");
	    EntityManager entityManager = entityManagerFactory.createEntityManager();
	    
	    Query query = entityManager
                .createQuery("select c from Customer c where custId = ?1");
        query.setParameter(1, 10);
        query.setMaxResults(2);
        List<Customer> custList = query.getResultList();
        
        for (Customer customer : custList) {
			System.out.println(customer);
		}
	}
}