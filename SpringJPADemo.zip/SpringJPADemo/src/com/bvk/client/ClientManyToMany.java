package com.bvk.client;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.bvk.entity.Addresses;
import com.bvk.entity.Custom;

public class ClientManyToMany {

	public static void main(String[] args) {
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
        EntityManager em=emf.createEntityManager();
        try{
            EntityTransaction entr=em.getTransaction();
            entr.begin();

            Addresses addresses1 = new Addresses();
            addresses1.setAddressId(100);
            addresses1.setHouseNo("44");
            addresses1.setStreet("M. G. Road");
            addresses1.setCity("Pune");
            addresses1.setState("Maharashtra");
            addresses1.setCountry("India");
            
            Addresses addresses2 = new Addresses();
            addresses2.setAddressId(200);
            addresses2.setHouseNo("49");
            addresses2.setStreet("D. G. Road");
            addresses2.setCity("Bengaluru");
            addresses2.setState("Karnataka");
            addresses2.setCountry("India");
            
            Set<Addresses>addressSet = new HashSet<Addresses>();
            addressSet.add(addresses1);
            addressSet.add(addresses2);
            
            Custom cust1 = new Custom();
            //cust1.setCustomerId(1);
            cust1.setFirstName("Ajay");
            cust1.setLastName("Pandit");
            cust1.setGender("M");
            cust1.setAddresses(addressSet);
            
            Custom cust2 = new Custom();
            //cust2.setCustomerId(2);
            cust2.setFirstName("Ananya");
            cust2.setLastName("Pandit");
            cust2.setGender("F");
            cust2.setAddresses(addressSet);
            
            em.persist(cust1);
            em.persist(cust2);
            
            entr.commit();
            System.out.println("Successfully added into database.");
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        finally{
            em.close();//detached
        }
	}
}