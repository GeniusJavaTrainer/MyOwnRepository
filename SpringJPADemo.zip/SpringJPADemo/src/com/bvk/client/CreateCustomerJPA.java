package com.bvk.client;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.bvk.entity.Customer;

/**
 *
 * @author Administrator
 */
public class CreateCustomerJPA {
    
    public static void main(String arg[]){
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
        EntityManager em=emf.createEntityManager();
        Customer customer = new Customer();//New/ Transient
        customer.setName("Srinath");
        //customer.setCustomerId(7);
        try{
            EntityTransaction entr=em.getTransaction();
            entr.begin();
            
            
            /*customer.setAddress("Pune");
            customer.setCity("Pune");
            customer.setCountry("Bharat");*/
            em.persist(customer);//persistent
            entr.commit();
            System.out.println("Successfully added into database.");
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        finally{
            em.close();//detached
        }
    }
}