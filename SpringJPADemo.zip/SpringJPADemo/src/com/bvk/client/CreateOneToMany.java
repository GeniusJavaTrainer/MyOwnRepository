package com.bvk.client;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.bvk.entity.Department;
import com.bvk.entity.Location;

public class CreateOneToMany {

	public static void main(String[] args) {
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
        EntityManager em=emf.createEntityManager();
        try{
            EntityTransaction entr=em.getTransaction();
            entr.begin();
            Department department = new Department();//New
            
            department.setDeptId(4);
            department.setName("Sales");
            
            Location location1 = new Location(5, "Hyderabad");
            Location location2 = new Location(6, "Bengaluru");
            
            Set<Location>locations = new HashSet<Location>();
            
            locations.add(location1);
            locations.add(location2);
            
            department.setLocations(locations);
            
            em.persist(department);//persistent
            entr.commit();
            System.out.println("Successfully added into database.");
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        finally{
            em.close();//detached
        }
	}
}