package com.bvk.client;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.bvk.entity.Customer;

public class SelectNamedQueryAnnotated {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA");
	    EntityManager entityManager = entityManagerFactory.createEntityManager();
	    
	    String fname = null;
	    
	    List<Customer> custList = null;
	    
	    Scanner scInput = new Scanner(System.in);
	    
	    Query query = entityManager
				.createNamedQuery("findAllCustomersWithName");
	    
	    System.out.print("What is pattern of name of the customer: ");
	    fname = scInput.nextLine();
	    
	    fname = "%" + fname + "%";
	    
		query.setParameter("fn", fname);
        query.setMaxResults(10);
        
        custList = query.getResultList();
        
        for (Customer customer : custList) {
			System.out.println(customer);
		}
        
       /* query = entityManager
				.createNamedQuery("findAllCustomersWithAddress");
        
        System.out.print("What is name of the city: ");
	    fname = scInput.nextLine();
	    
	    fname = "%" + fname + "%";
	    
		query.setParameter("ct", fname);
        query.setMaxResults(10);
        
        custList = query.getResultList();
        
        for (Cust customer : custList) {
			System.out.println(customer);
		}*/
        
/*        query = entityManager
				.createNamedQuery("findAllCustomersWithCountry");
        
        System.out.print("What is name of the country: ");
	    fname = scInput.nextLine();
	    
	    fname = "%" + fname + "%";
	    
		query.setParameter("cn", fname);
        query.setMaxResults(10);
        
        custList = query.getResultList();
        
        for (Cust customer : custList) {
			System.out.println(customer);
		}*/
        
        scInput.close();
	}
}