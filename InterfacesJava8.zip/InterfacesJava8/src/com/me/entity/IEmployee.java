package com.me.entity;

public interface IEmployee {
	void calculateSalary();
}