package com.me.entity;

public interface IVehicleService {
	float perKM = 19.50f;
	void calcTaxiBill();
}