package com.me.entity;

public class Rectangle implements IShape {
	private int length;
	private int breadth;
	
	private int area;
	private int perimeter;
	
	public Rectangle(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	}

	@Override
	public void calcArea() {
		this.area = this.length * this.breadth;
	}

	@Override
	public void calcPerimeter() {
		this.perimeter = 2 * (this.length + this.breadth);
	}

	@Override
	public String toString() {
		return "Rectangle [length=" + length + ", breadth=" + breadth + ", area=" + area + ", perimeter=" + perimeter
				+ "]";
	}
}