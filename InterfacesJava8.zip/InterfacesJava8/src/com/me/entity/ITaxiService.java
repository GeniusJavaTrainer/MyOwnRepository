package com.me.entity;

public interface ITaxiService {
	void calcTaxiService();
}