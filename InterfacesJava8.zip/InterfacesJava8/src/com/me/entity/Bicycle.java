package com.me.entity;

public class Bicycle implements IVehicle {

	@Override
	public void accelerate() {
		System.out.println("Accelerating by means of foot pedal.");
	}

	@Override
	public void applyBrakes() {
		System.out.println("Accelerating using hand brakes.");
	}
}