package com.me.entity;

public interface IFoodService {
	void calcFoodBill();
}