package com.me.entity;

public interface MyInterface {
	float number = 10.89f;
	//All variables declared here are public, static & final by default
	// These modifiers cannot be changed.
	
	void methodA();//All methods declared in an interface are public & abstract by default
	// These modifiers cannot be changed.
	void methodB();
}