package com.me.entity;

public interface AnotherInterface {
	void methodA();
	void methodC();
}