package com.me.entity;

public class Hospital implements RoomOccupier {

}