package com.me.entity;

public class BestLodge implements IRoomService, IFoodService, IVehicleService {

	@Override
	public void calcTaxiBill() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcFoodBill() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calculateRoomBill() {
		// TODO Auto-generated method stub

	}

}
