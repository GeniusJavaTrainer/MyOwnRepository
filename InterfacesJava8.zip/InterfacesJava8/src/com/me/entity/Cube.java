package com.me.entity;

public class Cube implements Shape, Volume {

	@Override
	public void printVolume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void printArea() {
		// TODO Auto-generated method stub

	}
}