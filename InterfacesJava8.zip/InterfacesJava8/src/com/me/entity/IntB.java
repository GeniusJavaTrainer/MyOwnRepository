package com.me.entity;

public interface IntB {
	void methodA();
	void methodB();
	void methodC();
}