package com.me.entity;

public interface IMasterLodge extends ITaxiService, IFoodService, RoomOccupier {

}