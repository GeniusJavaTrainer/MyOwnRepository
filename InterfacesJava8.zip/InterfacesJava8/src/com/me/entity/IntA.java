package com.me.entity;

public interface IntA {
	default void methodA(){}
	
	public static void methodStatic(){
		System.out.println("Inside static method.");
	}
	
	default void methodB(){};
	default void methodC(){};
	default void methodD(){};
	default void methodE(){};
	default void methodF(){};
	default void methodG(){};
	default void methodH(){};
	default void methodI(){};
	default void methodJ(){};
}