package com.me.client;

import com.me.entity.Hospital;

public class ClientHospital {
	public static void main(String[] args) {
		Hospital hospital = new Hospital();
		hospital.calculateRoomBill();
	}
}
