package com.me.client;

import com.me.entity.Bicycle;
import com.me.entity.MotorCycle;

public class ClientVehicle {

	public static void main(String[] args) {
		Bicycle bicycle = new Bicycle();
		MotorCycle bike = new MotorCycle();
		
		bicycle.accelerate();
		bicycle.applyBrakes();
		
		bike.accelerate();
		bike.applyBrakes();
	}
}