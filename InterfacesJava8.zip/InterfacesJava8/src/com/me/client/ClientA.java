package com.me.client;

import com.me.entity.ABImpl;
import com.me.entity.IntA;

public class ClientA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ABImpl a = new ABImpl();
		a.methodA();
		
		IntA.methodStatic();
	}
}