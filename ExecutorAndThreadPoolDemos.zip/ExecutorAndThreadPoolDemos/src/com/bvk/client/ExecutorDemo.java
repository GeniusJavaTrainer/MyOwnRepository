package com.bvk.client;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import com.bvk.thread.Task;

public class ExecutorDemo {

	public static void main(String[] args) {
		Executor executor = Executors.newSingleThreadExecutor();
		Task task = new Task();
		
		executor.execute(task);
		executor.execute(task);
	}
}