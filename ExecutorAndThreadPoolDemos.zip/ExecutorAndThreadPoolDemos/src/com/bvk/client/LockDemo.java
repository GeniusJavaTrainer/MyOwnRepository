package com.bvk.client;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.bvk.thread.Person;

public class LockDemo {

	public static void main(String[] args) {
		Lock machine = new ReentrantLock();
		// list of people waiting to access the machine
		new Person(machine, "Mickey");
		new Person(machine, "Donald");
		new Person(machine, "Tom");
		new Person(machine, "Jerry");
		new Person(machine, "Casper");
	}
}