package com.bvk.thread;

import java.util.concurrent.ThreadFactory;

public class MaxPriorityThreadFactory implements ThreadFactory {
	private static long count = 0;
	@Override
	public Thread newThread(Runnable r) {
		Thread temp = new Thread(r);
		temp.setName("prioritythread" + count++);
		temp.setPriority(Thread.MAX_PRIORITY);
		return temp;
	}
	
	public class ARunnable implements Runnable {
		public void run() {
		System.out.println("Running the created thread ");
		}
	}
}