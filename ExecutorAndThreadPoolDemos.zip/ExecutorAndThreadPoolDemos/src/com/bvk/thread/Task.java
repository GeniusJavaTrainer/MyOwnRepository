package com.bvk.thread;

public class Task implements Runnable {

	@Override
	public void run() {
		System.out.println("Calling Task.run() ");
	}
}