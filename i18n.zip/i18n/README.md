# Spring boot i18n

Tutorials related to this project:

1. [Spring boot i18n example](https://howtodoinjava.com/spring-boot2/rest/i18n-internationalization/)