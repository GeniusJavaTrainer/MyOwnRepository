import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class AdjListFlexible {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		Scanner sn = new Scanner(System.in);
		
        Queue<Integer>adjList[] = null;

        Queue<Integer>queue = new LinkedList<>();
        
        boolean visited[] = null;
        
        String data[]=sn.nextLine().split(" ");
        int n=Integer.parseInt(data[0]);
        int m=Integer.parseInt(data[1]);
      
        adjList = new Queue[n];
        visited = new boolean[n];
        
        for (int i = 0; i < adjList.length; i++) {
			adjList[i] = new LinkedList<Integer>();
		}
        
        for(int i=0;i<m;i++) {
        	data=sn.nextLine().split(" ");

        	adjList[Integer.parseInt(data[0])-1].add(Integer.parseInt(data[1]));
        	adjList[Integer.parseInt(data[1])-1].add(Integer.parseInt(data[0]));
        }
        
        int value = 1;
        visited[value-1] = true;
        System.out.print(value+"\t");
        queue.add(value);
        int i = 0;
        while(queue.size() != 0){
        	value = queue.remove();
        	Queue<Integer> adj = adjList[i++];
        	
        	while(!adj.isEmpty()){
        		value = adj.remove();
        		if(visited[value-1] == false){
        			queue.add(value);
        			System.out.print(value+"\t");
        			visited[value-1] = true;
        		}
        	}
        }
        sn.close();
	}
}