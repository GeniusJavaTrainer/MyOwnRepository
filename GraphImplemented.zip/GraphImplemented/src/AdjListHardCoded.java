import java.util.LinkedList;
import java.util.Queue;

public class AdjListHardCoded {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
        Queue<Integer>adjList[] = new Queue[8];

        Queue<Integer>queue = new LinkedList<>();
        
        boolean visited[] = new boolean[8];
        
        for (int i = 0; i < adjList.length; i++) {
			adjList[i] = new LinkedList<Integer>();
		}
        
        adjList[0].add(2);
        adjList[0].add(3);
        
        adjList[1].add(1);
        adjList[1].add(4);
        adjList[1].add(5);
        
        adjList[2].add(1);
        adjList[2].add(6);
        adjList[2].add(7);
        
        adjList[3].add(2);
        adjList[3].add(8);
        
        adjList[4].add(2);
        adjList[4].add(8);
        
        adjList[5].add(3);
        adjList[5].add(8);
        
        adjList[6].add(3);
        adjList[6].add(8);
        
        adjList[7].add(4);
        adjList[7].add(5);
        adjList[7].add(6);
        adjList[7].add(7);
        
        int value = 1;
        visited[value-1] = true;
        System.out.print(value+"\t");
        queue.add(value);
        int i = 0;
        while(queue.size() != 0){
        	value = queue.remove();
        	Queue<Integer> adj = adjList[i++];
        	
        	while(!adj.isEmpty()){
        		value = adj.remove();
        		if(visited[value-1] == false){
        			queue.add(value);
        			System.out.print(value+"\t");
        			visited[value-1] = true;
        		}
        	}
        }
        
	}
}