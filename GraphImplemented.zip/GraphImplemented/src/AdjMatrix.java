import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class AdjMatrix {

    public static void main(String[] args) throws Exception {
        
        Scanner sn=new Scanner(System.in);
        
        final int INIT=0;//vertex not visited
        final int WAIT=1;//vertex being visited
        final int VISITED=2;//vertex visited.
        
        	System.out.println("Enter vertices & edges separated by space:");
            String data[]=sn.nextLine().split(" ");
            int n=Integer.parseInt(data[0]);//vertices
            int m=Integer.parseInt(data[1]);//no. of edges
          
            int state[]=new int[n+1];//whether a particular vertex is visited or not.
            int adj[][]=new int[n+1][n+1];//One row, one column extra for mapping convenience.

            System.out.println("Enter edges separated by space:");
            for(int i=0;i<m;i++)
                {
                data=sn.nextLine().split(" ");

                adj[Integer.parseInt(data[0])][Integer.parseInt(data[1])]=1;
                adj[Integer.parseInt(data[1])][Integer.parseInt(data[0])]=1;
            }
            
            int start=1;
            Queue<Integer> que=new LinkedList<>();
            que.add(start);
            
            while(que.size()!=0)
            {
            	int nextStart=(int)(Integer)que.remove();
            	System.out.print(nextStart+"\t");
            	state[nextStart]=VISITED;

            	 for(int i=1;i<n+1;i++)
            	 {
            	 	if(adj[nextStart][i]==1 && state[i]==INIT)
            	 	{
            	 		que.add(i);
            	 		state[i]=WAIT;
            	 	}
            	 }
            }
        
        sn.close();
    }
}