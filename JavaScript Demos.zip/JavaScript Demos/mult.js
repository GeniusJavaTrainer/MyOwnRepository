function printMultiplicationTable(num) {
  document.write("<table border='2'>");
  let i = 1;
  while (i <= 10) {
    let result = num * i;

    document.write("<tr>");
    document.write("<td>" + result + "</td>");
    document.write("</tr>");
    i++;
  }
  document.write("</table>");
}
