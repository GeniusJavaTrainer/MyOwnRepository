document.write("<h1>Welcome! I'm from another file</h1>");
