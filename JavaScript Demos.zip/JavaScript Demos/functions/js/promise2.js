function myResolve(datum) {
  let data = "<table border='2'>";
  let employees = JSON.parse(datum);
  // console.log(employees);
  employees = employees.employees;
  // console.log(employees[0].empid);

  for (i = 0; i < employees.length; i++) {
    data +=
      "<tr>" +
      "<td>" +
      employees[i].empid +
      "</td>" +
      "<td>" +
      employees[i].name +
      "</td>" +
      "<td>" +
      employees[i].salary +
      "</td>" +
      "</tr>";
  }
  data += "</table>";
  console.log(employees);
  console.log(data);
  document.getElementById("demo").innerHTML = data;
}

function myReject(message) {
  document.getElementById("demo").innerHTML = message;
}

function testPromise() {
  let myPromise = new Promise(function (myResolve, myReject) {
    let req = new XMLHttpRequest();
    req.open("GET", "./records.json");
    req.onload = function () {
      if (req.status == 200) {
        myResolve(req.responseText);
      } else {
        myReject("<h1>Database not Available</h1>");
      }
    };
    req.send();
  });

  myPromise.then(
    function (response) {
      myResolve(response);
    },
    function (response) {
      myReject(response);
    }
  );
}
