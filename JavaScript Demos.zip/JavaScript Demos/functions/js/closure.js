calculate = () => {
    const PI = 3.14;
    let radius = document.getElementById("num").value;

    let area = calcArea();

    function calcArea(){
        return PI * radius ** 2;    
    }

    
    document.getElementById("area").value = area;

    function calcPeri(){
        return 2 * PI * radius;    
    }

    let perimeter = calcPeri();
    document.getElementById("perimeter").value = perimeter;
}