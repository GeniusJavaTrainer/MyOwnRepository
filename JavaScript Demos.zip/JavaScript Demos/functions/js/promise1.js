// function myResolve(datum) {
//   let data = "<table border='2'>";
//   let employees = JSON.parse(datum);
//   // console.log(employees);
//   employees = employees.employees;
//   // console.log(employees[0].empid);

//   for (i = 0; i < employees.length; i++) {
//     data +=
//       "<tr>" +
//       "<td>" +
//       employees[i].empid +
//       "</td>" +
//       "<td>" +
//       employees[i].name +
//       "</td>" +
//       "<td>" +
//       employees[i].salary +
//       "</td>" +
//       "</tr>";
//   }
//   data += "</table>";
//   console.log(employees);
//   console.log(data);
//   return data;
// }

// function myReject(message) {
//   console.log(message);
//   return message;
// }

async function testPromise() {
  let myPromise = new Promise(function (resolve) {
    let req = new XMLHttpRequest();
    req.open("GET", "./records.json", true);
    req.onload = function () {
      if (req.status == 200) {
        let data = "<table border='2'>";
        let employees = JSON.parse(req.responseText);
        // console.log(employees);
        employees = employees.employees;
        // console.log(employees[0].empid);

        for (i = 0; i < employees.length; i++) {
          data +=
            "<tr>" +
            "<td>" +
            employees[i].empid +
            "</td>" +
            "<td>" +
            employees[i].name +
            "</td>" +
            "<td>" +
            employees[i].salary +
            "</td>" +
            "</tr>";
        }
        data += "</table>";
        resolve(data);
      } else if (req.status == 404) {
        resolve("<h1>Database not Available</h1>");
      }
    };
    req.send();
  });

  // myPromise
  //   .then((response) => {
  //     console.log(response);
  //   })
  //   .catch((error) => {
  //     console.log(error);
  //   });
  document.getElementById("demo").innerHTML = await myPromise;
}
