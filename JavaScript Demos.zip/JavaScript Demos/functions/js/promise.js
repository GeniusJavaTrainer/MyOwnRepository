testPromise = () => {
  var promise = new Promise(function (resolve, reject) {
    const x = "geeksforgeeks";
    const y = "geeksfogeeks";
    if (x === y) {
      resolve();
    } else {
      reject();
    }
  });

  promise
    .then(function () {
      console.log("Success, You are a GEEK");
    })
    .catch(function () {
      console.log("Some error has occurred");
    });
};
