package com.me.service;

import com.me.entity.User;

public interface UserService {
	User save(User user);

	User findByEmail(String email);

	User findByEmailAndPassword(String email, String password);
}
