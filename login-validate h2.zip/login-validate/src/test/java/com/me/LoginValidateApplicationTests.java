package com.me;

import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.me.dao.UserDao;
import com.me.entity.User;
import com.me.service.UserService;
import com.me.service.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
public class LoginValidateApplicationTests {
	@Mock
	private UserDao userDao;

	@InjectMocks
	private UserService userService = new UserServiceImpl();

	@BeforeEach
	void setMockOutput() {
		this.userService = new UserServiceImpl(this.userDao);
	}

	@Test
	void testAdd() {
		User user = new User();
		user.setFirstName("Akshay");
		user.setLastName("Kumar");
		user.setEmail("akshay@sony.com");

		userService.save(user);

		verify(userDao).save(user);
	}

}
