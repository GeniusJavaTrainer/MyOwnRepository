package com.bhalchandra.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bhalchandra.dao.Customer;
import com.bhalchandra.entity.CustomerTO;

public class ClientDBOperations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice = 1;
		
		int custId = 0;
		String name = null;
		String address = null;
		
		CustomerTO customerTO = null;
		
		Customer customer = null;
		
		Scanner scCustomer = new Scanner(System.in);
		
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		customer = (Customer)appContext.getBean("customerDAO");
		
		Outer:
		while(choice != 0){
			System.out.println("Following is the choice:");
			System.out.println("1. Insert");
			System.out.println("2. Insert using procedure");
			System.out.println("3. Update");
			System.out.println("4. Delete");
			System.out.println("5. View");
			System.out.println("0. Exit");
			
			choice = Integer.parseInt(scCustomer.nextLine());
			
			switch(choice){
			case 1:
				System.out.print("Enter Customer ID: ");
				custId = Integer.parseInt(scCustomer.nextLine());
				
				System.out.print("Enter Customer Name: ");
				name = scCustomer.nextLine();
				
				System.out.print("Enter Customer Address: ");
				address = scCustomer.nextLine();
				
				customerTO = new CustomerTO(custId, name, address);
				customer.insertCustomer(customerTO);
				System.out.println("Record inserted");
				break;
			case 2:
				System.out.print("Enter Customer ID: ");
				custId = Integer.parseInt(scCustomer.nextLine());
				
				System.out.print("Enter Customer Name: ");
				name = scCustomer.nextLine();
				
				System.out.print("Enter Customer Address: ");
				address = scCustomer.nextLine();
				
				customerTO = new CustomerTO(custId, name, address);
				customer.insertUsingProcedure(customerTO);
				System.out.println("Record inserted using procedure");
				break;
			case 3:
				System.out.print("Enter Customer ID: ");
				custId = Integer.parseInt(scCustomer.nextLine());
				
				System.out.print("Enter Customer Name: ");
				name = scCustomer.nextLine();
				
				System.out.print("Enter Customer Address: ");
				address = scCustomer.nextLine();
				
				customerTO = new CustomerTO(custId, name, address);
				customer.updateCustomer(customerTO);
				System.out.println("Record updated");
				break;
			case 4:
				System.out.print("Enter Customer ID of the record to be deleted: ");
				custId = Integer.parseInt(scCustomer.nextLine());
				
				customerTO = new CustomerTO(custId, name, address);
				customer.deleteCustomer(customerTO);
				System.out.println("Record deleted");
				break;
			case 5:
				System.out.print("Enter Customer ID of the record to be viewed: ");
				custId = Integer.parseInt(scCustomer.nextLine());
				
				customerTO = new CustomerTO(custId, name, address);
				customerTO = customer.selectCustomer(customerTO);
				System.out.println(customerTO);
				break;
			case 0:
				break Outer;
				default:
					break;
			}
		}
	}
}