CREATE TABLE customer100
(
  customerId INT PRIMARY KEY,
  customerName VARCHAR2(20) NOT NULL,
  address  VARCHAR2(20) NOT NULL
);

CREATE OR REPLACE PROCEDURE insertit(p_custId INT, p_name VARCHAR2, p_address VARCHAR2)
IS
  BEGIN
       INSERT INTO customer100 VALUES(p_custId,p_name,p_address);
END insertit;