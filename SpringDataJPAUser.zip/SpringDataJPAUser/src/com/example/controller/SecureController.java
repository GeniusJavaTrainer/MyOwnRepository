package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.service.MyUserDetailsService;

@RestController
@RequestMapping("/secure")
public class SecureController {

	@Autowired
	private MyUserDetailsService userService;

	@RequestMapping("/user/users")
	public String loginSuccess() {
		return "Login Successful!";
	}

	@RequestMapping(value = "/user/email/{username}", method = RequestMethod.GET)
	public UserDetails findByEmail(@PathVariable(name="username") String email) {
		UserDetails user = userService.loadUserByUsername(email);
		System.out.println(user);
		return user;
	}
}
