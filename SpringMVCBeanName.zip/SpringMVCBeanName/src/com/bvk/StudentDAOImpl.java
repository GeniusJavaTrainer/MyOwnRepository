package com.bvk;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import com.bvk.entity.StudentTO;
import com.bvk.exception.DatabaseException;

@SuppressWarnings("deprecation")
public class StudentDAOImpl implements StudentDAO {

private SimpleJdbcTemplate  simpleJdbcTemplate;
	
	public void setDataSource(DataSource dataSource){
		this.simpleJdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}
	
	@Override
	public void insertStudent(StudentTO studentTO) throws DatabaseException{
		// TODO Auto-generated method stub
		String query = "INSERT INTO stud VALUES(?,?,?,?,?,?)";
		
		Integer rollNo = studentTO.getRollNo();
		String name = studentTO.getName();
		Integer m1 = studentTO.getM1();
		Integer m2 = studentTO.getM2();
		Integer total = studentTO.getTotal();
		Float percent = studentTO.getPercent();
		
		simpleJdbcTemplate.update(query,rollNo,name,m1,m2,total,percent);
	}
}