package com.bvk;

import com.bvk.entity.StudentTO;
import com.bvk.exception.DatabaseException;

public interface StudentDAO {
	public void insertStudent(StudentTO studentTO) throws DatabaseException;
}