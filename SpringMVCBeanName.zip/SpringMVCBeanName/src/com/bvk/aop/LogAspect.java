package com.bvk.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;

import com.bvk.exception.DatabaseException;

@Aspect
public class LogAspect {
	@AfterThrowing(pointcut="execution(* com.bvk.StudentDAOImpl.insertStudent(..))", throwing="error")
	public void afterThrowing(JoinPoint joinPoint, Throwable error) throws Exception{
		System.out.println("Exception is thrown on method: " + error);
		throw new DatabaseException("Record couldn't be inserted...");
	}
}