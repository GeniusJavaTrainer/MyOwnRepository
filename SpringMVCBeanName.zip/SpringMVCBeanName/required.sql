create table stud
(
  rollno INT PRIMARY KEY,
  name VARCHAR2(30) NOT NULL,
  m1 INT NOT NULL,
  m2 INT NOT NULL,
  total INT NOT NULL,
  percent FLOAT NOT NULL
)