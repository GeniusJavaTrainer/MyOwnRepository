package code;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class Body extends SimpleTagSupport {
	public void doTag() throws JspException, IOException {
		StringWriter sw = new StringWriter();
		getJspBody().invoke(sw);
		
		String str = sw.toString();
		
		JspWriter out = getJspContext().getOut();
		
		out.println(str.toUpperCase());
	}
}