package com.accenture.adfx.module5.datacon;

import javax.sql.DataSource;
/**
 * Data source connect interface.
 *
 */
public interface DataConnection {
	public DataSource dbcon();

}
