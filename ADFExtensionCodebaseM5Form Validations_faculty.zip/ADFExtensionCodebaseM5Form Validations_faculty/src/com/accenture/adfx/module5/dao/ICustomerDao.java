package com.accenture.adfx.module5.dao;

import java.sql.SQLException;

import com.accenture.adfx.module5.entity.Customer;

public interface ICustomerDao {
	
	public int insertRecord(Customer customer) throws SQLException, ClassNotFoundException;

}
