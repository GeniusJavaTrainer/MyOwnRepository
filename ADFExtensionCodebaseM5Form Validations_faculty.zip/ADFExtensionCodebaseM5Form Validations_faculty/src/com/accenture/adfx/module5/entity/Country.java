package com.accenture.adfx.module5.entity;
/**
 * Country object containing the Country details. 
 *
 */
public class Country {

	private int countryId;

	private String countryName;

	public int getCountryId() {
		return countryId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
}
