package com.ct.dao;

public interface IEmployeeQueries {
	String INSERT_QUERY = "INSERT INTO emp1 VALUES(?,?,?)";
	String UPDATE_QUERY = "UPDATE emp1 SET name=?,salary=? WHERE empid=?";
	String VIEW_QUERY = "SELECT empid, name, salary FROM emp1";
}