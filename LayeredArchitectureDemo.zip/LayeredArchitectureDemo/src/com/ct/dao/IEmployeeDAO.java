package com.ct.dao;

import java.util.List;

import com.ct.entity.Employee;
import com.ct.exception.EmployeeException;

public interface IEmployeeDAO {
	int insertRecord(Employee employee) throws EmployeeException;
	int updateRecord(Employee employee)throws EmployeeException;
	List<Employee>getRecords()throws EmployeeException;
}
