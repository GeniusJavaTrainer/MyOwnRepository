package com.ct.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.ct.entity.Employee;
import com.ct.exception.EmployeeException;
import com.ct.helper.DBUtil;

public class EmployeeDAOImpl implements IEmployeeDAO {
	private static Logger LOG = Logger.getLogger("com.ct.dao.EmployeeDAOImpl");
	@Override
	public int insertRecord(Employee employee) throws EmployeeException {
		int status = 0;
		
		try(Connection connEmployee = DBUtil.createConnection();
			PreparedStatement pstEmployee = connEmployee.prepareStatement(IEmployeeQueries.INSERT_QUERY)){
			
			pstEmployee.setInt(1, employee.getEmpid());
			pstEmployee.setString(2, employee.getName());
			pstEmployee.setFloat(3, employee.getSalary());
			
			status = pstEmployee.executeUpdate();
			LOG.info("Record inserted with Employee ID: " + employee.getEmpid());
		}catch(ClassNotFoundException | SQLException e){
			LOG.error(e.getMessage());
			EmployeeException emplException = new EmployeeException(e.getMessage());
			throw emplException;
		}
		return status;
	}

	@Override
	public int updateRecord(Employee employee) throws EmployeeException {
		int status = 0;
		
		try(Connection connEmployee = DBUtil.createConnection();
			PreparedStatement pstEmployee = connEmployee.prepareStatement(IEmployeeQueries.UPDATE_QUERY)){
			
			pstEmployee.setInt(3, employee.getEmpid());
			pstEmployee.setString(1, employee.getName());
			pstEmployee.setFloat(2, employee.getSalary());
			
			status = pstEmployee.executeUpdate();
			LOG.info("Record updated with Employee ID: " + employee.getEmpid());
		}catch(ClassNotFoundException | SQLException e){
			LOG.error(e.getMessage());
			EmployeeException emplException = new EmployeeException(e.getMessage());
			throw emplException;
		}
		return status;
	}

	@Override
	public List<Employee> getRecords() throws EmployeeException {
		List<Employee>employees = new ArrayList<>();
		Employee employee = null;
		
		ResultSet rsEmployees = null;
		
		try(Connection connEmployee = DBUtil.createConnection();
			PreparedStatement pstEmployee = connEmployee.prepareStatement(IEmployeeQueries.VIEW_QUERY)){
			
			rsEmployees = pstEmployee.executeQuery();
			
			while(rsEmployees.next()){
				employee = new Employee();
				
				employee.setEmpid(rsEmployees.getInt("empid"));
				employee.setName(rsEmployees.getString("name"));
				employee.setSalary(rsEmployees.getFloat("salary"));
				
				employees.add(employee);
			}
			
		}catch(ClassNotFoundException | SQLException e){
			EmployeeException emplException = new EmployeeException(e.getMessage());
			throw emplException;
		}
		return employees;
	}

}
