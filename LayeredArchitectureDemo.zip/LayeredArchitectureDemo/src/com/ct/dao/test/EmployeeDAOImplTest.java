package com.ct.dao.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ct.dao.EmployeeDAOImpl;
import com.ct.entity.Employee;
import com.ct.exception.EmployeeException;

public class EmployeeDAOImplTest {
	private EmployeeDAOImpl employeeDAOImpl;
	
	@Before
	public void setUp() throws Exception {
		employeeDAOImpl = new EmployeeDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		employeeDAOImpl = null;
	}

	@Test
	public final void testInsertRecord() throws EmployeeException {
		Employee employee = new Employee();
		
		employee.setEmpid(11);
		employee.setName("akhilesh");
		employee.setSalary(250000);
		
		assertEquals(1, employeeDAOImpl.insertRecord(employee));
	}

	@Test
	public final void testUpdateRecord() throws EmployeeException {
		Employee employee = new Employee();
		
		employee.setEmpid(11);
		employee.setName("Mohan");
		employee.setSalary(250000);
		
		assertEquals(1, employeeDAOImpl.updateRecord(employee));
	}

	@Test
	public final void testGetRecords() throws EmployeeException{
		List<Employee>employees = employeeDAOImpl.getRecords();
		
		assertTrue(employees.size()>0);
	}

}
