package com.ct.controller;

import java.util.List;

import com.ct.entity.Employee;
import com.ct.service.EmployeeServiceImpl;
import com.ct.service.IEmployeeService;

public class ControllerEmployee {
	private IEmployeeService employeeService;
	
	public ControllerEmployee(){
		employeeService = new EmployeeServiceImpl();
	}
	
	public String insert(Employee employee){
		int status = employeeService.insertEmployee(employee);
		String message = null;
		
		if(status > 0){
			message = new String("Record inserted successfully...");
		}else{
			message = new String("Record couldn't be inserted.");
		}
		return message;
	}
	
	public String update(Employee employee){
		int status = employeeService.updateEmployee(employee);
		String message = null;
		
		if(status > 0){
			message = new String("Record updated successfully...");
		}else{
			message = new String("Record couldn't be updated.");
		}
		return message;
	}
	
	public List<Employee>getRecords(){
		return employeeService.getEmployees();
	}
}