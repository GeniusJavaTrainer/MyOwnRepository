package com.ct.service;

import java.util.List;

import com.ct.dao.EmployeeDAOImpl;
import com.ct.dao.IEmployeeDAO;
import com.ct.entity.Employee;
import com.ct.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
	private IEmployeeDAO employeeDAO;
	
	
	public EmployeeServiceImpl() {
		employeeDAO = new EmployeeDAOImpl();
	}

	@Override
	public int insertEmployee(Employee employee) {
		int status = 0;
		try{
			status = employeeDAO.insertRecord(employee);
		}catch(EmployeeException empException){
			System.out.println(empException.getMessage());
		}
		return status;
	}

	@Override
	public int updateEmployee(Employee employee) {
		int status = 0;
		try{
			status = employeeDAO.updateRecord(employee);
		}catch(EmployeeException empException){
			System.out.println(empException.getMessage());
		}
		return status;
	}

	@Override
	public List<Employee> getEmployees() {
		List<Employee>employees = null;
		try{
			employees = employeeDAO.getRecords();
		}catch(EmployeeException empException){
			System.out.println(empException.getMessage());
		}
		return employees;
	}
}