package com.ct.service;

import java.util.List;

import com.ct.entity.Employee;

public interface IEmployeeService {
	int insertEmployee(Employee employee);
	int updateEmployee(Employee employee);
	List<Employee>getEmployees();
}