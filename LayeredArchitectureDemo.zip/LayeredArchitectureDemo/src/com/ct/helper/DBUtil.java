package com.ct.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBUtil {
	private static Connection connEmployee;
	
	public static Connection createConnection()
	throws ClassNotFoundException, SQLException{
		
		ResourceBundle oracleBundle = ResourceBundle.getBundle("oracle");
		
		String url = oracleBundle.getString("url");
		String username = oracleBundle.getString("username");
		String password = oracleBundle.getString("password");
		String driver = oracleBundle.getString("driver");
		
		Class.forName(driver);
		
		connEmployee = DriverManager.getConnection(url, username, password);
		return connEmployee;
	}
	
	public static void closeConnection() throws SQLException{
		connEmployee.close();
	}
}