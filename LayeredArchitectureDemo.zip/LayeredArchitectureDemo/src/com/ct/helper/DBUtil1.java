package com.ct.helper;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil1 {
	private static Connection connEmployee;
	
	public static Connection createConnection()
	throws ClassNotFoundException, SQLException{
		
		FileInputStream fis = null;
		Properties props = new Properties();
		
		try{
			fis = new FileInputStream("D:/wsJava8/LayeredArchitectureDemo/oracle.properties");
			props.load(fis);
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}
		
		String url = props.getProperty("url");
		String username = props.getProperty("username");
		String password = props.getProperty("password");
		String driver = props.getProperty("driver");
		
		Class.forName(driver);
		
		connEmployee = DriverManager.getConnection(url, username, password);
		return connEmployee;
	}
	
	public static void closeConnection() throws SQLException{
		connEmployee.close();
	}
}