package com.ct.exception;

public class EmployeeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2053358331293922799L;
	
	public EmployeeException(){
		
	}

	public EmployeeException(String message){
		super(message);
	}
}