package com.ct.pi;

import java.util.List;
import java.util.Scanner;

import com.ct.controller.ControllerEmployee;
import com.ct.entity.Employee;

public class ClientEmployee {

	public static void main(String[] args) {
		// Entry point of the Application.
		
		int choice = 0 ;
		
		Scanner scInput = new Scanner(System.in);
		
		Employee employee = null;
		ControllerEmployee controllerEmployee = new ControllerEmployee();
		
		String message = null;
		
		int empid = 0;
		String name = null;
		float salary = 0.0f;
		
		Out:
		while(true){
			System.out.println("Following is the choice:");
			System.out.println("1. Insert Record");
			System.out.println("2. Update Record");
			System.out.println("3. View Record");
			System.out.println("0. Exit");
			
			choice = Integer.parseInt(scInput.nextLine());
			
			switch(choice){
			case 1:
				System.out.print("Employee ID: ");
				empid = Integer.parseInt(scInput.nextLine());
				
				System.out.print("Name: ");
				name = scInput.nextLine();
				
				System.out.print("Salary: ");
				salary = Float.parseFloat(scInput.nextLine());
				
				employee = new Employee(name, salary);
				employee.setEmpid(empid);
				
				message = controllerEmployee.insert(employee);
				System.out.println(message);
				break;
			case 2:
				System.out.print("Employee ID: ");
				empid = Integer.parseInt(scInput.nextLine());
				
				System.out.print("Name: ");
				name = scInput.nextLine();
				
				System.out.print("Salary: ");
				salary = Float.parseFloat(scInput.nextLine());
				
				employee = new Employee(name, salary);
				employee.setEmpid(empid);
				
				message = controllerEmployee.update(employee);
				System.out.println(message);
				break;
			case 3:
				List<Employee>employees = controllerEmployee.getRecords();
				if(employees.size() == 0){
					System.out.println("No records.");
				}else{
					for (Employee empl : employees) {
						System.out.println(empl);
					}
				}
				break;
			default:
				System.out.println("Bye.");
				break Out;
			}
		}
		scInput.close();
	}
}