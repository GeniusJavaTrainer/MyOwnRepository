package com.shashank;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class LogAfterReturning {
	@AfterReturning(pointcut="execution(* com.shashank.Product.multiply(..))", returning="result")
  //@AfterReturning(pointcut="execution(* com.shashank.Product.multiply(..))", returning="result")
	public void afterReturning(JoinPoint joinPoint, Object result){
		System.out.println("After Normal Return from Method: " + result);
	}
}