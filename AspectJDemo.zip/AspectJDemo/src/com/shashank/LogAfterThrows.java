package com.shashank;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class LogAfterThrows {
	@AfterThrowing(pointcut="execution(* com.shashank.Product.multiply(..))", throwing="error")
//  @AfterThrowing(pointcut="execution(* com.shashank.Product.multiply(..))", throwing="error")
	public void afterThrowing(JoinPoint joinPoint, Throwable error){
		System.out.println("Exception is thrown on method: " + error);
	}
}