package com.cg.hims.exceptions;

public class PolicyNotFoundException extends Exception {

}
