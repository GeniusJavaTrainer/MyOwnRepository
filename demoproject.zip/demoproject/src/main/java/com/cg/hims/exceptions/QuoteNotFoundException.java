package com.cg.hims.exceptions;

public class QuoteNotFoundException extends Exception {

}
