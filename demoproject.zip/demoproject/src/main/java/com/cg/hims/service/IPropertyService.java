package com.cg.hims.service;

import com.cg.hims.entities.Property;

public interface IPropertyService {

	public Property addProperty(Property property);

	public Property viewProperty();

}
