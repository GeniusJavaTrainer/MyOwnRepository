package com.cg.hims.exceptions;

public class PolicyHolderNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2146304678694891525L;

	public PolicyHolderNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PolicyHolderNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PolicyHolderNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
