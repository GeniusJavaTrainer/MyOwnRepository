package com.cg.hims.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hims.entities.Quote;
import com.cg.hims.exceptions.QuoteNotFoundException;
import com.cg.hims.repository.QuoteRepositoryImpl;

@Service
public class QuoteServiceImpl implements IQuoteService {

	@Autowired
	private QuoteRepositoryImpl quoteRepository;
	
	
	@Override
	public Quote addQuote(Quote quote) {
		return quoteRepository.save(quote);
	}

	@Override
	public Quote updateQuote(Quote quote) throws QuoteNotFoundException {
		return quoteRepository.save(quote);
	}

	@Override
	public Quote findQuoteById(int id) throws QuoteNotFoundException {
		Optional<Quote>quote = quoteRepository.findById(id);
		Quote quot = null;
		
		if(quote.isPresent()) {
			quot = quote.get();
		}
		return quot; 
	}

	@Override
	public Quote removeQuote(int id) throws QuoteNotFoundException {
		Optional<Quote>quote = quoteRepository.findById(id);
		Quote quot = null;
		
		if(quote.isPresent()) {
			quot = quote.get();
		}
		
		quoteRepository.delete(quot);
		
		return quot;
	}

	@Override
	public List<Quote> showAllQuotes() {
		return quoteRepository.findAll();
	}
}