package com.cg.hims.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Agent extends AbstractUser implements Serializable{
	
	/**
	 * 
	 */

	private static final long serialVersionUID = -3277256898560568108L;
	
	public Agent() {
		super();
	}
	@Id	
	private int agentId;
	private String agentName;
	private String designation;
	private String salary; 
	private String address;
	private String email;
	private String mobileNo;
	
	
//	private List<PolicyHolder> policyHoldersList;
	
	
	public Agent(int agentId, String agentName, String designation, String salary, String address, String email,
			String mobileNo) {
		super();
		this.agentId = agentId;
		this.agentName = agentName;
		this.designation = designation;
		this.salary = salary;
		this.address = address;
		this.email = email;
		this.mobileNo = mobileNo;
//		this.policyHoldersList = policyHoldersList;
	}
	public int getAgentId() {
		return agentId;
	}
	public void setAgentId(int agentId) {
		this.agentId = agentId;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	/*public List<PolicyHolder> getPolicyHoldersList() {
		return policyHoldersList;
	}
	public void setPolicyHoldersList(List<PolicyHolder> policyHoldersList) {
		this.policyHoldersList = policyHoldersList;
	}*/
}
