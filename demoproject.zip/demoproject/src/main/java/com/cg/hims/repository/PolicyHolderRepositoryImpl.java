package com.cg.hims.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.hims.entities.PolicyHolder;
import com.cg.hims.exceptions.PolicyHolderNotFoundException;


public class PolicyHolderRepositoryImpl implements IPolicyHolderRepository {
	private EntityManager manager;
	public PolicyHolderRepositoryImpl() {
		EntityManagerFactory f = Persistence.createEntityManagerFactory("JPA-PU");
		manager=f.createEntityManager();
		
	}

	@Override
	public PolicyHolder addPolicyHolder(PolicyHolder policyHolder) {
		manager.getTransaction().begin();
		manager.persist(policyHolder);
		manager.getTransaction().commit();
		return policyHolder;
	}

	@Override
	public PolicyHolder updatePolicyHolder(PolicyHolder policyHolder) throws PolicyHolderNotFoundException {
		manager.getTransaction().begin();
		manager.merge(policyHolder);
		manager.getTransaction().commit();
		return policyHolder;
	}

	@Override
	public PolicyHolder findPolicyHolderById(int id) throws PolicyHolderNotFoundException {
		return manager.find(PolicyHolder.class, id);
	}

	@Override
	public PolicyHolder removePolicyHolder(int id) throws PolicyHolderNotFoundException {
		PolicyHolder policyHolder = null;
		manager.getTransaction().begin();
		policyHolder = manager.find(PolicyHolder.class,id);
		
		if(policyHolder == null) {
			throw new PolicyHolderNotFoundException("No such Policy Holder");
		}
		
		manager.remove(policyHolder);
		manager.getTransaction().commit();
		return policyHolder;
	}

	@Override
	public List<PolicyHolder> showAllPolicyHolders() {
		String qStr = "SELECT policyHolder FROM PolicyHolder policyHolder";
		TypedQuery<PolicyHolder> query = manager.createQuery(qStr, PolicyHolder.class);
		return query.getResultList();
	}
}