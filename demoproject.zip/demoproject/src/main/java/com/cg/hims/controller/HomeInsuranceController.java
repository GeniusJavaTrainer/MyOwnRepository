package com.cg.hims.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hims.entities.Quote;
import com.cg.hims.exceptions.QuoteNotFoundException;
import com.cg.hims.service.IQuoteService;

@RestController
@RequestMapping("/insurance")
public class HomeInsuranceController {
	
	@Autowired
	private IQuoteService quoteService;
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PutMapping("/quote/update")
	public ResponseEntity<Quote> updateProduct(
			@RequestBody Quote quote){
		Quote quot = null;
		try {
		quot = quoteService.updateQuote(quote);
		if(quot == null)
		{
			throw new QuoteNotFoundException();
		}
		}catch(QuoteNotFoundException qnfe) {
			return new ResponseEntity("Sorry! couldn't update!", 
					HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Quote>(quot, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping("/quote/add")
	public ResponseEntity<Quote> insertQuote(
			@RequestBody Quote quote){
		Quote quot = quoteService.addQuote(quote);
		
		if(quot == null)
		{
			return new ResponseEntity("Sorry! couldn't update!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Quote>(quot, HttpStatus.OK);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@DeleteMapping("/quote/delete/{quoteId}")
	public ResponseEntity<Quote> deleteQuote(
			@PathVariable("quoteId")Integer quoteId){
		Quote quot = null;
		try {
		quot = quoteService.removeQuote(quoteId);
		if(quot == null)
		{
			throw new QuoteNotFoundException();
		}
		}catch(QuoteNotFoundException qnfe) {
			return new ResponseEntity("Sorry! couldn't update!", 
					HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Quote>(quot, HttpStatus.OK);
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/quote/{quoteId}")
	public ResponseEntity<Quote> findProduct(
			@PathVariable("quoteId")Integer quoteId){
		Quote quot = null;
		try {
		quot = quoteService.findQuoteById(quoteId);
		if(quot == null)
		{
			throw new QuoteNotFoundException();
		}
		}catch(QuoteNotFoundException qnfe) {
			return new ResponseEntity("Sorry! couldn't update!", 
					HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Quote>(quot, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/quotes")
	public ResponseEntity<List<Quote>> getAllQuotes(){
		List<Quote> quotes= quoteService.showAllQuotes();
		if(quotes.isEmpty()) {
			return new ResponseEntity("Sorry! Products not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Quote>>(quotes, HttpStatus.OK);
	}
}