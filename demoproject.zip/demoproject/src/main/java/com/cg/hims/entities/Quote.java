package com.cg.hims.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

 

@Entity

public class Quote implements Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = -6169982377524818344L;
    @Id
    private int quoteId;
    @Column
    private String premiumType;
    @Column
    private double premium;
    @Column
    private double dwellingCoverage;
    @Column
    private double detachedStructureCoverage;
    @Column
    private double personalPropertyCoverage;
    @Column
    private double additionalLivingExpense;
    @Column
    private double medicalExpense;
    @Column
    private double deductibleAmount;

    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="propertyId")
    private Property property;
    
    public Quote() {
        super();
    }
    public Quote(int quoteId, String premiumType, double premium, double dwellingCoverage,
            double detachedStructureCoverage, double personalPropertyCoverage, double additionalLivingExpense,
            double medicalExpense, double deductibleAmount, Property property) {
        super();
        this.quoteId = quoteId;
        this.premiumType = premiumType;
        this.premium = premium;
        this.dwellingCoverage = dwellingCoverage;
        this.detachedStructureCoverage = detachedStructureCoverage;
        this.personalPropertyCoverage = personalPropertyCoverage;
        this.additionalLivingExpense = additionalLivingExpense;
        this.medicalExpense = medicalExpense;
        this.deductibleAmount = deductibleAmount;
        this.property = property;
    }
    public int getQuoteId() {
        return quoteId;
    }
    public void setQuoteId(int quoteId) {
        this.quoteId = quoteId;
    }
    public String getPremiumType() {
        return premiumType;
    }
    public void setPremiumType(String premiumType) {
        this.premiumType = premiumType;
    }
    public double getPremium() {
        return premium;
    }
    public void setPremium(double premium) {
        this.premium = premium;
    }
    public double getDwellingCoverage() {
        return dwellingCoverage;
    }
    public void setDwellingCoverage(double dwellingCoverage) {
        this.dwellingCoverage = dwellingCoverage;
    }
    public double getDetachedStructureCoverage() {
        return detachedStructureCoverage;
    }
    public void setDetachedStructureCoverage(double detachedStructureCoverage) {
        this.detachedStructureCoverage = detachedStructureCoverage;
    }
    public double getPersonalPropertyCoverage() {
        return personalPropertyCoverage;
    }
    public void setPersonalPropertyCoverage(double personalPropertyCoverage) {
        this.personalPropertyCoverage = personalPropertyCoverage;
    }
    public double getAdditionalLivingExpense() {
        return additionalLivingExpense;
    }
    public void setAdditionalLivingExpense(double additionalLivingExpense) {
        this.additionalLivingExpense = additionalLivingExpense;
    }
    public double getMedicalExpense() {
        return medicalExpense;
    }
    public void setMedicalExpense(double medicalExpense) {
        this.medicalExpense = medicalExpense;
    }
    public double getDeductibleAmount() {
        return deductibleAmount;
    }
    public void setDeductibleAmount(double deductibleAmount) {
        this.deductibleAmount = deductibleAmount;
    }
    public Property getProperty() {
        return property;
    }
    public void setProperty(Property property) {
        this.property = property;
    }
    @Override
    public String toString() {
        return "Quote [quoteId=" + quoteId + ", premiumType=" + premiumType + ", premium=" + premium
                + ", dwellingCoverage=" + dwellingCoverage + ", detachedStructureCoverage=" + detachedStructureCoverage
                + ", personalPropertyCoverage=" + personalPropertyCoverage + ", additionalLivingExpense="
                + additionalLivingExpense + ", medicalExpense=" + medicalExpense + ", deductibleAmount="
                + deductibleAmount + ", property=" + property + "]";
    }
}