package com.cg.hims.exceptions;

public class AgentNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4693040793384821969L;

	public AgentNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AgentNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public AgentNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public AgentNotFoundException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
