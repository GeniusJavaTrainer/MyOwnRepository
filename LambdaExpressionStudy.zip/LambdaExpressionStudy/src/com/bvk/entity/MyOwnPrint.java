package com.bvk.entity;

@FunctionalInterface
public interface MyOwnPrint {
	public void printIt(String str);
}