package com.bvk.entity;

public interface MyFunc {
	MyClass func(int n);
}