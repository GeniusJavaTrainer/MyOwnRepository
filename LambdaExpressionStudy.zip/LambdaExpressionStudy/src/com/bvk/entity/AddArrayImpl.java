package com.bvk.entity;

import com.bvk.exception.EmptyArrayException;

public class AddArrayImpl implements AddArray {

	@Override
	public double sumArray(double[] n) throws EmptyArrayException {
		double answer = 0.0;
		
		if(n.length == 0){
			throw new EmptyArrayException("No data provided.");
		}
		//          30       10, 20, 30
		for (double number : n) {
			answer += number;// answer = answer + number
		}
		return answer;
	}

}
