package com.bvk.entity;
@FunctionalInterface
public interface CheckPrime {
	boolean isPrime(int number);
}