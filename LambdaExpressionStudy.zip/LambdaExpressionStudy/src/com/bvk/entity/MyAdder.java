package com.bvk.entity;

public interface MyAdder {
	public Integer addIt(Integer a, Integer b);
}