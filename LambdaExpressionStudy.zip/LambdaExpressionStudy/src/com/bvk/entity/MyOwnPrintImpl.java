package com.bvk.entity;

public class MyOwnPrintImpl implements MyOwnPrint {

	@Override
	public void printIt(String str) {
		System.out.println(str);
	}
}