package com.bvk.entity;

public class IntegerReverse implements GenericReverse<Integer> {
// If it is 123 as input parameter, answer is 321.
	
	@Override
	public Integer reverse(Integer t) {
		int num = 0;
		int count = 0;
		int n = t;
		
		while(n != 0){
			n /= 10;
			count++;
		}
		count--;
		while(t != 0){
			num += t%10*Math.pow(10, count);
			count--;
			t /= 10;
		}
		return num;
	}

}
