package com.bvk.entity;

@FunctionalInterface
public interface CheckEven {
	boolean isEven(int number);//SAM. Single Abstract Method
}