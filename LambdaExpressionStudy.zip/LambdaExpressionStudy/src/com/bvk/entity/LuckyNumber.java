package com.bvk.entity;

public interface LuckyNumber {
	double getLuckyNumber();
}