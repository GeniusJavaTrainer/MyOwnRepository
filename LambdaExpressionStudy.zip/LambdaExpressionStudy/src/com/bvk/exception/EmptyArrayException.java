package com.bvk.exception;

public class EmptyArrayException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6962711490267744311L;

	public EmptyArrayException(String message){
		super(message);
	}
}