package com.bvk.client;

import java.util.function.BiPredicate;

public class ClientPredicate {

	public static void main(String[] args) {
		BiPredicate<Integer, Integer>isEven = (a,b)-> a>b;
		
		System.out.println(isEven.test(2,10));
	}
}