package com.bvk.client;

import com.bvk.entity.GenericReverse;

public class ClientGenericReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenericReverse<String> reverseString = null;
		GenericReverse<Integer> reverseInt = null;
		
		/*StringReverse stringReverse = new StringReverse();
		IntegerReverse integerReverse = new IntegerReverse();
		
		reverseString = stringReverse;
		reverseInt = integerReverse;*/
		
		reverseString = (t)->{
			StringBuffer sbf = new StringBuffer(t);
			sbf.reverse();
			t = new String(sbf);
			
			return t;
		};
		
		reverseInt = (t)->{
			int num = 0;
			int count = 0;
			int n = t;
			
			while(n != 0){
				n /= 10;
				count++;
			}
			count--;
			while(t != 0){
				num += t%10*Math.pow(10, count);
				count--;
				t /= 10;
			}
			return num;
		};
		
		String text = new String("This is test");
		int number = 123;
		
		System.out.println("Before reversal text: " + text);
		
		text = reverseString.reverse(text);
		
		System.out.println("After reversal text: " + text);
		
		System.out.println("Before reversal number: " + number);
		
		number = reverseInt.reverse(number);
		
		System.out.println("After reversal number: " + number);
	}
}