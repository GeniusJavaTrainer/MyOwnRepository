package com.bvk.client;

import java.util.function.Function;

public class ClientFunctionNew {

	public static void main(String[] args) {
	Function<Integer, Integer>calculateTwice = (n)->n*2;
	
	System.out.println(calculateTwice.apply(10));
	}
}