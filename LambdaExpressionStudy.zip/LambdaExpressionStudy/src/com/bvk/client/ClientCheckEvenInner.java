package com.bvk.client;

import java.util.Scanner;

import com.bvk.entity.CheckEven;

public class ClientCheckEvenInner {

	public static void main(String[] args) {
		CheckEven checkEven = new CheckEven(){
			@Override
			public boolean isEven(int number) {
				boolean isItEven;
				isItEven = number % 2 == 0;
				return isItEven;
			}
		};
		
		Scanner scInput = new Scanner(System.in);
		
		int number;
		
		boolean isEven;
		
		System.out.print("Enter a number: ");
		number = scInput.nextInt();
		
		//checkEven = checkEvenImpl;
		
		isEven = checkEven.isEven(number);
		
		if(isEven){
			System.out.println("Given number is even.");
		}else{
			System.out.println("Given number is odd.");
		}
		
		scInput.close();
	}
}