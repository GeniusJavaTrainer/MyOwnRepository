package com.bvk.client;

import com.bvk.entity.MyClass;
import com.bvk.entity.MyFunc;

public class ClientConstructorRef {

	public static void main(String[] args) {
		MyFunc myClassCons = MyClass::new;
		
		MyClass mc = myClassCons.func(100);
		
		System.out.println(mc.getValue());
	}
}