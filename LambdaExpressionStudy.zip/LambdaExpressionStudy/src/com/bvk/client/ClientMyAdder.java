package com.bvk.client;

import com.bvk.entity.MyAdder;

public class ClientMyAdder {

	public static void main(String[] args) {
		MyAdder myAdder = (Integer a, Integer b)-> (a+b);
		System.out.println(myAdder.addIt(10, 20));
	}
}