package com.bvk.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Function;

public class ClientFunction {
	public static void main(String[] args) {
		Function<Integer, List<Integer>>list = 
				(n)->{
					List<Integer>numbers = new ArrayList<>();
					Random random = new Random();
					for(int i = 1 ; i <= n ; i++){
						numbers.add(random.nextInt());
					}
					return numbers;
				};

		List<Integer>numbers = list.apply(10);
		
		for (Integer integer : numbers) {
			System.out.println(integer);
		}
	}
}