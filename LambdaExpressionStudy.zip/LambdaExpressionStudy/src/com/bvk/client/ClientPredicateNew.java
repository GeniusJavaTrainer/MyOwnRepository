package com.bvk.client;

import java.util.function.Predicate;

public class ClientPredicateNew {

	public static void main(String[] args) {
		Predicate<Integer>checkEven = (n)-> n%2 == 0;
		System.out.println(checkEven.test(20));
	}
}