package com.bvk.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bvk.entity.Student;

public class ClientStudent {

	public static void main(String[] args) {
		SessionFactory sf = new Configuration().configure().
				addAnnotatedClass(com.bvk.entity.Student.class).
				buildSessionFactory();
		
		Session session = sf.openSession();
		
		Transaction tx = null;
		
		try{
			Student student = new Student();
			
			//student.setRollno(1);
			student.setName("bvk");
			
			tx = session.beginTransaction();
			
			session.save(student);
			
			tx.commit();
		}catch(Exception e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}