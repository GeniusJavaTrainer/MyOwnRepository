package com.onlinetrainings.service;

import com.onlinetrainings.aop.Product;

public class ServiceLogger {
	public int handle(Product product,int a, int b){
		int result = 0;
		try{
			result = product.multiply(a, b);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
			return result;
	}
}