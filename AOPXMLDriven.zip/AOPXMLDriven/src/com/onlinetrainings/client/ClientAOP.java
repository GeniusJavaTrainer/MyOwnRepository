package com.onlinetrainings.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.onlinetrainings.aop.Product;
import com.onlinetrainings.service.ServiceLogger;

public class ClientAOP {

	public static void main(String[] args) {
		ApplicationContext appContext = new ClassPathXmlApplicationContext(
				"beans.xml");

		Product product = (Product) appContext.getBean("product");

		ServiceLogger serviceLogger = new ServiceLogger();
		
		int result = serviceLogger.handle(product,10, 10);

		System.out.println(result);

		result = serviceLogger.handle(product,0, 0);
		System.out.println(result);
	}
}