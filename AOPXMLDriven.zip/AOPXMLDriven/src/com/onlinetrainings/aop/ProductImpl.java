package com.onlinetrainings.aop;

public class ProductImpl implements Product {

	@Override
	public int multiply(int a, int b) {
		return a * b;
	}
}