package com.onlinetrainings.aop;

import org.aspectj.lang.JoinPoint;

public class LogAfterThrows {

	public void afterThrowing(JoinPoint joinPoint, Object error)
			throws Throwable {
		System.out.println("Exception is thrown on method: " + error);
	}
}