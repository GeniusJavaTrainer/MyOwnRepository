package com.onlinetrainings.aop;

import org.aspectj.lang.ProceedingJoinPoint;

public class LogAround {

	public Object invoke(ProceedingJoinPoint joinPoint) throws Throwable {

		Object arguments[] = joinPoint.getArgs();

		int number1 = ((Integer) arguments[0]).intValue();
		int number2 = ((Integer) arguments[1]).intValue();
		System.out.println("Inside Around");
		if (number1 == 0 && number2 == 0) {
			throw new Exception("Cannot multiply 0 with 0");
		}

		return joinPoint.proceed();
	}
}