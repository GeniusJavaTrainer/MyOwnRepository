package com.bvk.client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertDemo {

	public static void main(String[] args) {
		int status = 0;
		
		int empid = 1;
		String name = new String("xyz");
		float salary = 50000;
		
		Connection connEmp = null;
		String query = new String("INSERT INTO emp1 VALUES("+empid+",'"+name+"',"+salary+")");
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connEmp = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","bvk", "bvk");
			Statement pst = connEmp.createStatement();
			
			status = pst.executeUpdate(query);
			
			System.out.println(status);
		}catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}catch (SQLException e) {
			System.out.println(e.getMessage());
		}finally{
			try {
				connEmp.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}