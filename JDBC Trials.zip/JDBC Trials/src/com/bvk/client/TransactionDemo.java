package com.bvk.client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;

public class TransactionDemo {

	public static void main(String[] args) {
		try{
			//Loading JDBC Driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		
		try(
			//Establish connection.
			Connection connEmp = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","bvk", "bvk");
			//Creating SQL statement
			Statement st = connEmp.createStatement();
		   )
		{
			connEmp.setAutoCommit(false);
			
			String query = "INSERT INTO emp1 VALUES(10,'XYZ',150000)";
			String query1 = "INSERT INTO emp1 VALUES(11,'abc',250000)";
			
			Savepoint svA = connEmp.setSavepoint("A");
			st.executeUpdate(query);
			
			Savepoint svB = connEmp.setSavepoint("B");
			int result = st.executeUpdate(query1);
			
			connEmp.rollback(svB);
			connEmp.commit();
			System.out.println("Done finally!!");
		}catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
}