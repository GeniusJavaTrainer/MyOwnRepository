package com.bhalchandra.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.bhalchandra.entity.CustomerTO;

public class CustomerDAOImpl implements Customer {
	private JdbcDaoSupport jdbcDaoSupport = new SimpleJdbcDaoSupport();
	
	public void setDataSource(DataSource dataSource){
		this.jdbcDaoSupport.setDataSource(dataSource);
	}
	
	@Override
	public void insertCustomer(CustomerTO customer) {
		// TODO Auto-generated method stub
		String query = "INSERT INTO customer100 VALUES(?,?,?)";
		
		Integer custId = customer.getCustomerId();
		String name = customer.getName();
		String address = customer.getAddress();
		
		jdbcDaoSupport.getJdbcTemplate().update(query, custId,name,address);
	}

	@Override
	public void updateCustomer(CustomerTO customer) {
		// TODO Auto-generated method stub
		String query = "UPDATE customer100 SET customerId=?, name=?, address=?"
				+ "WHERE customerId=?";
		
		Integer custId = customer.getCustomerId();
		String name = customer.getName();
		String address = customer.getAddress();
		
		jdbcDaoSupport.getJdbcTemplate().update(query, custId,name,address,custId);
	}

	@Override
	public void deleteCustomer(CustomerTO customer) {
		// TODO Auto-generated method stub
		String query = "DELETE FROM customer100 WHERE customerId=?";
		
		Integer custId = customer.getCustomerId();
				
		jdbcDaoSupport.getJdbcTemplate().update(query, custId);
	}

	@Override
	public void insertUsingProcedure(CustomerTO customer) {
		// TODO Auto-generated method stub
		String query = "{CALL insertit(?,?,?)}";
		
		Integer custId = customer.getCustomerId();
		String name = customer.getName();
		String address = customer.getAddress();
		
		jdbcDaoSupport.getJdbcTemplate().update(query, custId,name,address);
	}

	@Override
	public CustomerTO selectCustomer(CustomerTO customer) {
		// TODO Auto-generated method stub
		CustomerTO customerFound = null;
		
		String query = "SELECT * FROM customer100 WHERE customerId = ?";
		
		Integer custId = customer.getCustomerId();
		
		customerFound = (CustomerTO)jdbcDaoSupport.getJdbcTemplate().queryForObject(query, new ParameterizedRowMapper(){
			@Override
			public Object mapRow(ResultSet resultSet, int rowNum) throws SQLException{
				int custId = resultSet.getInt("customerid");
				String name = resultSet.getString("customername");
				String address = resultSet.getString("address");
				
				CustomerTO customer = new CustomerTO(custId, name, address);
				return customer;
			}
		},
		custId
		);
		return customerFound;
	}
}