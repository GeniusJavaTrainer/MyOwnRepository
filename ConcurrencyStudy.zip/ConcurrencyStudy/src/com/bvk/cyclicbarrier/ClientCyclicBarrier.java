package com.bvk.cyclicbarrier;

import java.util.concurrent.CyclicBarrier;

import com.bvk.entity.MixedDoubleTennisGame;
import com.bvk.entity.Player;

public class ClientCyclicBarrier {

	public static void main(String[] args) {
		CyclicBarrier cyclicBarrier = new CyclicBarrier(4, new MixedDoubleTennisGame());
		
		Player player1 = new Player(cyclicBarrier);
		Player player2 = new Player(cyclicBarrier);
		Player player3 = new Player(cyclicBarrier);
		Player player4 = new Player(cyclicBarrier);
		//Player player5 = new Player(cyclicBarrier);
		
		
		//new Thread(player5, "Refree").start();
		new Thread(player4, "Stephy Graph").start();
		new Thread(player3, "John Mcnroe").start();
		new Thread(player1, "Martina Navratilova").start();
		new Thread(player2, "Ivan Lendal").start();
	}
}