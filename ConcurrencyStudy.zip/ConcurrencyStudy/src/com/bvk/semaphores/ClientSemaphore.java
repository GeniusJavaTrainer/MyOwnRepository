package com.bvk.semaphores;

import java.util.concurrent.Semaphore;

import com.bvk.entity.Person;

public class ClientSemaphore {

	public static void main(String[] args) {
		Semaphore machines = new Semaphore(2);
		
		Thread personOne = new Thread(new Person(machines,"helios"));
		Thread personTwo = new Thread(new Person(machines,"indigo"));
		Thread personThree = new Thread(new Person(machines,"juno"));
		/*Thread personFour = new Thread(new Person(machines,"kepler"));*/
		/*Thread personFive = new Thread(new Person(machines,"luna"));
		Thread personSix= new Thread(new Person(machines,"juno1"));
		Thread personSeven = new Thread(new Person(machines,"kepler1"));
		Thread personEight = new Thread(new Person(machines,"luna1"));*/
		
		personOne.start();
		personTwo.start();
		personThree.start();
		/*personFour.start();*/
		
	}
}