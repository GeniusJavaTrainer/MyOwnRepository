package com.bvk.atomic;

import java.util.concurrent.atomic.AtomicInteger;

public class AtomicTest {
	private static Integer integer = new Integer(0);
	private static AtomicInteger atomicInteger = new AtomicInteger(0);
	
	static class IntegerIncrementer extends Thread {
		public void run(){
			System.out.println("In " + Thread.currentThread().getName() + " Incremented value of integer is: " + ++integer);
		}
	}
	
	static class AtomicIncrementer extends Thread{
		public void run(){
			System.out.println("In " + Thread.currentThread().getName() + " Incremented value of atomic integer is: " + atomicInteger.incrementAndGet());
		}
	}
	
	public static void main(String[] args) {
		for(int i = 1 ; i < 5 ; i++){
			new IntegerIncrementer().start();
			new AtomicIncrementer().start();
		}
	}
}