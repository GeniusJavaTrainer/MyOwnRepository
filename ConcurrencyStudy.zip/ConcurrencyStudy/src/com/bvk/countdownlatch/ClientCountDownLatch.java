package com.bvk.countdownlatch;

import java.util.concurrent.CountDownLatch;

import com.bvk.entity.Runner;

public class ClientCountDownLatch {

	public static void main(String[] args) {
		CountDownLatch latch = new CountDownLatch(3);
		long count = 0 ;
		
		Thread t1 = new Thread(new Runner(latch, "Cheeta"));
		Thread t2 = new Thread(new Runner(latch, "Gazelle"));
		Thread t3 = new Thread(new Runner(latch, "Leopard"));
		
		t1.start();
		t2.start();
		t3.start();
		
		System.out.println("On your marks, Get Set...");
		
		count = latch.getCount();
		
		while(count >= 1){
			System.out.println(count);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			latch.countDown();
			count = latch.getCount();
		}
		System.out.println("Go!");
	}
}