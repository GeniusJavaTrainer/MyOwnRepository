package com.bvk.phaser;

import java.util.concurrent.Phaser;

import com.bvk.entity.MyWorker;

public class ClientPhaser {

	public static void main(String[] args) {
		Phaser deliveryOrder = new Phaser(1);
		
		System.out.println("Starting the process of delivery order...");
		
		new MyWorker(deliveryOrder, "Cook");
		new MyWorker(deliveryOrder, "Helper");
		new MyWorker(deliveryOrder, "Attendant");
		
		for(int i = 1 ; i <= 3 ; i++){
			deliveryOrder.arriveAndAwaitAdvance();
			System.out.println("Deliver food item no. " + i);
		}
		
		deliveryOrder.arriveAndDeregister();
		System.out.println("Delivery order completed... Give it to the Customer.");
	}
}