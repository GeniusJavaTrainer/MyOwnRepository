package com.bvk.exchanger;

import java.util.concurrent.Exchanger;

import com.bvk.entity.Person1;
import com.bvk.entity.Person2;

public class ClientExchanger {

	public static void main(String[] args) {
		Exchanger<String> talk = new Exchanger<>();
		
		Thread firstPerson = new Thread(new Person1(talk));
		Thread secondPerson = new Thread(new Person2(talk));
		Thread thirdPerson = new Thread(new Person1(talk));
		
		firstPerson.start();
		secondPerson.start();
		thirdPerson.start();
	}
}