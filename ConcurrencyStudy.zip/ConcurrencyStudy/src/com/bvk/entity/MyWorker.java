package com.bvk.entity;

import java.util.concurrent.Phaser;

public class MyWorker extends Thread {
	private Phaser deliveryOrder;
	
	public MyWorker(Phaser deliveryOrder, String name){
		this.deliveryOrder = deliveryOrder;
		this.setName(name);
		this.deliveryOrder.register();
		start();
	}
	
	public void run(){
		for(int i = 1 ; i <= 3 ; i++){
			System.out.println("\t" + getName() + " doing work for order no. " + i);
			if(i == 3){
				deliveryOrder.arriveAndDeregister();
			}else{
				deliveryOrder.arriveAndAwaitAdvance();
			}
			try{
				Thread.sleep(3000);
			}catch(InterruptedException ioe){
				System.out.println(ioe.getMessage());
			}
		}
	}
}