package com.bvk.entity;

public class MixedDoubleTennisGame implements Runnable {

	@Override
	public void run() {
		System.out.println("All players ready\nGame starts\nLove all...");
	}
}