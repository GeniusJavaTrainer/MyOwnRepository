package com.bvk.entity;

import java.util.concurrent.Semaphore;

public class Person implements Runnable {
	private Semaphore machines;
	private String name;
	
	public Person() {
		super();
	}

	public Person(Semaphore machines, String name) {
		super();
		this.machines = machines;
		this.name = name;
	}

	public Semaphore getMachines() {
		return machines;
	}

	public void setMachines(Semaphore machines) {
		this.machines = machines;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void run() {
		try{
			System.out.println(getName() + " waiting to access an ATM machine.");
			machines.acquire();
			Thread.sleep(10000);
			System.out.println(getName() + " going to leave ATM machine");
			machines.release();
		}catch(InterruptedException ioe){
			System.err.println(ioe.getMessage());
		}
	}
}