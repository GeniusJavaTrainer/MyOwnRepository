package com.bvk.entity;

import java.util.concurrent.CountDownLatch;

public class Runner implements Runnable {
	private CountDownLatch latch;
	private String name;
	
	
	public Runner(CountDownLatch latch, String name) {
		super();
		this.latch = latch;
		this.name = name;
		
		System.out.println(this.name + " ready and waiting for count down to start...");
	}

	@Override
	public void run() {
		try{
			latch.await();
		}catch(InterruptedException ioe){
			System.out.println("In " + this.name + " got interrupted...");
		}
		System.out.println(this.name + " started running...");
	}	
}