package com.bvk.entity;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class Player implements Runnable {
	private CyclicBarrier waitPoint;
	
	
	public Player(CyclicBarrier waitPoint) {
		super();
		this.waitPoint = waitPoint;
	}


	@Override
	public void run() {
		System.out.println("Player " + Thread.currentThread().getName() + " is ready.");
		
		try{
			waitPoint.await();
		}catch(BrokenBarrierException | InterruptedException e){
			System.out.println(e.getMessage());
		}
	}
}