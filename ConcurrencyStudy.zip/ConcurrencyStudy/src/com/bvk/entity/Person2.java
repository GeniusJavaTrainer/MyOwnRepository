package com.bvk.entity;

import java.util.concurrent.Exchanger;

public class Person2 implements Runnable {
	private Exchanger<String>talk;
	
	public Person2(Exchanger<String> talk) {
		super();
		this.talk = talk;
	}

	@Override
	public void run() {
		String reply = null;
		
		try{
			reply = talk.exchange("Hello");
			System.out.println("In " + Thread.currentThread().getName()+ " "
					+ "Reply: " + reply);
			
			reply = talk.exchange("How about you? ");
			System.out.println("In " + Thread.currentThread().getName()+ " "
					+ "Reply: " + reply);
			
			reply = talk.exchange("I'm ok");
			System.out.println("In " + Thread.currentThread().getName()+ " "
					+ "Reply: " + reply);
			
		}catch(InterruptedException ioe){
			System.out.println(ioe.getMessage());
		}
	}

}
