package com.bvk.entity;

import java.util.concurrent.Exchanger;

public class Person1 implements Runnable {
	private Exchanger<String>talk;
	
	public Person1(Exchanger<String> talk) {
		super();
		this.talk = talk;
	}

	@Override
	public void run() {
		String reply = null;
		
		try{
			reply = talk.exchange("Hi");
			System.out.println("In " + Thread.currentThread().getName()+ " "
					+ "Reply: " + reply);
			
			reply = talk.exchange("How are you? ");
			System.out.println("In " + Thread.currentThread().getName()+ " "
					+ "Reply: " + reply);
			
			reply = talk.exchange("I'm fine");
			System.out.println("In " + Thread.currentThread().getName()+ " "
					+ "Reply: " + reply);
			
		}catch(InterruptedException ioe){
			System.out.println(ioe.getMessage());
		}
	}
}