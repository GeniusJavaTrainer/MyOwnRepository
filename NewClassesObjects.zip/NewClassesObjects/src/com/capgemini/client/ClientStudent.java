package com.capgemini.client;

import com.capgemini.entity.Student;
public class ClientStudent {

	public static void main(String[] args) {
		//This will allocate memory for record of a student & its starting reference is 
		// given to student variable. It gives default values to its internal variables.
		//These internal variables are known as members. The variables that we are using are
		//known as instance variables.
		//An object is an instance of class.
		Student.printLastRollNo();
		
		Student student = new Student();
		Student studentTwo = new Student("xyz",99.99f);
		
		student.output();
		studentTwo.output();
		
		System.out.println(studentTwo.getPercent());

		studentTwo.setPercent(100);
		
		System.out.println(studentTwo.getPercent());
		
		Student.printLastRollNo();
	}
}