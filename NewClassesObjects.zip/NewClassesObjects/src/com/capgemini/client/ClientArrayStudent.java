package com.capgemini.client;

import java.util.Scanner;

import com.capgemini.entity.Student;

public class ClientArrayStudent {

	public static void main(String[] args) {

		Student students[] = new Student[3];
		Scanner scInput = new Scanner(System.in);
		
		String name = null;
		float percent = 0.0f;
		
		for(int i = 0 ; i < students.length ; i++) {
			System.out.print("Enter name: ");
			name = scInput.nextLine();
			
			System.out.print("Enter percent: ");
			percent = scInput.nextFloat();
					  scInput.nextLine();
					  
			students[i] = new Student(name, percent);
		}
		
		for (Student student : students) {
			student.output();
		}
		
		scInput.close();
	}
}