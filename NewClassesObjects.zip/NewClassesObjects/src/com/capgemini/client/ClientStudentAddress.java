package com.capgemini.client;

import java.util.Scanner;

import com.capgemini.entity.Address;
import com.capgemini.entity.Student;

public class ClientStudentAddress {

	public static void main(String[] args) {

		Scanner scInput = new Scanner(System.in);
		
		Student student = null;
		Address address = null;
		
		String name = null;
		float percent = 0.0f;
		
		String street = null;
		String city = null;
		
		System.out.print("Enter name: ");
		name = scInput.nextLine();
			
		System.out.print("Enter percent: ");
		percent = scInput.nextFloat();
				  scInput.nextLine();
					  
		System.out.print("Enter street: ");
		street = scInput.nextLine();
		
		System.out.print("Enter city: ");
		city = scInput.nextLine();
		
		address = new Address(street, city);
		
		student = new Student(name, percent, address);
		
		student.output();
				
		scInput.close();

	}

}
