package com.capgemini.entity;

public class Student {
	private static int rno;
	
	private int rollno;//0
	private String name;//null
	private float percent;//0.0f
	
	private Address address;
	
	//byte, short, int & long = 0
	//char = \\u0000
	//Reference variable = null;
	//float = 0.0f
	//double = 0.0
	//boolean = false
	
	public Student() {//default constructor. It will not have any parameters.
		rollno = ++rno;
		name = new String("Bhalchandra");
		percent = 100.00f;
	}
	
	public Student(String name, float percent) {
		this.rollno = ++rno;
		this.name = name;
		this.percent = percent;
	}
	
	public Student(String name, float percent, Address address) {
		super();
		this.name = name;
		this.percent = percent;
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getRollno() {
		return rollno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPercent() {
		return this.percent;
	}
	
	public void setPercent(float percent) {
		this.percent = percent;
	}
	public void output() {
		System.out.println("Roll No.: " + rollno);
		System.out.println("Name: " + name);
		System.out.println("Percent: " + percent);
		address.output();
	}
	
	public static void printLastRollNo() {
		System.out.println("Last roll no: " + rno);
	}
}
