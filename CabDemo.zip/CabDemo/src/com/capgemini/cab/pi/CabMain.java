package com.capgemini.cab.pi;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.cab.bean.CustomerBean;
import com.capgemini.cab.exception.CabException;
import com.capgemini.cab.service.ServiceCabImpl;

public class CabMain {
	private static Logger logger = Logger.getRootLogger();
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		
		int choice = -1;
		
		Scanner scInput = new Scanner(System.in);
		ServiceCabImpl serviceCabImpl = new ServiceCabImpl();
		
		String customer_name;
		String phone_number;
		
		String cab_number;
		String address_of_pickup;
		String pincode;
		int request_id = 0;
		
		while(choice != 0){
			System.out.println("1. Register customer");
			System.out.println("2. Book Cab");
			System.out.println("0. Exit");
			
			choice = Integer.parseInt(scInput.nextLine());
			
			switch(choice){
			case 1:
				System.out.print("Customer name: ");
				customer_name = scInput.nextLine();
				
				System.out.print("Phone number: ");
				phone_number = scInput.nextLine();
				
				System.out.print("Address of pickup: ");
				address_of_pickup = scInput.nextLine();
				
				System.out.print("Pin code: ");
				pincode = scInput.nextLine();
				
				CustomerBean customerBean = new CustomerBean(customer_name, phone_number, address_of_pickup, pincode);
				try {
					request_id = serviceCabImpl.addCustomer(customerBean);
					
					if(request_id > 1001){
						System.out.println("Record inserted successfully.");
					}
					
					System.out.println("Your Registration ID is: " + request_id);
				} catch (CabException e) {
					logger.error(e.getMessage());
				}
				
				break;
			case 2:
				try {
					cab_number = serviceCabImpl.bookCab(request_id);
					System.out.println("Your cab is booked. Cab number: " + cab_number);
				} catch (CabException e) {
					logger.error(e.getMessage());
				}
				break;
			case 0:
				System.out.println("End of Program.");
				break;
			default:
				System.out.println("Invalid input");
				break;
			}
		}
		
		scInput.close();
		
	}
}