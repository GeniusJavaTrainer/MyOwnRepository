package com.capgemini.cab.service;

import com.capgemini.cab.bean.CustomerBean;
import com.capgemini.cab.dao.CustomerDAOImpl;
import com.capgemini.cab.dao.ICustomerDAO;
import com.capgemini.cab.exception.CabException;

public class ServiceCabImpl implements IServiceCab {
	private ICustomerDAO customerDAO;
	
	public ServiceCabImpl() {
		customerDAO = new CustomerDAOImpl();
	}
	
	@Override
	public int addCustomer(CustomerBean customerBean) throws CabException {
		int requestID = 0;
		requestID = customerDAO.insertCustomer(customerBean);
		return requestID;
	}

	@Override
	public int getRequestId() throws CabException{
		int requestId = 0;
		
		requestId = customerDAO.getID();
		
		return requestId;
	}

	@Override
	public String bookCab(int requestId) throws CabException {
		String cab_number = customerDAO.updateCustomer(requestId);
		return cab_number;
	}
}