package com.capgemini.cab.bean;

import java.time.LocalDate;

public class CustomerBean {
	private int requestId;
	private String customer_name;
	private String phone_number;
	private LocalDate date_of_request;
	private String cab_number;
	private String address_of_pickup;
	private String pincode;
	
	public CustomerBean() {
		super();
	}

	public CustomerBean(String customer_name, String phone_number, String address_of_pickup, String pincode) {
		super();
		this.customer_name = customer_name;
		this.phone_number = phone_number;
		this.address_of_pickup = address_of_pickup;
		this.pincode = pincode;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public LocalDate getDate_of_request() {
		return date_of_request;
	}

	public void setDate_of_request(LocalDate date_of_request) {
		this.date_of_request = date_of_request;
	}

	public String getCab_number() {
		return cab_number;
	}

	public void setCab_number(String cab_number) {
		this.cab_number = cab_number;
	}

	public String getAddress_of_pickup() {
		return address_of_pickup;
	}

	public void setAddress_of_pickup(String address_of_pickup) {
		this.address_of_pickup = address_of_pickup;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "CustomerBean [requestId=" + requestId + ", customer_name=" + customer_name + ", phone_number="
				+ phone_number + ", date_of_request=" + date_of_request + ", cab_number=" + cab_number
				+ ", address_of_pickup=" + address_of_pickup + ", pincode=" + pincode + "]";
	}
}