package com.capgemini.cab.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.capgemini.cab.bean.CustomerBean;
import com.capgemini.cab.exception.CabException;
import com.capgemini.cab.util.DBConnection;

public class CustomerDAOImpl implements ICustomerDAO {

	@Override
	public int insertCustomer(CustomerBean customerBean) throws CabException {
		int records = 0;
		boolean isInserted = false;
		int customerId = 0;
		try(Connection connMobile = DBConnection.getInstance().getConnection();
			PreparedStatement preparedStatement= 
			connMobile.prepareStatement(QueryMapperCustomer.INSERT_CABREQUEST);
			PreparedStatement pst = 
						connMobile.prepareStatement(QueryMapperCustomer.SHOW_ID);
			){
			java.sql.Date regDate = Date.valueOf(LocalDate.now());
			
			preparedStatement.setString(1, customerBean.getCustomer_name());
			preparedStatement.setString(2, customerBean.getPhone_number());
			preparedStatement.setDate(3, regDate);
			preparedStatement.setString(4,customerBean.getAddress_of_pickup());
			preparedStatement.setString(5,customerBean.getPincode());
			
			records = preparedStatement.executeUpdate();
			
			if(records > 0){
				isInserted = true;
			}
			
			ResultSet rsMobiles = pst.executeQuery();
			
			if(rsMobiles.next()){
				customerId = rsMobiles.getInt("cabid");
			}
		}catch(SQLException sqlEx){
			throw new CabException(sqlEx.getMessage());
		}
		
		return customerId;
	}

	@Override
	public int viewCabs(String pin) throws CabException {
		int cabid = 0;
		try(Connection connMobile = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement= 
				connMobile.prepareStatement(QueryMapperCustomer.VIEW_CABS);
				){
				preparedStatement.setString(1, pin);
				ResultSet rsMobiles = preparedStatement.executeQuery();
				
				if(rsMobiles.next()){
					cabid = rsMobiles.getInt("cabid");
				}
			}catch(SQLException sqlEx){
				throw new CabException(sqlEx.getMessage());
			}
		return cabid;
	}

	@Override
	public int getID() throws CabException {
		int customerId = 0;
		try(Connection connMobile = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement= 
				connMobile.prepareStatement(QueryMapperCustomer.SHOW_ID);
				){
				ResultSet rsMobiles = preparedStatement.executeQuery();
				
				if(rsMobiles.next()){
					customerId = rsMobiles.getInt(1);
				}
			}catch(SQLException sqlEx){
				sqlEx.printStackTrace();
				throw new CabException(sqlEx.getMessage());
			}
		return customerId;
	}

	@Override
	public String updateCustomer(int requestId) throws CabException {
		int pincode = 0 ;
		String cab_number = null;
		
		try(Connection connCab = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement= 
				connCab.prepareStatement(QueryMapperCustomer.VIEW_PINCODE);
				PreparedStatement pstCab = 
						connCab.prepareStatement(QueryMapperCustomer.VIEW_CABS);
				PreparedStatement pstUpdate = 
						connCab.prepareStatement(QueryMapperCustomer.UPDATE_CABREQUEST);
				){
				ResultSet rsMobiles = preparedStatement.executeQuery();
				
				if(rsMobiles.next()){
					pincode = rsMobiles.getInt("pincode");
				}
				
				pstCab.setInt(1,pincode);
				rsMobiles = pstCab.executeQuery();
				
				if(rsMobiles.next()){
					cab_number = rsMobiles.getString("cab_number");
				}
				pstUpdate.setString(1, cab_number);
				pstUpdate.setInt(2,pincode);
				
				pstUpdate.executeUpdate();
			}catch(SQLException sqlEx){
				throw new CabException(sqlEx.getMessage());
			}
		
		return cab_number;
	}

}
