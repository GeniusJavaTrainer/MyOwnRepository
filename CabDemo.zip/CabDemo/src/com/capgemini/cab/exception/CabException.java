package com.capgemini.cab.exception;

public class CabException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4473513424240627536L;

	public CabException(){
		super();
	}

	public CabException(String message) {
		super(message);
	}
	
	
}
