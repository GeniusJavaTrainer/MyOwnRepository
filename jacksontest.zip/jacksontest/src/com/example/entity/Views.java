package com.example.entity;

public class Views {
    public static class Public {}
 
    public static class Internal extends Public {}
}