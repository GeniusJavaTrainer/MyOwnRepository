package com.example.entity;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@JsonIdentityInfo(
		  generator = ObjectIdGenerators.PropertyGenerator.class, 
		  property = "id")

//@JsonIgnore
//@JsonManagedReference
//@JsonBackReference
public class User {
	
    public int id;
 
    
    public String name;
 
    @JsonBackReference
    public List<Item> userItems;

	public User() {
		super();
	}

	public User(int id, String name, List<Item> userItems) {
		super();
		this.id = id;
		this.name = name;
		this.userItems = userItems;
	}

	
	public User(int id, String name) {
		super();
		this.id = id;
		this.name = name;
		this.userItems = new ArrayList<>();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Item> getUserItems() {
		return userItems;
	}

	public void setUserItems(List<Item> userItems) {
		this.userItems = userItems;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", userItems=" + userItems + "]";
	}
	
	public void addItem(Item item) {
		this.userItems.add(item);
	}
}