package com.example.test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.example.entity.Item;
import com.example.entity.User;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ApplicationTest {

	@Test
	public void
	  givenBidirectionRelation_whenUsingJacksonReferenceAnnotation_thenCorrect()
	  throws JsonProcessingException {
	  
	    User user = new User(1, "John");
	    Item item = new Item(2, "book", user);
	    user.addItem(item);
	 
	    String result = new ObjectMapper().writeValueAsString(item);
	 
	    assertThat(result, containsString("book"));
	    assertThat(result, containsString("John"));
	    assertThat(result, not(containsString("userItems")));
	}

	@Test
	public void givenBidirectionRelation_whenUsingJsonIdentityInfo_thenCorrect()
	  throws JsonProcessingException {
	  
	    User user = new User(1, "John");
	    Item item = new Item(2, "book", user);
	    user.addItem(item);
	 
	    String result = new ObjectMapper().writeValueAsString(item);
	 
	    assertThat(result, containsString("book"));
	    assertThat(result, containsString("John"));
	}
	
	/*@Test
	public void givenBidirectionRelation_whenUsingJsonIgnore_thenCorrect()
	  throws JsonProcessingException {
	  
	    User user = new User(1, "John");
	    Item item = new Item(2, "book", user);
	    user.addItem(item);
	 
	    String result = new ObjectMapper().writeValueAsString(item);
	 
	    assertThat(result, containsString("book"));
	    assertThat(result, containsString("John"));
	    assertThat(result, not(containsString("userItems")));
	}*/
}
