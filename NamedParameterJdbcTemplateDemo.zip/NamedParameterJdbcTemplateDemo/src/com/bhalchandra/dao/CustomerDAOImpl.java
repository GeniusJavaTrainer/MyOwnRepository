package com.bhalchandra.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.bhalchandra.entity.CustomerTO;

public class CustomerDAOImpl implements Customer {
	private NamedParameterJdbcTemplate  namedParameterJdbcTemplate;
	
	public void setDataSource(DataSource dataSource){
		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}
	
	@Override
	public void insertCustomer(CustomerTO customer) {
		String query = "INSERT INTO customer100 VALUES(:customerId,:customerName,:address)";
		
		Map<String, Object>namedParameters = new HashMap<String,Object>();
		
		int custId = customer.getCustomerId();
		String name = customer.getName();
		String address = customer.getAddress();
		
		namedParameters.put("customerId", custId);
		namedParameters.put("customerName", name);
		namedParameters.put("address", address);
		
		namedParameterJdbcTemplate.update(query, namedParameters);
	}

	@Override
	public void updateCustomer(CustomerTO customer) {
		String query = "UPDATE customer100 SET customerId=:customerId, customername=:customerName, address=:address "
				+ "WHERE customerId=:customerId";
		
		Map<String, Object>namedParameters = new HashMap<String,Object>();
		
		int custId = customer.getCustomerId();
		String name = customer.getName();
		String address = customer.getAddress();
		
		namedParameters.put("customerId", custId);
		namedParameters.put("customerName", name);
		namedParameters.put("address", address);
		
		namedParameterJdbcTemplate.update(query, namedParameters);
	}

	@Override
	public void deleteCustomer(CustomerTO customer) {
		String query = "DELETE FROM customer100 WHERE customerId=:customerId";
		
		Map<String, Object>namedParameters = new HashMap<String,Object>();
		
		int custId = customer.getCustomerId();
				
		namedParameters.put("customerId", custId);
				
		namedParameterJdbcTemplate.update(query, namedParameters);
	}

	@Override
	public void insertUsingProcedure(CustomerTO customer) {
		String query = "{CALL insertit(:customerId,:customerName,:address)}";
		
		Map<String, Object>namedParameters = new HashMap<String,Object>();
		
		int custId = customer.getCustomerId();
		String name = customer.getName();
		String address = customer.getAddress();
		
		namedParameters.put("customerId", custId);
		namedParameters.put("customerName", name);
		namedParameters.put("address", address);
		
		namedParameterJdbcTemplate.update(query, namedParameters);
	}

	@Override
	public CustomerTO selectCustomer(CustomerTO customer) {
		CustomerTO customerFound = null;
		
		int custId = customer.getCustomerId();
		
		String query = "SELECT * FROM customer100 WHERE customerId = :customerId";
		SqlParameterSource namedParameters = new MapSqlParameterSource("customerId",custId);
		
		customerFound = (CustomerTO)namedParameterJdbcTemplate.queryForObject(query, namedParameters,
		new RowMapper(){
			@Override
			public Object mapRow(ResultSet resultSet, int rowNum) throws SQLException{
				int custId = resultSet.getInt("customerid");
				String name = resultSet.getString("customername");
				String address = resultSet.getString("address");
				
				CustomerTO customer = new CustomerTO(custId, name, address);
				return customer;
			}
		}
		);
		return customerFound;
	}
}