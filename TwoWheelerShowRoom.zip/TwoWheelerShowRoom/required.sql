CREATE TABLE twowheeler
(
	twowheelerId INT PRIMARY KEY,
	modelName VARCHAR2(40),
	mileage FLOAT,
	price FLOAT
);

CREATE TABLE user_showroom
(
	username VARCHAR2(40) PRIMARY KEY,
	password VARCHAR2(40),
	isAdmin VARCHAR2(1)
);

CREATE SEQUENCE twowheel_seq_id START WITH 1;

INSERT INTO user_showroom VALUES('admin','admin','Y');
INSERT INTO user_showroom VALUES('sales','sales123','N');
INSERT INTO user_showroom VALUES('accountant','acc123','N');