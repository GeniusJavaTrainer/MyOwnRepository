package com.zensar.showroom.utility;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.zensar.showroom.exception.ShowroomException;




public class DbConnection {
	public static Connection getConnection() throws ShowroomException {
		Connection conn = null;

		try {
			InitialContext ic = new InitialContext();
			Context context = (Context) ic.lookup("java:/comp/env");
			DataSource ds = (DataSource)context.lookup("jdbc/OracleDS");
			conn = ds.getConnection();
		}

		catch (SQLException e) {
			throw new ShowroomException("SQL Error:"+e.getMessage());
		} catch (NamingException e) {
			throw new ShowroomException("message from DB/NamingExc:"
					+ e.getMessage());
		}
		return conn;
	}
}