package com.zensar.showroom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.zensar.showroom.entity.User;
import com.zensar.showroom.exception.ShowroomException;
import com.zensar.showroom.utility.DbConnection;

public class UserDAOImpl implements UserDAO {

	@Override
	public User isUserValid(String username, String password) throws ShowroomException {
		User user = new User();
		
		Connection connUser = null;
		PreparedStatement pstUser = null;
		ResultSet rsUser = null;
		
		try{
			connUser = DbConnection.getConnection();
			pstUser = connUser.prepareStatement(IQueryMapperUser.IS_USER_VALID);
			
			pstUser.setString(1, username);
			pstUser.setString(2, password);
			
			rsUser = pstUser.executeQuery();
			
			while(rsUser.next()){
				user.setUsername(rsUser.getString("username"));
				String isAdmin = rsUser.getString("isAdmin");
				
				if(isAdmin.equals("Y")){
					user.setAdmin(true);
				}else{
					user.setAdmin(false);
				}
				
			}
		}catch(SQLException se){
			throw new ShowroomException(se.getMessage());
		}finally{
			try {
				if(connUser != null){
					connUser.close();
				}
			} catch (SQLException e) {
				throw new ShowroomException(e.getMessage());
			}
		}
		return user;
	}
}