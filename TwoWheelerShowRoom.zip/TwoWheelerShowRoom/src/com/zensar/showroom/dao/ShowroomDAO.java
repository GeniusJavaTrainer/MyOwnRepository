package com.zensar.showroom.dao;

import java.util.List;

import com.zensar.showroom.entity.TwoWheeler;
import com.zensar.showroom.exception.ShowroomException;

public interface ShowroomDAO {
	public boolean insertTwowheeler(TwoWheeler twoWheeler) throws ShowroomException;
	public boolean updateTwowheeler(TwoWheeler twoWheeler) throws ShowroomException;
	public boolean deleteTwowheeler(int twoWheelerId) throws ShowroomException;
	public List<TwoWheeler> getTwowheelers() throws ShowroomException;
}