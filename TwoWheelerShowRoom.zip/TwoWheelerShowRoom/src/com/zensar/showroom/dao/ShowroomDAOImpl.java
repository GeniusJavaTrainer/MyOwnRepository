package com.zensar.showroom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.zensar.showroom.entity.TwoWheeler;
import com.zensar.showroom.exception.ShowroomException;
import com.zensar.showroom.utility.DbConnection;

public class ShowroomDAOImpl implements ShowroomDAO {

	@Override
	public boolean insertTwowheeler(TwoWheeler twoWheeler) throws ShowroomException {
		boolean isInserted = false;
		Connection connTwowheeler = null;
		PreparedStatement pstTwowheeler = null;
				
		try{
			connTwowheeler = DbConnection.getConnection();
			pstTwowheeler = connTwowheeler.prepareStatement(IQueryMapperTwoWheeler.INSERT_TWOWHEELER);
			
			pstTwowheeler.setString(1, twoWheeler.getModelName());
			pstTwowheeler.setFloat(2, twoWheeler.getMileage());
			pstTwowheeler.setFloat(3, twoWheeler.getPrice());
			
			int records = pstTwowheeler.executeUpdate();
			
			if(records > 0){
				isInserted = true;
			}
		}catch(SQLException se){
					throw new ShowroomException(se.getMessage());
		}finally{
			try {
				if(connTwowheeler != null){
					connTwowheeler.close();
				}
			} catch (SQLException e) {
				throw new ShowroomException(e.getMessage());
			}
		}
		return isInserted;
	}

	@Override
	public boolean updateTwowheeler(TwoWheeler twoWheeler) throws ShowroomException {
		boolean isUpdated = false;
		Connection connTwowheeler = null;
		PreparedStatement pstTwowheeler = null;
				
		try{
			connTwowheeler = DbConnection.getConnection();
			pstTwowheeler = connTwowheeler.prepareStatement(IQueryMapperTwoWheeler.UPDATE_TWOWHEELER);
			
			pstTwowheeler.setString(1, twoWheeler.getModelName());
			pstTwowheeler.setFloat(2, twoWheeler.getMileage());
			pstTwowheeler.setFloat(3, twoWheeler.getPrice());
			pstTwowheeler.setInt(4, twoWheeler.getTwowheelerId());
			
			int records = pstTwowheeler.executeUpdate();
			
			if(records > 0){
				isUpdated = true;
			}
		}catch(SQLException se){
					throw new ShowroomException(se.getMessage());
		}finally{
			try {
				if(connTwowheeler != null){
					connTwowheeler.close();
				}
			} catch (SQLException e) {
				throw new ShowroomException(e.getMessage());
			}
		}
		return isUpdated;
	}

	@Override
	public boolean deleteTwowheeler(int twoWheelerId) throws ShowroomException {
		boolean isDeleted = false;
		Connection connTwowheeler = null;
		PreparedStatement pstTwowheeler = null;
				
		try{
			connTwowheeler = DbConnection.getConnection();
			pstTwowheeler = connTwowheeler.prepareStatement(IQueryMapperTwoWheeler.DELETE_TWOWHEELER);
			
			pstTwowheeler.setInt(1, twoWheelerId);
			
			int records = pstTwowheeler.executeUpdate();
			
			if(records > 0){
				isDeleted = true;
			}
		}catch(SQLException se){
					throw new ShowroomException(se.getMessage());
		}finally{
			try {
				if(connTwowheeler != null){
					connTwowheeler.close();
				}
			} catch (SQLException e) {
				throw new ShowroomException(e.getMessage());
			}
		}
		return isDeleted;
	}

	@Override
	public List<TwoWheeler> getTwowheelers() throws ShowroomException {
		List<TwoWheeler> twoWheelers = new ArrayList<>();
		
		Connection connTwowheeler = null;
		PreparedStatement pstTwowheeler = null;
		ResultSet rsTwowheeler = null;
		
		TwoWheeler twowheeler = null;
		
		try{
			connTwowheeler = DbConnection.getConnection();
			pstTwowheeler = connTwowheeler.prepareStatement(IQueryMapperTwoWheeler.VIEW_TWOWHEELERS);
			rsTwowheeler = pstTwowheeler.executeQuery();
			
			while(rsTwowheeler.next()){
				twowheeler = new TwoWheeler();
				twowheeler.setTwowheelerId(rsTwowheeler.getInt("twowheelerId"));
				twowheeler.setModelName(rsTwowheeler.getString("modelName"));
				twowheeler.setMileage(rsTwowheeler.getFloat("mileage"));
				twowheeler.setPrice(rsTwowheeler.getFloat("price"));
				
				twoWheelers.add(twowheeler);
			}
		}catch(SQLException se){
					throw new ShowroomException(se.getMessage());
		}finally{
			try {
				if(connTwowheeler != null){
					connTwowheeler.close();
				}
			} catch (SQLException e) {
				throw new ShowroomException(e.getMessage());
			}
		}
		return twoWheelers;
	}
}