package com.zensar.showroom.dao;

import com.zensar.showroom.entity.User;
import com.zensar.showroom.exception.ShowroomException;

public interface UserDAO {
	public User isUserValid(String username, String password) throws ShowroomException;
}