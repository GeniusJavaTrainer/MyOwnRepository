package com.zensar.showroom.dao;

public interface IQueryMapperTwoWheeler {
	public static final String INSERT_TWOWHEELER = "INSERT INTO twowheeler VALUES(twowheel_seq_id.NEXTVAL,?,?,?)";
	public static final String UPDATE_TWOWHEELER = "UPDATE twowheeler SET modelName=?, mileage=?, "
													+ "price=? WHERE twowheelerId=?";
	public static final String DELETE_TWOWHEELER = "DELETE FROM twowheeler WHERE twowheelerId=?";
	public static final String VIEW_TWOWHEELERS = "SELECT twowheelerId, modelName, mileage, price "
												  + " FROM twowheeler";
}