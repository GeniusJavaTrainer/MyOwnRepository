package com.zensar.showroom.dao;

public interface IQueryMapperUser {
	public static final String IS_USER_VALID = "SELECT username, isAdmin FROM user_showroom"
			+ " WHERE username=? AND password=?";
}