package com.zensar.showroom.exception;

public class ShowroomException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6477222039769119376L;

	public ShowroomException() {
		super();
	}

	public ShowroomException(String message){
		super(message);
	}

	public ShowroomException(Throwable exception) {
		super(exception);
	}

	public ShowroomException(String message, Throwable exception) {
		super(message, exception);
	}
}