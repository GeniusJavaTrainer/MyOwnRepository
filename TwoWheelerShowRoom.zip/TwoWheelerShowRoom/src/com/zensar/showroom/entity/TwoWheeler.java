package com.zensar.showroom.entity;

public class TwoWheeler {
	private int twowheelerId;
	private String modelName;
	private float mileage;
	private float price;
	
	public TwoWheeler() {
		super();
	}

	public TwoWheeler(int twowheelerId, String modelName, float mileage, float price) {
		super();
		this.twowheelerId = twowheelerId;
		this.modelName = modelName;
		this.mileage = mileage;
		this.price = price;
	}

	public int getTwowheelerId() {
		return twowheelerId;
	}

	public void setTwowheelerId(int twowheelerId) {
		this.twowheelerId = twowheelerId;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public float getMileage() {
		return mileage;
	}

	public void setMileage(float mileage) {
		this.mileage = mileage;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "TwoWheeler [twowheelerId=" + twowheelerId + ", modelName=" + modelName + ", mileage=" + mileage
				+ ", price=" + price + "]";
	}
}