package com.zensar.showroom.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zensar.showroom.entity.TwoWheeler;
import com.zensar.showroom.exception.ShowroomException;
import com.zensar.showroom.service.ShowroomService;
import com.zensar.showroom.service.ShowroomServiceImpl;

/**
 * Servlet implementation class ShowroomServlet
 */
public class ShowroomServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowroomServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ShowroomService showroomService = new ShowroomServiceImpl();
		
		String target = "";

		List<TwoWheeler>twoWheelerList = null;
		
		HttpSession session = request.getSession();
		
		String targetWelcome= "welcome.jsp";
		String targetLogout = "logout.jsp";
		String targetError = "error.jsp";
		String targetInsert = "insert.jsp";
		String targetUpdateDelete = "updatedelete.jsp";
		String targetUpdate = "update.jsp";		
		String targetView = "view.jsp";
		
		String path = request.getServletPath().trim();
		String username = null;
		String message = null;
		
		String modelName = null;
		float mileage = 0.0f;
		float price = 0.0f;
		int twoWheelerId = 0;
		
		TwoWheeler twoWheeler = null;
		
		switch (path) {

		case "/validate.obj":
			target = targetWelcome;
			boolean isAdmin = (boolean)request.getAttribute("isAdmin");
			username = request.getAttribute("username").toString();
			session.setAttribute("username", username);
			session.setAttribute("isAdmin", isAdmin);
			
			break;
			
		case "/insert.obj":
			target = targetInsert;
			break;

		case "/update.obj":
		case "/delete.obj":
			target = targetUpdateDelete;
			
			try {
				twoWheelerList = showroomService.view();
				session.setAttribute("twowheelers", twoWheelerList);
			} catch (ShowroomException e) {
				message = "Problem in receiving records";
				target = targetError;
			}
			break;
		
		case "/inserted.obj":
			target = targetWelcome;
			
			modelName = request.getParameter("modelName");
			mileage = Float.parseFloat(request.getParameter("mileage"));
			price = Float.parseFloat(request.getParameter("price"));
			
			twoWheeler = new TwoWheeler();
			twoWheeler.setMileage(mileage);
			twoWheeler.setModelName(modelName);
			twoWheeler.setPrice(price);
			
			try {
				boolean isInserted = showroomService.insertTwowheeler(twoWheeler);
				
				if(isInserted){
					message = "Record inserted successfully.";
				}else{
					message = "Record couldn't be inserted";
				}
				session.setAttribute("message", message);
			} catch (ShowroomException e) {
				message = e.getMessage();
				session.setAttribute("message", message);
			}
			break;
			
		case "/updateit.obj":
			target = targetUpdate;
			
			twoWheelerId = Integer.parseInt(request.getParameter("twoWheelerId"));
			modelName = request.getParameter("modelName");
			mileage = Float.parseFloat(request.getParameter("mileage"));
			price = Float.parseFloat(request.getParameter("price"));
			
			twoWheeler = new TwoWheeler();
			twoWheeler.setTwowheelerId(twoWheelerId);
			twoWheeler.setMileage(mileage);
			twoWheeler.setModelName(modelName);
			twoWheeler.setPrice(price);
			
			session.setAttribute("twoWheeler", twoWheeler);
			break;
			
		case "/updated.obj":
			target = targetWelcome;
			
			twoWheelerId = Integer.parseInt(request.getParameter("twowheelerId"));
			modelName = request.getParameter("modelName");
			mileage = Float.parseFloat(request.getParameter("mileage"));
			price = Float.parseFloat(request.getParameter("price"));
			
			twoWheeler = new TwoWheeler();
			twoWheeler.setTwowheelerId(twoWheelerId);
			twoWheeler.setMileage(mileage);
			twoWheeler.setModelName(modelName);
			twoWheeler.setPrice(price);
			
			try {
				boolean isUpdated = showroomService.updateTwowheeler(twoWheeler);
				
				if(isUpdated){
					message = "Record updated successfully.";
				}else{
					message = "Record couldn't be updated";
				}
				session.setAttribute("message", message);
			} catch (ShowroomException e) {
				message = e.getMessage();
				session.setAttribute("message", message);
			}
			break;
			
		case "/deleted.obj":
			target = targetWelcome;
			
			twoWheelerId = Integer.parseInt(request.getParameter("twoWheelerId"));
			
			try {
				boolean isDeleted = showroomService.deleteTwowheeler(twoWheelerId);
				
				if(isDeleted){
					message = "Record deleted successfully.";
				}else{
					message = "Record couldn't be deleted";
				}
				session.setAttribute("message", message);
			} catch (ShowroomException e) {
				message = e.getMessage();
				session.setAttribute("message", message);
			}
			break;
		case "/logout.obj":
			target = targetLogout;
			session.invalidate();
			break;
			
		case "/view.obj":
			target = targetView;
			try {
				twoWheelerList = showroomService.view();
				session.setAttribute("twowheelers", twoWheelerList);
			} catch (ShowroomException e) {
				message = "Problem in receiving records";
				target = targetError;
			}
			break;
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}