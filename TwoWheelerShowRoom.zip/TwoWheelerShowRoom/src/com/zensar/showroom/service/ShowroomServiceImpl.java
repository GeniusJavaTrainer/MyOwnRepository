package com.zensar.showroom.service;

import java.util.List;

import com.zensar.showroom.dao.ShowroomDAO;
import com.zensar.showroom.dao.ShowroomDAOImpl;
import com.zensar.showroom.dao.UserDAO;
import com.zensar.showroom.dao.UserDAOImpl;
import com.zensar.showroom.entity.TwoWheeler;
import com.zensar.showroom.entity.User;
import com.zensar.showroom.exception.ShowroomException;

public class ShowroomServiceImpl implements ShowroomService {
	private UserDAO userDAO;
	private ShowroomDAO showroomDAO;
	
	public ShowroomServiceImpl() {
		userDAO = new UserDAOImpl();
		showroomDAO = new ShowroomDAOImpl();
	}
	@Override
	public User isUserValid(String username, String password) throws ShowroomException {
		return userDAO.isUserValid(username, password);
	}

	@Override
	public boolean insertTwowheeler(TwoWheeler twoWheeler) throws ShowroomException {
		return showroomDAO.insertTwowheeler(twoWheeler);
	}

	@Override
	public boolean updateTwowheeler(TwoWheeler twoWheeler) throws ShowroomException {
		return showroomDAO.updateTwowheeler(twoWheeler);
	}

	@Override
	public boolean deleteTwowheeler(int twoWheelerId) throws ShowroomException {
		return showroomDAO.deleteTwowheeler(twoWheelerId);
	}
	@Override
	public List<TwoWheeler> view() throws ShowroomException {
		return showroomDAO.getTwowheelers();
	}
}