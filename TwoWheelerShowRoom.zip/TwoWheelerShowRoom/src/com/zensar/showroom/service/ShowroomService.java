package com.zensar.showroom.service;

import java.util.List;

import com.zensar.showroom.entity.TwoWheeler;
import com.zensar.showroom.entity.User;
import com.zensar.showroom.exception.ShowroomException;

public interface ShowroomService {
	public User isUserValid(String username, String password) throws ShowroomException;
	public boolean insertTwowheeler(TwoWheeler twoWheeler) throws ShowroomException;
	public boolean updateTwowheeler(TwoWheeler twoWheeler) throws ShowroomException;
	public boolean deleteTwowheeler(int twoWheelerId) throws ShowroomException;
	public List<TwoWheeler> view() throws ShowroomException;
}