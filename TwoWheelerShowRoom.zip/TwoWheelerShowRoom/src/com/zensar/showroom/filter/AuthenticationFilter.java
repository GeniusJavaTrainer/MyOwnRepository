package com.zensar.showroom.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.zensar.showroom.entity.User;
import com.zensar.showroom.exception.ShowroomException;
import com.zensar.showroom.service.ShowroomService;
import com.zensar.showroom.service.ShowroomServiceImpl;

/**
 * Servlet Filter implementation class AuthenticationFilter
 */
public class AuthenticationFilter implements Filter {

    /**
     * Default constructor. 
     */
    public AuthenticationFilter() {
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		ShowroomService showroomService = new ShowroomServiceImpl();
		
		RequestDispatcher requestDispatch = null;
		
		User user = new User();
		
		String target = null;
		String message = null;
		
		String username = null;
		String password = null;
				
		username = request.getParameter("username");
		password = request.getParameter("password");
		
		try {
				user = showroomService.isUserValid(username, password);
				
				if(user.getUsername() != null){
					request.setAttribute("isAdmin", user.isAdmin());
					request.setAttribute("username", username);
					chain.doFilter(request, response);
				}else{
					target = "error.jsp";
					message = "Invalid User";
					request.setAttribute("errorMessage", message);
					requestDispatch = request.getRequestDispatcher(target);
					requestDispatch.forward(request, response);
				}
			} catch (ShowroomException e) {
				message = e.getMessage();
			}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
	}

}
