import http from "../http-common";

const getAll = () => {
  return http.get("/getAll");
};

const get = id => {
  return http.get(`/get/${id}`);
};

const create = data => {
  return http.post("/register", data);
};

const update = (data) => {
  return http.put(`/update`, data);
};

const remove = id => {
  return http.delete(`/delete/${id}`);
};


const EmployeeDataService = {
  getAll,
  get,
  create,
  update,
  remove
};

export default EmployeeDataService;
