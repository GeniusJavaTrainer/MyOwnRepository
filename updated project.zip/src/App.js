import React from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

import AddEmployee from "./components/AddEmployee";
import UpdateDeleteEmployee from "./components/UpdateDeleteEmployee";

function App() {
  return (
    <Router>
      <nav className="navbar navbar-expand navbar-dark bg-dark">

        <Link to={"/employees"}>
          <button className="btn btn-secondary">
            Home
          </button>
        </Link>

        <Link to={"/add"} className="nav-link">
          <button className="btn btn-secondary">
            Add a record
          </button>
        </Link>


      </nav>

      <div className="container mt-3" >
        <Switch>
          <Route exact path={["/", "/employees"]} component={UpdateDeleteEmployee} />
          <Route exact path="/add" component={AddEmployee} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
