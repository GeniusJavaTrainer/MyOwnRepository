import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { insertEmployee } from "../actions/employees";

const AddEmployee = () => {
  const initialEmployeeState = {
    name: "",
    salary: 0
  };
  const [employee, setEmployee] = useState(initialEmployeeState);

  const dispatch = useDispatch();

  const handleInputChange = event => {
    const { name, value } = event.target;
    setEmployee({ ...employee, [name]: value });
  };

  const saveEmployee = () => {
    const { name, salary } = employee;

    dispatch(insertEmployee(name, salary))
      .then(data => {
        setEmployee({
          name: data.name,
          salary: data.salary
        });

        console.log(data);
        document.getElementById("name").value = ""
        document.getElementById("salary").value = ""
        alert("Record has been added successfully...")
      })
      .catch(e => {
        console.log(e);
      });

  };

  return (
    <div className="submit-form" >
      <div>
        <div className="form-group">
          <label htmlFor="Name">Name</label>
          <input
            type="text"
            className="form-control"
            id="name"
            required

            onChange={handleInputChange}
            name="name"
          />
        </div>

        <div className="form-group">
          <label htmlFor="Salary">Salary</label>
          <input
            type="number"
            className="form-control"
            id="salary"
            required

            onChange={handleInputChange}
            name="salary"
          />
        </div>

        <br />
        <button onClick={saveEmployee} className="btn btn-dark">
          <i class="fa fa-book"></i>Submit
        </button>

      </div>

    </div>

  );
};

export default AddEmployee;