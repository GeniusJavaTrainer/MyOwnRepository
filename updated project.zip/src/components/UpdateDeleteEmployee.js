import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getEmployees, deleteEmployee, updateEmployee
} from "../actions/employees";



const UpdateDeleteEmployee = () => {
  const [currentEmployee, setCurrentEmployee] = useState(null);
  const [searchName, setSearchName] = useState("");

  const employees = useSelector(state => state.employees);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getEmployees());
  });

  const handleInputChange = event => {

    const { name, value } = event.target;
    setCurrentEmployee({ ...currentEmployee, [name]: value });
  };

  const updateContent = (eid, index) => {

    var myEmp = currentEmployee
    myEmp.empid = eid
    myEmp.name = document.getElementById("name" + index).value
    myEmp.salary = document.getElementById("salary" + index).value

    dispatch(updateEmployee(myEmp))
      .then(response => {
        console.log(response);
      })
      .catch(e => {
        console.log(e);
      });
  };

  const removeEmployee = (empid) => {

    dispatch(deleteEmployee(empid))
      .then(() => {
        console.log("Deleted")
      })
      .catch(e => {
        console.log(e);
      });
  };

  const onChangeSearchName = e => {
    const searchName = e.target.value;
    setSearchName(searchName);
  };

  return (
    <div className="list row">
      <div className="col-md-8">
        <div className="input-group mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Search by name. . ."
            value={searchName}
            onChange={onChangeSearchName}
          />
        </div>
      </div>
      <div className="col-md-6">
        <h4>Employee Records</h4>

        <form>

          <table border="2" align="center" width="100%">

            <tr>

              <th>Name</th>
              <th>Salary</th>
              <th>Actions</th>

            </tr>

            {employees &&
              employees.filter(employee => (searchName == "") ? true : employee.name == searchName).map((employee, index) => (

                <tr
                  key={index}
                >
                  <td align="left"><input type="text" id={"name" + index} name="name" defaultValue={employee.name} onChange={handleInputChange} /></td>
                  <td align="left"><input type="text" id={"salary" + index} name="salary" defaultValue={employee.salary} onChange={handleInputChange} /></td>
                  <button className="btn btn-dark" type="submit" onClick={() => updateContent(employee.empid, index)}><i class="fa fa-book"></i>Save</button>
                  <td>
                    <button className="btn btn-dark" type="submit" onClick={() => { removeEmployee(employee.empid) }}><i class="fa fa-trash"></i>Delete</button>
                  </td>
                </tr>
              ))
            }
          </table>
        </form>
      </div>

    </div>
  );
};

export default UpdateDeleteEmployee;