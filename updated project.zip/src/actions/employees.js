import {
  CREATE_EMPLOYEE,
  READ_EMPLOYEES,
  UPDATE_EMPLOYEE,
  DELETE_EMPLOYEE
} from "./types";

import EmployeeDataService from "../services/EmployeeDataService";

export const insertEmployee = (name, salary) => async (dispatch) => {
  try {
    const res = await EmployeeDataService.create({ name, salary });

    dispatch({
      type: CREATE_EMPLOYEE,
      payload: res.data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const getEmployees = () => async (dispatch) => {
  try {
    const res = await EmployeeDataService.getAll();

    dispatch({
      type: READ_EMPLOYEES,
      payload: res.data,
    });
    console.log(res.data)
    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err)
  }
};

export const updateEmployee = (data) => async (dispatch) => {
  try {
    const res = await EmployeeDataService.update(data);

    dispatch({
      type: UPDATE_EMPLOYEE,
      payload: data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err)
  }
};

export const deleteEmployee = (id) => async (dispatch) => {
  try {
    await EmployeeDataService.remove(id);

    dispatch({
      type: DELETE_EMPLOYEE,
      payload: { id },
    });
  } catch (err) {
    console.log(err);
  }
};