import {
  CREATE_EMPLOYEE,
  READ_EMPLOYEES,
  UPDATE_EMPLOYEE,
  DELETE_EMPLOYEE
} from "../actions/types";

const initialState = [];

const employees = (employees = initialState, action) => {
  const { type, payload } = action;

  switch (type) {
    case CREATE_EMPLOYEE:
      return [...employees, payload];

    case READ_EMPLOYEES:
      return payload;

    case UPDATE_EMPLOYEE:
      return employees.map((employee) => {
        if (employee.empid === payload.empid) {
          return {
            ...employee,
            ...payload,
          };
        } else {
          return employee;
        }
      });

    case DELETE_EMPLOYEE:
      return employees.filter(({ id }) => id !== payload.id);

    default:
      return employees;
  }
};

export default employees;