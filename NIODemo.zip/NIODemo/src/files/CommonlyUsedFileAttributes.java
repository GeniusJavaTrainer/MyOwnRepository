package files;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class CommonlyUsedFileAttributes {

	public static void main(String[] args) {
		
		Path target = Paths.get("d:\\poems\\dir2\\luci1_backup.txt");
				
		try {
			System.out.println("File Size: " + Files.size(target)+" bytes");
			System.out.println("Is " + target + " a hidden file? " + Files.isHidden(target));
			System.out.println("Is " + target + " a regular file? " + Files.isRegularFile(target));
			System.out.println("Is " + target + " a directory? " + Files.isDirectory(target));
			System.out.println("Last accessed time of " + target + ": " +Files.getLastModifiedTime(target));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}