package files;

import java.io.File;

public class CreateDirectory {

	public static void main(String[] args) {
		File file = new File("d:/mydirectory");
		File file1 = new File("d:/sample/important");
		try{
			boolean isCreated = file.mkdir();
			
			if(isCreated){
				System.out.println("Directory created: " + file.toString());
			}else{
				System.out.println("Directory already exists!");
			}
			
			isCreated = file1.mkdirs();
			
			if(isCreated){
				System.out.println("Directory created: " + file1.toString());
			}else{
				System.out.println("Directory already exists!");
			}
		}catch(SecurityException ioe){
			System.out.println(ioe.getMessage());
		}
	}
}