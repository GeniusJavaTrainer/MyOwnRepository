package files;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class FileDemo {
	public static void main(String[] args) {
		File file = null;
		FileInputStream fis = null;
		
		try{
			file = new File("abc.txt");
			
			if(file.exists()){
			fis = new FileInputStream(file);
			int value = 0;
			
			value = fis.read();
			
			while( value != -1){
				System.out.print((char)value);
				value = fis.read();
			}
			
			System.out.println("\nDetails of the file: ");
			System.out.println("Is it a file? " + file.isFile());
			System.out.println("Is it a directory? " + file.isDirectory());
			System.out.println("Is it an executable file? " + file.canExecute());
			System.out.println("Is it a hidden file? " + file.isHidden());
			System.out.println("Is it a readable file? " + file.canRead());
			System.out.println("Is it a writable file? " + file.canWrite());
			System.out.println("Path of the file: " + file.getCanonicalPath());
			
			file = new File("xyz.txt");
			File anotherFile = new File("pqr.txt");
			
			if(!file.exists()){
				file.createNewFile();//blank file created.
				System.out.println("A blank file created!");
				/*file.delete();
				System.out.println("File deleted!");*/
				
			}else{
				file.renameTo(anotherFile);
				System.out.println("Renamed to " + anotherFile.toString());
			}
			}else{
				System.out.println("File does not exist.");
			}
			
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}finally{
			if(fis != null){
				
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}