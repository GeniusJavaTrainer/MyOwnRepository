package files;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class FileMove {
	public static void main(String[] args) {
		Path source = Paths.get("d:\\poems\\luci1.txt");
		Path target = Paths.get("d:\\poems\\dir2\\luci1_backup.txt");
		
		try{
			Path p = Files.move(source, target, StandardCopyOption.ATOMIC_MOVE);
			System.out.println(source + " has been moved to " + p);
		}catch(NoSuchFileException fae){
			System.out.println("source does not exists.");
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}
	}
}