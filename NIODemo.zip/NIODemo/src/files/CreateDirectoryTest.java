package files;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class CreateDirectoryTest {

	public static void main(String[] args) {
		Path p1 = Paths.get("c:\\hello");
		Path p2 = Paths.get("c:\\hello2\\dir2");
		
		try{
			Path p3 = Files.createDirectory(p1);
			System.out.println(p3.toRealPath());
			
			Path p4 = Files.createDirectories(p2);
			System.out.println(p4.toRealPath());
			
		}catch(FileAlreadyExistsException ioe){
			System.out.println("Directory being created is already existing: "+ioe.getMessage());
		}catch(IOException ioe){
			ioe.printStackTrace();
		}
	}
}