package files;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


public class SameFileTest {

	public static void main(String[] args) {
		Path p1 = Paths.get("d:\\poems\\luci1.txt");
		Path p2 = Paths.get("d:\\poems\\..\\poems\\luci1.txt");
		
		Path p3 = Paths.get("C:\\abc.txt");
		Path p4 = Paths.get("C:\\abc.txt");
		
		try{
			boolean isSame = Files.isSameFile(p1, p2);
			System.out.println("Is p1 & p2 same?" + isSame);
			
			isSame = Files.isSameFile(p3, p4);
			System.out.println("Is p3 & p4 same? " + isSame);
		}catch(IOException ioe){
			ioe.printStackTrace();
			System.out.println(ioe.getMessage());
		}
	}
}