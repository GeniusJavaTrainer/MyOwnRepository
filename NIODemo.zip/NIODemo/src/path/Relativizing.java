package path;
import java.nio.file.Path;
import java.nio.file.Paths;


public class Relativizing {
	public static void main(String[] args) {
		Path p1 = Paths.get("poems");
		Path p2 = Paths.get("poems\\recent\\Luci");
		
		System.out.println(p1.relativize(p2));// recent\Luci
		System.out.println(p2.relativize(p1));// ..\..
	
		Path p3 = Paths.get("Donna");// ..\Bobby
		Path p4 = Paths.get("Bobby");// ..\Donna
		
		System.out.println(p3.relativize(p4));
		System.out.println(p4.relativize(p3));
	}
}