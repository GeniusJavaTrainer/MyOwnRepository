package path;
import java.nio.file.Path;
import java.nio.file.Paths;


public class ComparingPaths {
	public static void main(String[] args) {
		Path p1 = Paths.get("C:\\POEMS\\Muci1.txt");
		Path p2 = Paths.get("C:\\POEMS\\LUCI1.txt");
		
		Path p3 = Paths.get("c:\\poems\\..");
		Path p4 = Paths.get("C:\\POEMST\\LUCI1.txt");
		
		boolean b1 = p1.equals(p2);
		System.out.println(b1);
		
		boolean b2 = p1.equals(p3);
		System.out.println(b2);
		
		int c1 = p1.compareTo(p2);
		System.out.println(c1);
		
		c1 = p1.compareTo(p4);
		System.out.println(c1);
	}
}