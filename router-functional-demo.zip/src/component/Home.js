function Home() {
    return <h1>At Home!</h1>
}

export default Home;