function Shop() {
    return <h1>At Shop!</h1>
}

export default Shop;