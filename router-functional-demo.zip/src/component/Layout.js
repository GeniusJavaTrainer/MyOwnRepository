import { Outlet, Link } from "react-router-dom"

import "bootstrap/dist/css/bootstrap.min.css"

function Layout() {
    return (
        <>
            <nav>
                <Link to="/">
                    <button className="btn btn-primary">
                        Home
                    </button>
                </Link>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Link to="/shop">
                    <button className="btn btn-primary">
                        Shop
                    </button>
                </Link>
            </nav>
            <Outlet />
        </>
    );
}

export default Layout;