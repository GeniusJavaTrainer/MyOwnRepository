import { BrowserRouter, Routes, Route } from "react-router-dom"
import Layout from "./component/Layout"
import Home from "./component/Home"
import Shop from "./component/Shop";
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <BrowserRouter>
          <Routes>
            <Route path='/' element={<Layout />}>
              <Route index element={<Home />} />
              <Route path="shop" element={<Shop />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </header>
    </div>
  );
}

export default App;
