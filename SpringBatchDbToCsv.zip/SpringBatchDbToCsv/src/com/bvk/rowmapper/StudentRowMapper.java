package com.bvk.rowmapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bvk.model.Student;

public class StudentRowMapper implements RowMapper<Student> {

	@Override
	public Student mapRow(ResultSet rsStudent, int rowNum) throws SQLException {
		Student student = new Student();
		
		student.setRollno(rsStudent.getInt("rollno"));
		student.setName(rsStudent.getString("name"));
		student.setBranch(rsStudent.getString("branch"));
		student.setPercent(rsStudent.getFloat("percent"));
		
		return student;
	}
}