package me.aboullaite.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import me.aboullaite.dao.PolicyRepository;
import me.aboullaite.model.Policy;

@Service
public class PolicyService {
	@Autowired
	private PolicyRepository policyRepository;
	
	
	List<Policy> policies=new ArrayList<>();
	
	public List<Policy> getAllTopics()
	{
		//return policies;
		List<Policy> policies=new ArrayList<>();
		policyRepository.findAll().forEach(policies::add);
		return policies;
	}
	
	
	public Policy getPolicy(String id)
	{
		//return policies.stream().filter(t -> t.getId().equals(id)).findFirst().get();
		return policyRepository.findOne(id);
	
	}


	public void addPolicy(Policy policy)
	{
     //policies.add(policy);
		policyRepository.save(policy);
		
	}


	public void deletePolicy(String id) {
		
		//policies.removeIf(t -> t.getId().equals(id));
		policyRepository.delete(id);
	}

}
