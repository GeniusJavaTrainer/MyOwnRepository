package me.aboullaite.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import me.aboullaite.model.Policy;
import me.aboullaite.model.User;
import me.aboullaite.service.UserService;
import me.aboullaite.service.impl.PolicyService;

@RestController
@RequestMapping("/secure")
public class SecureController {

	@Autowired
	private UserService userService;

	@Autowired
	private PolicyService policyService;
	
	@RequestMapping("/user/users")
	public String loginSuccess() {
		return "Login Successful!";
	}

	@RequestMapping(value = "/user/email", method = RequestMethod.POST)
	public User findByEmail(@RequestBody String email) {
		return userService.findByEmail(email);
	}

	@RequestMapping(value = "/user/update", method = RequestMethod.POST)
	public User updateUser(@RequestBody User user) {
		return userService.save(user);
	}
	
	@RequestMapping("/policies")
	public List<Policy> getAllTopics()
	{
		return policyService.getAllTopics();
	}

	@RequestMapping("/policies/{id}")
	public Policy getPolicy(@PathVariable String id)
	{
		return policyService.getPolicy(id); 
	}
	
	@RequestMapping(method = RequestMethod.POST,value="/policies")
	public void addPolicy(@RequestBody Policy policy)
	{
		policyService.addPolicy(policy);
	}
	@RequestMapping(method = RequestMethod.DELETE,value="/policies/{id}")
	public void deletePolicy(@PathVariable String id)
	{
	 policyService.deletePolicy(id); 
	}
}