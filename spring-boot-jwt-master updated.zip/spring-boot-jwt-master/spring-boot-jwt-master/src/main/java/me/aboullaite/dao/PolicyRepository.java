package me.aboullaite.dao;

import org.springframework.data.repository.CrudRepository;

import me.aboullaite.model.Policy;

public interface PolicyRepository extends CrudRepository<Policy, String> {

}
