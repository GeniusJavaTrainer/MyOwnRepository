# spring-boot-jwt

This is an example project where a Spring REST API is secured using JSON Web Tokens. [Blog post on this subject](https://aboullaite.me/spring-boot-token-authentication-using-jwt)