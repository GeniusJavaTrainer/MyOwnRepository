CREATE TABLE student
(
	rollno INT PRIMARY KEY,
	name VARCHAR(40),
	percent FLOAT
);