package com.me.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.me.entity.Student;
import com.me.service.StudentService;
import com.me.service.StudentServiceImpl;

/**
 * Servlet implementation class MyServlet
 */
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Student s = new Student();
		int rollno = Integer.parseInt(request.getParameter("rollno"));
		String name = request.getParameter("name");
		float percent = Float.parseFloat(request.getParameter("percent"));
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		s.setRollno(rollno);
		s.setName(name);
		s.setPercent(percent);
		
		StudentService studentService = new StudentServiceImpl();
		
		String message = studentService.insertStudent(s);
		
		out.println(message);
			
	}
}