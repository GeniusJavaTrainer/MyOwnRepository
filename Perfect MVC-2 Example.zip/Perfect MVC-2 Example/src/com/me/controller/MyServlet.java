package com.me.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.me.entity.Student;
import com.me.service.StudentService;

/**
 * Servlet implementation class MyServlet
 */
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Student s = new Student();
		int rollno = Integer.parseInt(request.getParameter("rollno"));
		String name = request.getParameter("name");
		float percent = Float.parseFloat(request.getParameter("percent"));
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		s.setRollno(rollno);
		s.setName(name);
		s.setPercent(percent);
		
		StudentService ss = new StudentService();
		
		int st = ss.insertStudent(s);
		
		if(st == 1){
			out.println("Record inserted successfully.");
		}else{
			out.println("Unable to insert record.");
		}	
	}
}