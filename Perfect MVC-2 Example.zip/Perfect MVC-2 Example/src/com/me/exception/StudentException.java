package com.me.exception;

public class StudentException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1010029966119472300L;

	public StudentException(){
		
	}
	
	public StudentException(String message){
		super(message);
	}
}