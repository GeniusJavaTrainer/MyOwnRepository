package com.me.service;

import java.util.List;

import com.me.dao.StudentDao;
import com.me.dao.StudentDaoImpl;
import com.me.entity.Student;
import com.me.exception.StudentException;

public class StudentServiceImpl implements StudentService{

	private StudentDao studentDao;
	
	public StudentServiceImpl(){
		studentDao = new StudentDaoImpl();
	}
	
	public String insertStudent(Student student){
		String message = null;
		
		try {
			studentDao.insert(student);
			message = "Record inserted successfully";
		} catch (StudentException studentException) {
			message = studentException.getMessage();
		}
		
		return message;
	}

	@Override
	public List<Student> listAll() {
		List<Student>studentList = null;
				
		try {
			studentList = studentDao.listAll();
		} catch (StudentException studentException) {
			System.out.println(studentException.getMessage());
		}
		return studentList;
	}
}