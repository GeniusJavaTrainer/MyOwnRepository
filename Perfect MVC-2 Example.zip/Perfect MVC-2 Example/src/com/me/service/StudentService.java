package com.me.service;

import com.me.dao.StudentDAO;
import com.me.entity.Student;

public class StudentService {

	public int insertStudent(Student s){
		StudentDAO sd = new StudentDAO();
		
		int status = sd.insert(s);
		
		return status;
	}
}