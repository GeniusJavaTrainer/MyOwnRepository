package com.me.service;

import java.util.List;

import com.me.entity.Student;

public interface StudentService {

	public String insertStudent(Student s);
	
	public List<Student>listAll();
}