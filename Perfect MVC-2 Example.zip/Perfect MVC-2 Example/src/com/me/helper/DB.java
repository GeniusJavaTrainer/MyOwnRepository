package com.me.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DB {
	private static Connection connDB = null;
	
	public static Connection CreateConnection() throws ClassNotFoundException, SQLException{
		ResourceBundle rsMySql = ResourceBundle.getBundle("mysql");
		String driver = rsMySql.getString("driver");
		String url = rsMySql.getString("url");
		String user = rsMySql.getString("username");
		String password = rsMySql.getString("password");
		
		Class.forName(driver);
		connDB = DriverManager.getConnection(url, user, password);
		
		return connDB;
	}
}