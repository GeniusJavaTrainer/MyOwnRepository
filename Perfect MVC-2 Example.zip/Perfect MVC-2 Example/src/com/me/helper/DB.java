package com.me.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {
	private static Connection connDB = null;
	
	public static Connection CreateConnection() throws ClassNotFoundException, SQLException{
		String driver = new String("oracle.jdbc.driver.OracleDriver");
		String url = new String("jdbc:oracle:thin:@localhost:1521:XE");
		String user = new String("bvk");
		String password = new String("bvk");
		
		Class.forName(driver);
		connDB = DriverManager.getConnection(url, user, password);
		
		return connDB;
	}
	
	public static void closeConnection() throws SQLException{
		connDB.close();
	}
}