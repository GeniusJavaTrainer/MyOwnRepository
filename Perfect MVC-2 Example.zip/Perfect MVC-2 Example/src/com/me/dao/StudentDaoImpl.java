package com.me.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.me.entity.Student;
import com.me.exception.StudentException;
import com.me.helper.DB;

public class StudentDaoImpl implements StudentDao{
	
	public StudentDaoImpl(){
		
	}
	
	public int insert(Student student) throws StudentException{
		int isInserted = 0;
		String query = StudentQueries.INSERTQUERY;
		try (Connection connDB = DB.CreateConnection();
			 PreparedStatement	ps = connDB.prepareStatement(query);){
			
			ps.setInt(1, student.getRollno());
			ps.setString(2, student.getName());
			ps.setFloat(3, student.getPercent());
			
			isInserted = ps.executeUpdate();
		}catch(ClassNotFoundException cnfe){
			throw new StudentException(cnfe.getMessage());
		}catch(SQLException se){
			throw new StudentException(se.getMessage());
		}
		return isInserted;
	}

	@Override
	public List<Student> listAll() throws StudentException {
		List<Student>studentList = new ArrayList<>();
		String query = StudentQueries.LISTQUERY;
		
		try (Connection connDB = DB.CreateConnection();
		     PreparedStatement	ps = connDB.prepareStatement(query);){
			
			ResultSet rsStudent = ps.executeQuery();
						
			while(rsStudent.next()){
				Student student = new Student();
				
				student.setRollno(rsStudent.getInt("rollno"));
				student.setName(rsStudent.getString("name"));
				student.setPercent(rsStudent.getFloat("percent"));
				
				studentList.add(student);
			}
		}catch(ClassNotFoundException cnfe){
			throw new StudentException(cnfe.getMessage());
		}catch(SQLException se){
			throw new StudentException(se.getMessage());
		}
		return studentList;
	}
}
