package com.me.dao;

public interface StudentQueries {
	String INSERTQUERY = "INSERT INTO student VALUES(?,?,?)";
	String LISTQUERY = "SELECT rollno, name, percent "
						+ "FROM student"; 
}