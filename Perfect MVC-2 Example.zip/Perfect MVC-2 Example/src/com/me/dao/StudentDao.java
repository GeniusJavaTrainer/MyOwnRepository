package com.me.dao;

import java.util.List;

import com.me.entity.Student;
import com.me.exception.StudentException;

public interface StudentDao {
	public int insert(Student s) throws StudentException;
	
	public List<Student>listAll()
			throws StudentException;
}