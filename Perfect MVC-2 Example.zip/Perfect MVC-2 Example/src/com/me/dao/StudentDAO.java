package com.me.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.me.entity.Student;
import com.me.helper.DB;

public class StudentDAO {
	
	public StudentDAO(){
		
	}
	
	public int insert(Student s){
		Connection connDB = null;
		PreparedStatement ps = null;
		int isInserted = 0;
		String query = new String("INSERT INTO student VALUES(?,?,?)");
		try{
			connDB = DB.CreateConnection();
			ps = connDB.prepareStatement(query);
			ps.setInt(1, s.getRollno());
			ps.setString(2, s.getName());
			ps.setFloat(3, s.getPercent());
			
			isInserted = ps.executeUpdate();
		}catch(ClassNotFoundException cnfe){
			System.out.println(cnfe.getMessage());
		}catch(SQLException se){
			System.out.println(se.getMessage());
		}finally{
			try{
			DB.closeConnection();
			}catch(SQLException se){
				System.out.println(se.getMessage());
			}
		}
		return isInserted;
	}
}
