package com.example.demo.demo6;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WishController {
	@RequestMapping("/hello")
	public String wish() {
		return "Hi there!";
	}
}