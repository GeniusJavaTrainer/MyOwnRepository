package com.javalearning.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.javalearning.entity.Emp;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
		
		/*SampleEntity se = (SampleEntity)appContext.getBean("se");
		System.out.println(se);*/
		Emp e = (Emp)appContext.getBean("employee");
		/*Emp e = (Emp)appContext.getBean("employee");*/
		e.calculateSalary();
		
		/*Emp e1 = (Emp)appContext.getBean("employee");
		
		if(e == e1){
			System.out.println("Both beans are same.");
		}else{
			System.out.println("Both beans are different.");
		}*/
		/*SampleEntity se = (SampleEntity)appContext.getBean("se");
		
		System.out.println(se);*/
		System.out.println(e);
		
		/*Address address = (Address)appContext.getBean("address");
		
		System.out.println(address);*/
		System.out.println("End of program");
	}
}