package com.javalearning.entity;

public class SampleEntity {
	private String value;
	
	public SampleEntity(){
		System.out.println("Inside default constructor");
	}
	
	public SampleEntity(String value){
		this.value = value;
		System.out.println("Inside sample entity");
	}
	
	public SampleEntity(int value){
		this.value = Integer.toString(value);
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "value=" + value + "\n==============================================================";
	}
}