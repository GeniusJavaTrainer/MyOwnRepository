package com.me;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginValidateApplicationTests {

	@Test
	void contextLoads() {
	}

}
