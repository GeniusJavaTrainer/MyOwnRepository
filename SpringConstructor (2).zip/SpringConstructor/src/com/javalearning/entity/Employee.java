package com.javalearning.entity;

public class Employee implements Emp {
	private int empid;
	private String name;
	private String lastName;
	private Address address;
	private int basic;
	private float da;
	private float hra;
	private float pf;
	private float salary;
	
	
	public Employee() {
		super();
	}

	public Employee(int empid, String name, String lastName, Address address, int basic, float da, float hra,
			float pf) {
		super();
		this.empid = empid;
		this.name = name;
		this.lastName = lastName;
		this.address = address;
		this.basic = basic;
		this.da = da;
		this.hra = hra;
		this.pf = pf;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getBasic() {
		return basic;
	}

	public void setBasic(int basic) {
		this.basic = basic;
	}

	public float getDa() {
		return da;
	}

	public void setDa(float da) {
		this.da = da;
	}

	public float getHra() {
		return hra;
	}

	public void setHra(float hra) {
		this.hra = hra;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	public float getPf() {
		return pf;
	}

	public void setPf(float pf) {
		this.pf = pf;
	}

	
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public void calculateSalary() {
		salary = basic + da + hra - pf;
	}

	@Override
	public String toString() {
		return "empid="
				+ empid
				+ "\nname="
				+ name
				+ "\nlast name="
				+ lastName				
				+ "\naddress="
				+ address
				+ "\nbasic="
				+ basic
				+ "\nda="
				+ da
				+ "\nhra="
				+ hra
				+ "\npf="
				+ pf
				+ "\nsalary="
				+ salary
				+ "\n==============================================================";
	}
}