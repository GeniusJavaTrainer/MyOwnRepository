/**
 * 
 */

	document.write("Welcome to JavaScript Again!!");