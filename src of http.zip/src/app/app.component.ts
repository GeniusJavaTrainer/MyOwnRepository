import { Component } from '@angular/core';
import { map } from 'rxjs/operators';
import { Http, Response, Headers } from '@angular/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'httpservicedemo';
  headers = new Headers({'Content-Type' : 'application/json'})
  students = [];
  studentsPost : Object = [];
  studentsPut: Object = [];
  constructor(public httpdata: Http) { }
  ngOnInit() {
    this.httpdata.get('http://localhost:3000/students')
      .pipe(map(
        (response: Response) => response.json()

      )).subscribe((data) => {
        this.students = data
        console.log(data)
      }
        
    )
    this.studentsPost = [
      {
        "id": "22",
        "name": "Mayur Jadhav"
      }
    ]

    this.studentsPut = [
      {
        "id": "22",
        "name": "Pallavi Pawar"
      }
    ]
  }

  getData() {
    this.httpdata.get('http://localhost:3000/students')
      .pipe(map(
        (response: Response) => response.json()

      )).subscribe((data) => {
        this.students = data
        console.log(data)
      }

      )
  }

  postData() {
    this.httpdata.post('http://localhost:3000/students', this.studentsPost[0]).
      subscribe((data) =>
      
      console.log(data))
  }

  putData() {
    this.httpdata.put('http://localhost:3000/students/22', this.studentsPut[0]).
      subscribe((data) =>
      console.log(data))
  }

  deleteData() {
    this.httpdata.delete('http://localhost:3000/students/4').subscribe((data) =>
      console.log(data))
  }
  }
