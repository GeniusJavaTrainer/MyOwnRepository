package com.bvk.client;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.bvk.entity.Department;
import com.bvk.entity.Employee;

public class ClientOneToMany {

	public static void main(String[] args) {
		SessionFactory sf = new Configuration().configure().
				addAnnotatedClass(com.bvk.entity.Employee.class).
				addAnnotatedClass(com.bvk.entity.Department.class).
				buildSessionFactory();
		
		Session session = sf.openSession();
		
		Transaction tx = null;
		
		try{
			Employee employeeOne = new Employee();
			Employee employeeTwo = new Employee();
			Employee employeeThree = new Employee();
			
			Department department = new Department();
			
			department.setId(1);
			department.setName("Marketing");
			
			employeeOne.setId(1);
			employeeOne.setName("bvk");
			employeeOne.setSalary(90000);
			employeeOne.setDepartment(department);
			
			employeeTwo.setId(2);
			employeeTwo.setName("svk");
			employeeTwo.setSalary(180000);
			employeeTwo.setDepartment(department);
			
			employeeThree.setId(3);
			employeeThree.setName("pqr");
			employeeThree.setSalary(270000);
			employeeThree.setDepartment(department);
			
			
			Set<Employee>employees = new HashSet<>();
			employees.add(employeeOne);
			employees.add(employeeTwo);
			employees.add(employeeThree);
			
			department.setEmployees(employees);
			
			tx = session.beginTransaction();
			
			session.save(department);
			
			tx.commit();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}